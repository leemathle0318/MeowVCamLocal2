"""Logging contracts; Foundation integration runs separately on macOS CI."""
from pathlib import Path
import hashlib
import json
import plistlib
import re
import unittest

ROOT = Path(__file__).resolve().parents[1]


class SessionLogsTest(unittest.TestCase):
    def test_pre_repush_audio_and_video_algorithms_are_unchanged(self):
        baseline = json.loads((ROOT / 'LOGGING_BASELINE_SHA256.json').read_text(encoding='utf-8'))
        for name, digest in baseline['unchanged_files'].items():
            self.assertEqual(hashlib.sha256((ROOT / name).read_bytes()).hexdigest(), digest, name)
        source = (ROOT / 'Receiver.mm').read_text(encoding='utf-8')
        start = source.index('NSDictionary *OBLogSnapshot(void) {')
        end = source.index('void OBStart(', start)
        restored = source[:start] + source[end:]
        self.assertEqual(hashlib.sha256(restored.encode()).hexdigest(), baseline['receiver_without_diagnostics_utf8_sha256'])
        self.assertNotIn('RtmpReconnect.hpp', source)
        self.assertFalse((ROOT / 'core/RtmpReconnect.hpp').exists())

    def test_logging_does_not_replay_stream_commands(self):
        client = (ROOT / 'Client.m').read_text(encoding='utf-8')
        operation = client.split('NSString *OBCLogCommand(', 1)[1].split('NSString *OBCWiFiIP(', 1)[0]
        for key in ('Enabled', 'RequestID', 'RequestDate', 'RTMPURL'):
            self.assertNotIn('config[@"' + key + '"]=', operation)
        self.assertIn('config[@"LogRequestID"]=', operation)
        producer = (ROOT / 'Producer.mm').read_text(encoding='utf-8')
        self.assertLess(producer.index('OBLogHandleConfig(config)'), producer.index('NSString *request = config[@"RequestID"]'))
        make = (ROOT / 'Makefile').read_text(encoding='utf-8')
        self.assertIn('SessionLog.mm', next(x for x in make.splitlines() if x.startswith('OBSBridgeSB_FILES')))
        self.assertNotIn('SessionLog', next(x for x in make.splitlines() if x.startswith('OBSBridgeLive_FILES')))
        self.assertNotIn('SessionLog', (ROOT / 'AppAudio.mm').read_text(encoding='utf-8'))

    def test_numeric_privacy_and_sampling_semantics(self):
        receiver = (ROOT / 'Receiver.mm').read_text(encoding='utf-8').split('NSDictionary *OBLogSnapshot(', 1)[1].split('void OBStart(', 1)[0]
        receiver=re.sub(r'//[^\n]*', '', receiver)
        for text in ('RTMPURL', 'Pairing', 'heartbeat_key', 'lastPeer', 'lastError.c_str', 'OBStatus()'):
            self.assertNotIn(text, receiver)
        for key in ('audio_lead_ms', 'clock_rate_ppm', 'audio_wait_max_us', 'audio_engine_errors', 'capture_fresh', 'media', 'live'):
            self.assertIn('@"' + key + '"', receiver)
        log = (ROOT / 'SessionLog.mm').read_text(encoding='utf-8')
        for text in ('OBEnabled()?5.:60.', 'QOS_CLASS_UTILITY', 'n>=16', 'O_NOFOLLOW', 'st.st_nlink!=1',
                     'audience_stutter_mark', 'sample_gap_s', 'no_detected_record_loss_in_this_process', 'recovered_tail_bytes'):
            self.assertIn(text, log)
        for text in ('OBStartRTMP(', 'OBStop(', 'OBBusResetAudio(', 'OB_CONFIG options:', 'RTMPURL', 'heartbeat_key'):
            self.assertNotIn(text, log)
        self.assertIn('128ull*1024*1024', (ROOT / 'Shared.h').read_text(encoding='utf-8'))
        live = (ROOT / 'LiveAudioStatus.mm').read_text(encoding='utf-8')
        for key in ('missing_samples_u32', 'partial_blocks_u32', 'read_samples', 'rate_milli_ppm', 'fresh', 'pid'):
            self.assertIn('@"' + key + '"', live)

    def test_control_ui_exports_file_with_no_preview_or_legacy_route(self):
        source = (ROOT / 'controlapp/main.mm').read_text(encoding='utf-8')
        for text in ('标记卡顿', '导出全程日志', 'UIActivityViewController', 'sourceRect', 'dispatch_get_main_queue()', '清空诊断日志'):
            self.assertIn(text, source)
        action=source.split('- (void)logAction:',1)[1].split('- (void)start',1)[0]
        self.assertLess(action.index('OBCLogCommand(action,request)'),action.index('dispatch_async(dispatch_get_global_queue'))
        export = (ROOT / 'controlapp/LogExport.m').read_text(encoding='utf-8')
        self.assertIn('O_NOFOLLOW', export)
        self.assertIn('O_EXCL', export)
        self.assertIn('libSandy_applyProfile', export)
        self.assertIn('char buffer[65536]', export)
        info = plistlib.loads((ROOT / 'controlapp/Info.plist').read_bytes())
        self.assertNotIn('CFBundleURLTypes', info)
        self.assertEqual(info['CFBundleDisplayName'], 'tk直播推流助手')

    def test_only_the_control_app_can_read_only_the_fixed_export(self):
        profile = plistlib.loads((ROOT / 'layout/Library/libSandy/local.xiaoguai.obsbridge.log-read.plist').read_bytes())
        self.assertEqual(profile, {'AllowedProcesses': ['local.xiaoguai.obsbridge.control'], 'Extensions': [
            {'type': 'file', 'extension_class': 'com.apple.app-sandbox.read',
             'path': '/var/mobile/Library/Preferences/local.xiaoguai.obsbridge.diagnostics.jsonl'}]})
        workflow = (ROOT / '.github/workflows/build-deb.yml').read_text(encoding='utf-8')
        self.assertIn('bash scripts/run_session_log_tests.sh 2>&1 | tee work/session-log-test.log', workflow)
        self.assertIn('python3 -m unittest discover -s tests -p test_session_logs.py -v', workflow)
        for name in ('SessionLog.mm', 'session_journal_tests.cpp', 'run_session_log_tests.sh', 'test_session_logs.py'):
            self.assertIn(name, workflow)


if __name__ == '__main__':
    unittest.main()
