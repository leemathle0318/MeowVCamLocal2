#include "../core/AccessAttempt.hpp"
#ifdef NDEBUG
#undef NDEBUG
#endif
#include <cassert>
#include <cstdio>
int main() {
    obs::AccessAttempt a;
    assert(!a.begin(0) && a.attempts == 0);
    assert(a.begin(10)); a.finish(obs::AccessPhase::ReadProbeFailed, 1);
    assert(!a.verified && a.detail == 1); // API success must not imply access success
    assert(a.begin(10)); a.finish(obs::AccessPhase::ProfileRejected, 2);
    assert(a.begin(10)); a.finish(obs::AccessPhase::LibraryMissing, 0);
    assert(!a.begin(10) && a.attempts == 3);
    assert(a.begin(11) && a.attempts == 1); // fresh file session needs fresh grant
    a.finish(obs::AccessPhase::Verified, 0);
    assert(a.verified && !a.begin(11));
    assert(a.begin(12)); a.finish(obs::AccessPhase::HeaderMismatch, 0);
    assert(!a.verified && uint32_t(a.state() >> 32) == uint32_t(obs::AccessPhase::HeaderMismatch));
    std::puts("PASS: permission attempt policy, bounded retries, changed inode/session, real-probe requirement (not a libSandy runtime test)");
}
