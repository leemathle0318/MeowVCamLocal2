#ifdef NDEBUG
#undef NDEBUG
#endif
#include "../core/AudioReadClock.hpp"
#include "../core/SharedMedia.hpp"
#include <cassert>
#include <cstdio>
#include <memory>
#include <vector>
int main() {
    uint64_t oldJumps=0, oldMissingTailBlocks=0;
    double largestPhase=0;
    // Four simulated hours per combination. This is clock simulation, not
    // an iPhone livestream or a measurement of the user's source lookahead.
    for (double ppm : {-100.,-10.,10.,100.}) for (bool jitter : {false,true}) {
        obs::AudioDeliveryCursor old;
        obs::DisciplinedAudioCursor clock;
        constexpr double dt=.010;
        double previous=0, previousOld=0;
        unsigned jumps=0, dry=0;
        for (unsigned i=0;i<1440000;++i) {
            double now=1000.+i*dt*(1+ppm/1e6);
            if(jitter)now+=.002*std::sin(i*.037)+.001*std::sin(i*.137);
            double start=clock.begin(1,1,now,480,48000);
            double oldStart=old.begin(1,1,now,480,48000);
            if(i){jumps+=std::abs(start-previous)>1e-8;oldJumps+=std::abs(oldStart-previousOld)>.001;}
            previous=clock.next;previousOld=old.next;
            largestPhase=std::max(largestPhase,std::abs(start-now));
            // 60ms lookahead is deliberately inside the receiver's healthy window.
            dry+=clock.next>now+.060;
            oldMissingTailBlocks+=old.next>now+.060;
            assert(std::abs(clock.correction)<=.0005000001);
            assert(std::abs(start-now)<.010);
            if(i)assert(std::abs((previous-start)-480/clock.effectiveRate)<1e-9);
        }
        assert(jumps==0 && dry==0);
    }
    assert(oldJumps>0 && oldMissingTailBlocks>0);
    // Native block sizes/rates remain unchanged. Variable callbacks keep the
    // program sample cursor continuous, not a splice on every callback.
    for(double rate : {8000.,44100.,48000.,96000.,192000.}) {
        obs::DisciplinedAudioCursor clock;
        double now=100,previous=100;
        for(unsigned i=0;i<10000;++i){
            unsigned frames=(i%2)?256:512;
            double start=clock.begin(4,2,now,frames,rate);
            assert(std::abs(start-previous)<1e-8);
            assert(clock.effectiveRate>=8000 && clock.effectiveRate<=192000);
            assert(clock.next>start);previous=clock.next;
            now+=frames/rate*(1+10./1e6);
        }
        assert(clock.begin(4,3,1000,256,rate)==1000); // shared epoch
        assert(clock.correction==0);
        assert(clock.begin(5,3,2000,256,rate)==2000); // source restart
        assert(clock.begin(5,3,2001,256,rate)==2001); // actual pause/discontinuity
        assert(std::isnan(clock.begin(5,3,2001,0,rate)));
    }
    // Exercise the actual shared PCM reader at the compensated rate, with
    // deterministic 440Hz source audio. No new timestamps or output frames.
    auto bus=std::make_unique<obs::SharedMedia>();
    bus->initialize();bus->enabled=1;bus->generation=1;bus->heartbeatUS=100000000;
    std::vector<float> pcm(96000);
    for(size_t i=0;i<pcm.size();++i)pcm[i]=float(.25*std::sin(2*3.141592653589793*440*i/48000));
    bus->writeAudio(pcm.data(),pcm.size(),100);
    obs::DisciplinedAudioCursor clock;
    float data[480];uint8_t valid[480];obs::AudioReadCoverage coverage;
    double previous=100;
    for(unsigned i=0;i<90;++i){
        double now=100+i*.0100001;
        double start=clock.begin(1,1,now,480,48000);
        assert(std::abs(start-previous)<1e-8);previous=clock.next;
        bus->heartbeatUS=uint64_t(now*1e6);
        assert(bus->readAudio(data,480,start,clock.effectiveRate,uint64_t(now*1e6),&coverage,valid));
        assert(coverage.found==480);
        for(unsigned j=0;j<480;++j){
            double time=start-100+j/clock.effectiveRate;
            double expected=.25*std::sin(2*3.141592653589793*440*time);
            assert(std::abs(data[j]-expected)<.00012);
        }
    }
    std::printf("PASS: 8 x 4h clock models (not iPhone runtime), +/-10/100ppm with callback jitter; legacy jumps=%llu tail-miss-blocks=%llu; disciplined continuous/no missing tails max phase=%.3fms; native formats/variable blocks/session/epoch/pause; actual shared PCM tone read\n",
        (unsigned long long)oldJumps,(unsigned long long)oldMissingTailBlocks,largestPhase*1000);
}
