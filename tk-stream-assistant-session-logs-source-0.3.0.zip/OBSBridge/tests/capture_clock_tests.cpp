#ifdef NDEBUG
#undef NDEBUG
#endif
#include "../core/CaptureClockFeedback.hpp"
#include <cassert>
#include <cstdio>
#include <memory>
#include <thread>
using namespace obs::next;
static CaptureReport report(uint64_t frame,double host,double rate=48000) {
    CaptureReport r;
    r.cookie=123;r.unit=1;r.generation=2;r.formatVersion=4;r.frames=480;
    r.framePosition=frame;r.hasSample=r.hasHost=true;r.sampleTime=10000.+double(frame);
    r.hostTime=host;r.callbackTime=host+.003;r.nominalRate=rate;return r;
}
static void constantSkew(double ppm,int rate) {
    CaptureClockTracker clock;
    constexpr unsigned blocks=24*3600*100;
    double host=1000.;
    uint64_t frames=0;
    unsigned count=unsigned(rate/100);
    for(unsigned n=0;n<blocks;++n) {
        CaptureReport r=report(frames,host,rate);r.frames=count;
        // Scheduling is bursty, but hardware timestamps remain paired. Changing
        // callback arrival must not masquerade as a frequency error.
        r.callbackTime=host+.004+double(n%17)*.00003;
        auto result=clock.observe(r);
        assert(result==CaptureClockResult::Priming || result==CaptureClockResult::Observed || result==CaptureClockResult::RateUpdated);
        if(clock.ready(r.callbackTime)) {
            assert(std::abs(clock.ppm()-ppm)<.03);
            double master=clock.masterForHost(host+.18,r.callbackTime);
            assert(std::isfinite(master));
            assert(std::abs(clock.hostForMaster(master,r.callbackTime)-(host+.18))<1e-8);
        }
        frames+=count;host+=double(count)/rate/(1.+ppm/1e6);
    }
    assert(clock.stats.discontinuities==0 && clock.stats.updated>10000);
    assert(clock.ready(host+.003));
    assert(!clock.ready(host+3));
    assert(std::isnan(clock.masterForHost(host+3,host+3)));
    std::printf("PASS 24h accelerated paired native clock: rate=%d skew=%+.0fppm measured=%+.6fppm; callback jitter does not drive clock\n",rate,ppm,clock.ppm());
}
static void reportLossAndGuards() {
    auto queue=std::make_unique<CaptureReportQueue<4>>();
    CaptureReportSource producer;CaptureClockTracker clock;
    for(unsigned n=0;n<1000;++n) {
        auto r=report(0,100.+n*.01);r.sampleTime=10000.+n*480.;
        producer.offer(*queue,r);
        if(n%10==9) {
            CaptureReport item;
            while(queue->pop(item))clock.observe(item);
        }
    }
    assert(queue->dropped()==600 && clock.stats.discontinuities==0);
    assert(clock.ready(110.) && std::abs(clock.ppm())<.01);
    auto latest=clock.latest();
    assert(clock.observe(latest)==CaptureClockResult::Stale);
    latest.callbackTime+=.01;latest.hostTime+=.01;latest.framePosition+=480;latest.sampleTime+=480;
    latest.hasHost=false;
    assert(clock.observe(latest)==CaptureClockResult::Unavailable);
    latest.hasHost=true;latest.hostTime=NAN;
    assert(clock.observe(latest)==CaptureClockResult::Invalid);
    latest=clock.latest();latest.hostTime+=.01;latest.callbackTime+=.01;
    latest.framePosition+=480;latest.sampleTime+=481;
    auto revision=clock.revision();
    assert(clock.observe(latest)==CaptureClockResult::Discontinuity);
    assert(clock.revision()==revision+1);
    assert(!clock.ready(latest.callbackTime));
    latest.cookie++;
    assert(clock.observe(latest)==CaptureClockResult::Priming);
    assert(clock.revision()==revision+2);
    assert(!clock.ready(latest.callbackTime));
    std::puts("PASS bounded observation overflow, exact consumed-frame accounting, duplicates/invalid stamps, device gap and session isolation");
}
static void concurrentQueue() {
    auto queue=std::make_unique<CaptureReportQueue<64>>();
    std::atomic<bool> done{false};uint64_t accepted=0,observed=0;
    std::thread producer([&]{
        for(uint64_t n=1;n<=500000;++n) {
            auto r=report(n*480,100.+double(n)*.01);r.cookie=n;r.unit=n^0xfeed;
            if(queue->push(r))++accepted;
        }
        done.store(true,std::memory_order_release);
    });
    uint64_t previous=0;
    for(;;) {
        CaptureReport r;
        if(queue->pop(r)) {
            assert(r.cookie>previous && r.unit==(r.cookie^0xfeed) && r.framePosition==r.cookie*480);
            assert(r.sampleTime==10000.+double(r.framePosition));
            previous=r.cookie;++observed;
        } else if(done.load(std::memory_order_acquire)) {
            // done is published after the final queue write. Recheck to cover a
            // producer write between the failed pop and the acquire above.
            if(!queue->pop(r))break;
            assert(r.cookie>previous && r.unit==(r.cookie^0xfeed));previous=r.cookie;++observed;
        } else std::this_thread::yield();
    }
    producer.join();
    assert(observed==accepted && accepted+queue->dropped()==500000);
    std::puts("PASS real producer/consumer threads: bounded feedback records stay coherent, no lock-wait or torn payload");
}
static void changingRate() {
    CaptureClockTracker clock;
    double host=100.,sample=10000.;
    double largestError=0;
    for(unsigned n=0;n<3600*100;++n) {
        double ppm=500.*std::sin(2.*3.141592653589793*n/90000.);
        auto r=report(uint64_t(n)*480,host);r.sampleTime=sample;
        clock.observe(r);
        if(clock.ready(r.callbackTime))largestError=std::max(largestError,std::abs(clock.ppm()-ppm));
        sample+=480.;host+=.01/(1.+ppm/1e6);
    }
    assert(largestError<45 && clock.stats.discontinuities==0);
    auto r=clock.latest();
    // A coherent-looking but very noisy hardware time domain is not silently
    // accepted just because an older window was valid.
    for(unsigned n=1;n<=1000;++n) {
        auto bad=r;bad.framePosition+=uint64_t(n)*480;bad.sampleTime+=n*480.;
        bad.hostTime+=n*.01+((n%2)? .001 : -.001);bad.callbackTime=bad.hostTime+.003;
        clock.observe(bad);
    }
    assert(clock.stats.unreliable>0 && !clock.ready(clock.latest().callbackTime));
    std::printf("PASS changing hardware frequency and noisy timestamp rejection: maximum tracking error %.3fppm\n",largestError);
}
int main(){
    for(int rate:{44100,48000})for(double ppm:{-500.,500.})constantSkew(ppm,rate);
    reportLossAndGuards();concurrentQueue();changingRate();
}
