#ifdef NDEBUG
#undef NDEBUG
#endif
#include "../core/VideoContinuity.hpp"
#include "../core/SharedMedia.hpp"
#include "../core/MappedMedia.hpp"
#include <cassert>
#include <cstdio>
#include <memory>

int main() {
    obs::VideoContinuity state;
    assert(!state.reusable(1000000));
    state.context(77, 1, true);
    assert(state.accept(0, 1, 1000000, 1000000));
    assert(state.same(0, 1)); assert(!state.same(1, 1));
    assert(state.reusable(2499999)); assert(!state.reusable(2500000));
    assert(!state.reusable(999999));
    assert(!state.accept(0, 2, 2000000, 1900000));
    assert(state.same(0, 1)); // failed read must not replace a good snapshot
    state.context(77, 1, false); assert(!state.reusable(1000000));
    state.context(77, 2, true); assert(!state.reusable(1000000));
    assert(state.accept(0, 2, 1000000, 1000000));
    state.context(78, 2, true); assert(!state.reusable(1000000));
    assert(state.accept(1, 3, 1000000, 1000000));
    state.context(78, 3, true); assert(!state.reusable(1000000));

    // Same-sized source/capture clocks, 30 fps source / 60 fps camera.
    // Force every third callback to lose its shared snapshot read.
    // Old per-callback fail-open leaks the camera. A copied-frame cache holds
    // a complete prior OBS frame; no corrupted shared bytes are accepted.
    state.context(79, 1, true);
    unsigned oldReal = 0, newReal = 0, held = 0;
    for (unsigned i = 0; i < 600; ++i) {
        uint64_t now = 1000000 + uint64_t(i) * 16667;
        bool copied = (i % 3 != 2);
        if (copied) {
            assert(state.accept((i / 2) % 3, i / 2 + 1, now, now));
        } else ++oldReal;
        if (!state.reusable(now)) ++newReal;
        else if (!copied) ++held;
    }
    assert(oldReal == 200 && newReal == 0 && held == 200);
    assert(!state.reusable(state.due + obs::VideoContinuity::HoldUS)); // prolonged disconnect isn't hidden
    state.context(79, 1, false); assert(!state.valid);

    // EXIF quarter-turns: landscape sensor + portrait display compose back to
    // upright. Old right(6) plus display right(6) composed to a half-turn.
    assert(obs::sensorOrientation(720, 1280, 1920, 1080) == 8);
    assert(obs::sensorOrientation(1280, 720, 1920, 1080) == 1);
    assert(obs::sensorOrientation(720, 1280, 1080, 1920) == 1);
    assert(obs::extraOrientation(0) == 1 && obs::extraOrientation(1) == 6);
    assert(obs::extraOrientation(2) == 3 && obs::extraOrientation(3) == 8);
    assert(obs::extraOrientation(4) == 1);

    auto bus = std::make_unique<obs::SharedMedia>();
    bus->initialize(); bus->enabled = 1; bus->heartbeatUS = 1000000;
    assert(bus->fresh(1000000)); assert(bus->fresh(999999));
    assert(bus->fresh(997500)); assert(!bus->fresh(997499));
    assert(bus->fresh(2999999)); assert(!bus->fresh(3000000));
    bus->enabled = 0; assert(!bus->fresh(1000000));
    // A large frame copy may span a producer heartbeat. Its final freshness
    // check must sample the clock AGAIN, not reuse the pre-copy timestamp.
    auto mapped = std::make_unique<obs::MappedMedia>();
    mapped->initialize(91); mapped->state.enabled = 1; mapped->state.generation = 1;
    mapped->state.heartbeatUS = 1000000;
    uint32_t words[] = {1, 2, 3, 4};
    auto &slot = mapped->state.video[0];
    assert(mapped->frames[0].write(reinterpret_cast<uint8_t *>(words), 8, 2, 2));
    slot.surface = 1; slot.generation = 1; slot.dueUS = 1000000; slot.sequence = 1;
    obs::FrameTicket ticket{}; assert(obs::captureFrame(*mapped, 0, 1000000, ticket));
    uint32_t result[4]{}; unsigned reads = 0;
    auto clock = [&]() -> uint64_t {
        uint64_t now = reads++ ? 1020000 : 1000000;
        mapped->state.heartbeatUS = now; return now;
    };
    assert(obs::copyFrameTimed(*mapped, ticket, clock, reinterpret_cast<uint8_t *>(result), 8, sizeof(result)));
    assert(reads == 2 && result[0] == 1 && result[3] == 4);
    assert(!obs::frameUnchanged(*mapped, ticket, 1000000)); // old frozen time would wrongly reject
    std::puts("PASS: 200 forced short read misses: old real-camera fallback=200, cached fallback=0; stop/session/epoch/expiry; EXIF orientation; heartbeat clock-load race (policy tests, not iPhone rendering)");
}
