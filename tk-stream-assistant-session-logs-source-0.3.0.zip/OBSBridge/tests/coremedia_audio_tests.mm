#ifdef NDEBUG
#undef NDEBUG
#endif
#import "../AudioSample.h"
#include "../core/NativePCM.hpp"
#include <cassert>
#include <cstdio>
#include <vector>
#include <array>

static void exercise(bool planar, bool floating, bool individualTiming) {
    std::printf("CASE: planar=%d float=%d individualTiming=%d frames=481\n",
        planar, floating, individualTiming); std::fflush(stdout);
    constexpr size_t frames = 481;
    obs::NativePCM pcm;
    pcm.bits = floating ? 32 : 16; pcm.bytes = floating ? 4 : 2;
    pcm.channels = 2; pcm.planar = planar; pcm.floating = floating;
    pcm.signedInteger = !floating; pcm.frameBytes = pcm.bytes * (planar ? 1 : 2);
    AudioStreamBasicDescription asbd{};
    asbd.mSampleRate = 48000; asbd.mFormatID = kAudioFormatLinearPCM;
    asbd.mFormatFlags = kAudioFormatFlagIsPacked |
        (floating ? kAudioFormatFlagIsFloat : kAudioFormatFlagIsSignedInteger) |
        (planar ? kAudioFormatFlagIsNonInterleaved : 0);
    asbd.mBitsPerChannel = pcm.bits; asbd.mChannelsPerFrame = 2;
    asbd.mFramesPerPacket = 1; asbd.mBytesPerFrame = asbd.mBytesPerPacket = pcm.frameBytes;
    CMAudioFormatDescriptionRef format = nullptr;
    assert(!CMAudioFormatDescriptionCreate(kCFAllocatorDefault, &asbd, 0, nullptr,
        0, nullptr, nullptr, &format) && format);
    size_t planes = planar ? 2 : 1, planeBytes = frames * pcm.frameBytes;
    std::vector<uint8_t> micBytes(planeBytes * planes);
    for (size_t b = 0; b < planes; ++b) for (size_t i = 0; i < frames; ++i)
        for (unsigned c = 0; c < (planar ? 1u : 2u); ++c)
            obs::pcmWrite(micBytes.data() + b * planeBytes + i * pcm.frameBytes + c * pcm.bytes,
                pcm, (planar ? b : c) ? -.25 : .25);
    CMBlockBufferRef sourceBlock = nullptr;
    assert(!CMBlockBufferCreateWithMemoryBlock(kCFAllocatorDefault, nullptr, micBytes.size(),
        kCFAllocatorDefault, nullptr, 0, micBytes.size(), 0, &sourceBlock));
    assert(!CMBlockBufferAssureBlockMemory(sourceBlock));
    assert(!CMBlockBufferReplaceDataBytes(micBytes.data(), sourceBlock, 0, micBytes.size()));
    CMSampleTimingInfo first{CMTimeMake(1,48000), CMTimeMake(480000,48000), kCMTimeInvalid};
    std::vector<CMSampleTimingInfo> timing(individualTiming ? frames : 1, first);
    if (individualTiming) for (size_t i = 0; i < frames; ++i)
        timing[i].presentationTimeStamp = CMTimeMake(480000 + int64_t(i), 48000);
    size_t stride = pcm.frameBytes;
    CMSampleBufferRef source = nullptr;
    assert(!CMSampleBufferCreate(kCFAllocatorDefault, sourceBlock, true, nullptr, nullptr,
        format, frames, timing.size(), timing.data(), planar ? 0 : 1,
        planar ? nullptr : &stride, &source) && source);
    // Confirm the fixture itself is readable, so a malformed source is not
    // mistaken for a mixing/output-construction failure.
    alignas(16) std::array<uint8_t, OBAudioListCapacity> sourceStorage{};
    auto *sourceList = reinterpret_cast<AudioBufferList *>(sourceStorage.data());
    size_t sourceNeeded = 0; CMBlockBufferRef sourceRetained = nullptr;
    OBAudioListReport sourceReport{};
    OSStatus sourceRC = OBGetAudioBufferList(source, sourceList, sourceStorage.size(), &sourceNeeded, &sourceRetained, &sourceReport);
    std::fprintf(stderr, "SOURCE: status=%d query=%d fill=%d stage=%u inputBuffers=%u needed=%zu capacity=%zu buffers=%u bytes=%zu\n",
        int(sourceRC), int(sourceReport.queryStatus), int(sourceReport.fillStatus), sourceReport.stage,
        sourceReport.inputBuffers, sourceNeeded, sourceStorage.size(), sourceList->mNumberBuffers, micBytes.size());
    assert(sourceRC == 0 && sourceRetained);
    assert(sourceList->mNumberBuffers == planes);
    CFRelease(sourceRetained);
    CMSetAttachment(source, CFSTR("test.propagating"), CFSTR("keep"), kCMAttachmentMode_ShouldPropagate);
    CMSetAttachment(source, CFSTR("test.private"), CFSTR("also keep"), kCMAttachmentMode_ShouldNotPropagate);
    auto sampleAttachments = CMSampleBufferGetSampleAttachmentsArray(source, true);
    assert(sampleAttachments && CFArrayGetCount(sampleAttachments));
    auto sampleDict = static_cast<CFMutableDictionaryRef>(const_cast<void *>(CFArrayGetValueAtIndex(sampleAttachments, 0)));
    CFDictionarySetValue(sampleDict, kCMSampleAttachmentKey_NotSync, kCFBooleanTrue);

    std::vector<uint8_t> changed = micBytes;
    alignas(16) std::array<uint8_t, OBAudioListCapacity> storage{};
    auto *abl = reinterpret_cast<AudioBufferList *>(storage.data()); abl->mNumberBuffers = UInt32(planes);
    obs::PCMBuffer buffers[2];
    for (size_t b = 0; b < planes; ++b) {
        abl->mBuffers[b] = {planar ? 1u : 2u, UInt32(planeBytes), changed.data() + b * planeBytes};
        buffers[b] = {abl->mBuffers[b].mData, planeBytes, planar ? 1u : 2u};
    }
    std::vector<float> program(frames, .2f);
    assert(obs::mixNative(program.data(), buffers, planes, frames, pcm, 1., .70));
    OSStatus status = 999;
    CMSampleBufferRef mixed = OBCopyMixedAudioSample(source, abl, &status);
    std::fprintf(stderr, "BUILD: status=%d result=%p layout=%s kind=%s timing=%s\n", int(status),
        static_cast<const void *>(mixed), planar ? "planar" : "interleaved",
        floating ? "float32" : "int16", individualTiming ? "per-frame" : "single");
    assert(mixed && status == 0 && CMSampleBufferDataIsReady(mixed));
    // Destroy temporary channel storage: the returned sample must own its bytes.
    std::fill(changed.begin(), changed.end(), 0x5a);
    assert(CMSampleBufferGetNumSamples(mixed) == frames);
    assert(CMFormatDescriptionEqual(CMSampleBufferGetFormatDescription(mixed), format));
    assert(CMTimeCompare(CMSampleBufferGetPresentationTimeStamp(mixed), first.presentationTimeStamp) == 0);
    CMItemCount actualCount = 0;
    assert(!CMSampleBufferGetSampleTimingInfoArray(mixed, 0, nullptr, &actualCount));
    assert(actualCount == CMItemCount(timing.size()));
    std::vector<CMSampleTimingInfo> actual(size_t(actualCount), CMSampleTimingInfo{});
    assert(!CMSampleBufferGetSampleTimingInfoArray(mixed, actualCount, actual.data(), nullptr));
    for (size_t i = 0; i < actual.size(); ++i) {
        assert(CMTimeCompare(actual[i].presentationTimeStamp, timing[i].presentationTimeStamp) == 0);
        assert(CMTimeCompare(actual[i].duration, timing[i].duration) == 0);
        assert(!CMTIME_IS_VALID(actual[i].decodeTimeStamp));
    }
    assert(CFEqual(CMGetAttachment(mixed, CFSTR("test.propagating"), nullptr), CFSTR("keep")));
    CMAttachmentMode mode{};
    assert(CFEqual(CMGetAttachment(mixed, CFSTR("test.private"), &mode), CFSTR("also keep")));
    assert(mode == kCMAttachmentMode_ShouldNotPropagate);
    auto outAttachments = CMSampleBufferGetSampleAttachmentsArray(mixed, false);
    auto outDict = static_cast<CFDictionaryRef>(CFArrayGetValueAtIndex(outAttachments, 0));
    assert(CFDictionaryGetValue(outDict, kCMSampleAttachmentKey_NotSync) == kCFBooleanTrue);
    CMBlockBufferRef retained = nullptr; size_t needed = 0;
    OBAudioListReport mixedReport{};
    OSStatus extracted = OBGetAudioBufferList(mixed, abl, storage.size(), &needed, &retained, &mixedReport);
    std::fprintf(stderr, "EXTRACT: status=%d query=%d fill=%d stage=%u inputBuffers=%u needed=%zu capacity=%zu buffers=%u\n",
        int(extracted), int(mixedReport.queryStatus), int(mixedReport.fillStatus), mixedReport.stage,
        mixedReport.inputBuffers, needed, storage.size(), abl->mNumberBuffers);
    assert(extracted == 0 && retained);
    assert(abl->mNumberBuffers == planes && needed <= storage.size());
    for (size_t b = 0; b < planes; ++b) for (size_t i = 0; i < frames; ++i)
        for (unsigned c = 0; c < (planar ? 1u : 2u); ++c) {
            double value = obs::pcmRead(static_cast<uint8_t *>(abl->mBuffers[b].mData) + i * pcm.frameBytes + c * pcm.bytes, pcm);
            assert(std::fabs(value - ((planar ? b : c) ? -.11 : .39)) < .0001);
        }
    CFRelease(retained);
    // Insufficient metadata space must return an error, not overwrite memory.
    size_t shortNeeded = 0; CMBlockBufferRef shortBlock = nullptr;
    assert(OBGetAudioBufferList(mixed, abl, 1, &shortNeeded, &shortBlock) == kCMSampleBufferError_ArrayTooSmall);
    assert(!shortBlock && shortNeeded > 1);
    std::vector<uint8_t> original(micBytes.size());
    assert(!CMBlockBufferCopyDataBytes(CMSampleBufferGetDataBuffer(source), 0, original.size(), original.data()));
    assert(original == micBytes); // Original microphone buffer is never modified.
    auto wrong = *abl; wrong.mNumberBuffers = 0;
    assert(!OBCopyMixedAudioSample(source, &wrong, &status) && status != 0);
    assert(!OBCopyMixedAudioSample(nullptr, abl, &status) && status != 0);
    CFRelease(mixed); CFRelease(source); CFRelease(sourceBlock); CFRelease(format);
}
int main() {
    @autoreleasepool {
        for (bool planar : {false,true}) for (bool floating : {false,true})
            for (bool timing : {false,true}) exercise(planar, floating, timing);
        std::puts("PASS: real macOS CoreMedia APIs: 8 PCM layout/timing cases, owned mixed bytes, original mic unchanged, ASBD/PTS/attachments retained");
    }
}
