#ifdef NDEBUG
#undef NDEBUG
#endif
#include "../core/VideoBudget.hpp"
#include "../core/VideoCopy.hpp"
#include <cassert>
#include <cstdio>
#include <array>
int main() {
    assert(obs::videoBudget(0,0).edge==960 && obs::videoBudget(1,0).edge==1280);
    assert(obs::videoBudget(1,2).edge==800 && obs::videoBudget(1,2).fps==20);
    assert(obs::videoBudget(1,3).edge==640 && obs::videoBudget(1,3).fps==15);
    assert(obs::videoBudget(2,0).edge==2048 && obs::videoBudget(2,0).fps==60);
    assert(obs::videoBudget(2,2).fps==20 && obs::videoBudget(2,3).fps==15);
    assert(obs::normalizedProfile(3)==2 && obs::normalizedProfile(1)==1);
    for (unsigned sourceFPS : {24u,25u,30u,50u,60u}) {
        obs::FrameGate original;unsigned count=0;
        for(unsigned i=0;i<sourceFPS*100;++i)
            count+=original.admit(std::floor(i*1000./sourceFPS)/1000.,60);
        assert(count==sourceFPS*100); // source frames retained, never duplicated to 60
    }
    for (unsigned fps : {15u,20u,30u}) {
        obs::FrameGate gate; unsigned count=0;
        for (unsigned i=0;i<600;++i) if (gate.admit(i/60.,fps)) ++count;
        assert(count==fps*10);
        assert(gate.admit(0,fps)); // backward sender PTS reset, not permanent starvation
        assert(!gate.admit(NAN,fps)); assert(!gate.admit(1,0));
    }
    for (unsigned inputFPS : {30u,60u}) {
        for (unsigned targetFPS : {15u,20u,30u}) {
            obs::FrameGate gate; unsigned count=0;
            for (unsigned i=0;i<inputFPS*100;++i) {
                double pts=std::floor(i*1000./inputFPS)/1000.;
                count += gate.admit(pts,targetFPS);
                assert(!gate.admit(pts,targetFPS)); // duplicate never counted
            }
            assert(count==targetFPS*100);
        }
    }
    obs::FrameGate changed;
    assert(changed.admit(0,30));
    assert(changed.admit(.01,15)); // thermal budget transition resets phase
    assert(!changed.admit(.02,15));
    assert(changed.admit(100,15)); // large gap skips slots in constant time
    std::array<uint8_t,32> from{},to{};
    for (unsigned i=0;i<32;++i) from[i]=uint8_t(i+1);
    to.fill(99);
    obs::VideoPlane planes[]={{from.data(),to.data(),8,8,2,4}, {from.data()+16,to.data()+16,8,8,1,4}};
    assert(obs::copyVideoPlanes(planes,2));
    assert(to[0]==1 && to[8]==9 && to[16]==17 && to[4]==99 && to[20]==99);
    auto prior=to; planes[1].bytes=9;
    assert(!obs::copyVideoPlanes(planes,2) && to==prior); // Y unchanged if UV invalid
    planes[1].bytes=4; planes[1].target=nullptr;
    assert(!obs::copyVideoPlanes(planes,2) && to==prior);
    planes[1].target=to.data()+16; planes[0].sourceStride=SIZE_MAX;
    assert(!obs::copyVideoPlanes(planes,2) && to==prior);
    assert(!obs::copyVideoPlanes(nullptr,2)); assert(!obs::copyVideoPlanes(planes,3));
    std::puts("PASS: 60-to-30/20/15 fps gates, PTS reset, thermal/profile bounds; preflighted BGRA/NV12 stride copies and unchanged padding (not device heat measurement)");
}
