#import "../SessionLog.h"
#import "../Shared.h"
#import "../Receiver.h"
#include <cassert>
#include <cstdio>
#include <fcntl.h>
#include <sys/stat.h>
#include <unistd.h>
#include <cmath>
double OBNow(void){return NSProcessInfo.processInfo.systemUptime;}
BOOL OBEnabled(void){return YES;}
NSDictionary *OBLogSnapshot(void){return @{@"enabled":@YES,@"connected":@YES,@"generation":@1,@"clock_epoch":@2,@"accepted":@3,@"clock_resets":@0,@"audio_segments":@0,@"audio_engine_errors":@0,@"lead_us":@1234,@"unavailable":@(NAN)};}
NSDictionary *waitAck(NSString *request) {
    double end=OBNow()+10;
    while(OBNow()<end){NSDictionary *s=OBLogState();if([s[@"Ack"] isEqual:request])return s;usleep(10000);}
    assert(false && "log worker acknowledgement timed out");return nil;
}
NSDictionary *command(NSString *action) {
    NSString *request=NSUUID.UUID.UUIDString;
    OBLogHandleConfig(@{@"LogRequestID":request,@"LogRequestDate":[NSDate date],@"LogAction":action,
        @"RTMPURL":@"rtmp://private.example/live/DO_NOT_LOG_TOKEN",@"Pairing":@{@"key":@"DO_NOT_LOG_SECRET"}});
    return waitAck(request);
}
int main(){@autoreleasepool{
    // Compile-time paths are a mktemp directory, never the phone Preferences.
    FILE *start=fopen(OB_LOG_FILE,"w");assert(start);fputs("{\"before_restart\":1}\n{\"incomplete\":",start);fclose(start);
    OBLogInitialize();double end=OBNow()+5;
    while(![OBLogState()[@"Ready"] boolValue] && OBNow()<end)usleep(10000);
    assert([OBLogState()[@"Ready"] boolValue]);assert([OBLogState()[@"RecoveredTailBytes"] unsignedLongLongValue]>0);
    assert([command(@"mark")[@"OK"] boolValue]);assert(OBEnabled());
    // A stale command must not clear anything.
    uint64_t bytes=[OBLogState()[@"Bytes"] unsignedLongLongValue];
    OBLogHandleConfig(@{@"LogRequestID":NSUUID.UUID.UUIDString,@"LogAction":@"clear",@"LogRequestDate":[NSDate dateWithTimeIntervalSinceNow:-100]});
    usleep(50000);assert([OBLogState()[@"Bytes"] unsignedLongLongValue]>=bytes);
    assert([command(@"export")[@"OK"] boolValue]);
    NSString *exported=[NSString stringWithContentsOfFile:@OB_LOG_EXPORT_FILE encoding:NSUTF8StringEncoding error:nil];
    assert([exported hasPrefix:@"{\"before_restart\":1}\n"]);assert([exported containsString:@"audience_stutter_mark"]);
    assert(![exported containsString:@"DO_NOT_LOG"] && ![exported containsString:@"RTMPURL"]);
    for(NSString *line in [exported componentsSeparatedByString:@"\n"])if(line.length)assert([NSJSONSerialization JSONObjectWithData:[line dataUsingEncoding:NSUTF8StringEncoding] options:0 error:nil]);
    // Refuse a staging symlink without modifying its target.
    NSString *victim=[@OB_LOG_FILE stringByAppendingString:@".victim"];
    [@"untouched" writeToFile:victim atomically:YES encoding:NSUTF8StringEncoding error:nil];
    assert(symlink(victim.fileSystemRepresentation,OB_LOG_EXPORT_TEMP)==0);
    assert(![command(@"export")[@"OK"] boolValue]);
    assert([[NSString stringWithContentsOfFile:victim encoding:NSUTF8StringEncoding error:nil] isEqual:@"untouched"]);
    unlink(OB_LOG_EXPORT_TEMP);assert([command(@"clear")[@"OK"] boolValue]);assert(OBEnabled());
    for(unsigned i=0;i<50 && ![OBLogState()[@"Full"] boolValue];++i)command(@"mark");
    assert([OBLogState()[@"Full"] boolValue] && [OBLogState()[@"Bytes"] unsignedLongLongValue]<=OB_LOG_LIMIT);
    assert([command(@"export")[@"OK"] boolValue]);
    exported=[NSString stringWithContentsOfFile:@OB_LOG_EXPORT_FILE encoding:NSUTF8StringEncoding error:nil];
    assert(![exported containsString:@"before_restart"] && [exported containsString:@"user_clear"]);
    assert([exported containsString:@"no_detected_record_loss_in_this_process\":false"] || [exported containsString:@"no_detected_record_loss_in_this_process\": false"]);
    assert([command(@"clear")[@"OK"] boolValue]);assert(![OBLogState()[@"Full"] boolValue] && OBEnabled());
    puts("PASS: real Foundation journal recovery, mark/exported/clear, privacy, symlink denial, saturation and continued reception (stub receiver, NOT iPhone validation)");
}}
