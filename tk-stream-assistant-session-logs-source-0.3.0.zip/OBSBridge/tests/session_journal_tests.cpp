#include "../core/SessionJournal.hpp"
#include <cassert>
#include <cstring>
#include <iostream>
int main() {
    {
        FILE *f=std::tmpfile();assert(f);obs::SessionJournal j(f,0,12);
        assert(j.append("{\"a\":1}\n"));assert(j.bytes()==8);
        assert(!j.append("{\"b\":2}\n"));assert(j.full && j.dropped==1 && j.bytes()==8);
        FILE *out=std::tmpfile();assert(out && j.copyTo(out));std::rewind(out);char b[20]{};
        assert(std::fread(b,1,sizeof(b),out)==8 && !std::strcmp(b,"{\"a\":1}\n"));std::fclose(out);
    }
    {
        FILE *f=std::tmpfile();assert(f);const char *old="{\"before\":1}\n";
        assert(std::fwrite(old,1,std::strlen(old),f)==std::strlen(old));std::fflush(f);
        obs::SessionJournal j(f,std::strlen(old),200000);
        assert(j.append("{\"after\":2}\n"));
        for(unsigned i=0;i<2000;++i)assert(j.append("{\"tick\":123456789012345678901234567890}\n"));
        FILE *out=std::tmpfile();assert(out && j.copyTo(out));
        assert(std::ftell(out)==long(j.bytes()));std::rewind(out);char b[14]{};
        assert(std::fread(b,1,std::strlen(old),out)==std::strlen(old));assert(!std::strcmp(b,old));std::fclose(out);
        assert(j.append("{\"after_export\":true}\n")); // writer continues after stable export
    }
    {
        FILE *f=std::tmpfile();assert(f);obs::SessionJournal j(f,0,200000);
        assert(!j.append("not terminated"));assert(j.errors==1 && j.dropped==1);
        assert(!j.append("bad\nextra\n"));assert(!j.append(std::string(20000,'x')+'\n'));
        assert(j.bytes()==0 && j.errors==3);
    }
    {
        obs::SessionJournal j(nullptr,0,100);assert(!j.append("{}\n"));assert(!j.copyTo(nullptr));assert(j.dropped==1);
        FILE *f=std::tmpfile();assert(f);obs::SessionJournal oversized(f,101,100);
        assert(!oversized.append("{}\n") && oversized.full && oversized.bytes()==101);
    }
    std::cout<<"PASS: bounded append, cap preserves beginning, restart append, multi-block export, resume after export, malformed records, null and oversize guards (NOT phone validation)\n";
}
