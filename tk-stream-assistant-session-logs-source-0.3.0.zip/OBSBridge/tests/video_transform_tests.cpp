#ifdef NDEBUG
#undef NDEBUG
#endif
#include "../core/VideoTransform.hpp"
#include "../core/RtmpPull.hpp"
#include <cassert>
#include <iostream>
#include <limits>
int main(){
    obs::VideoTransform t;t.zoom=2.53;t.x=-.753;t.y=.999;t.left=.12;t.right=.3;t.top=.45;
    auto copy=obs::VideoTransform::decode(t.position(),t.crop());assert(std::abs(copy.zoom-t.zoom)<.001);
    assert(copy.position()==t.position() && copy.crop()==t.crop());
    assert(obs::outputOrientation(1920,1080,false)==8);assert(obs::outputOrientation(1080,1920,false)==1);
    t.landscape=true;assert(obs::VideoTransform::decode(t.position(),t.crop()).landscape);
    for(int w: {100,360,540,1280,1920})for(int h:{100,360,960,1080,1920})for(double z:{1.,2.,4.})for(double x:{-1.,0.,1.})for(double y:{-1.,0.,1.}){
        t.zoom=z;t.x=x;t.y=y;auto g=obs::fillGeometry(w,h,540,960,t);
        assert(g.tx<=.001 && g.ty<=.001);assert(g.tx+w*g.scale>=540-.001 && g.ty+h*g.scale>=960-.001);
    }
    t.zoom=INFINITY;t.left=.99;t.right=-1;t.normalize();assert(t.zoom==1 && t.left==.45 && t.right==0);
    auto url=obs::RtmpURL::parse("rtmp://192.168.1.2:1935/live/phone01-abcd");assert(url.app=="live" && url.stream=="phone01-abcd");
    for(const char *bad:{"https://192.168.1.2/x/y","rtmp://name:1935/live/x","rtmp://192.168.1.2:0/live/x","rtmp://192.168.1.2/live/../x","rtmp://192.168.1.2/live/x?auth=secret"}){
        bool failed=false;try{(void)obs::RtmpURL::parse(bad);}catch(...){failed=true;}assert(failed);
    }
    std::cout<<"PASS transform roundtrip, 675 fills/pans with no uncovered borders, clamps and RTMP URL rejection\n";
}
