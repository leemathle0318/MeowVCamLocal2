#ifdef NDEBUG
#undef NDEBUG
#endif
#include "../core/AudioContinuity.hpp"
#include "../core/SharedMedia.hpp"
#include "../core/LiveAudio.hpp"
#include "../core/PresentationClock.hpp"
#include <cassert>
#include <cstdio>
#include <memory>
#include <vector>
#include <mutex>
#include <thread>
#include <future>
#include <chrono>

int main() {
    auto bus = std::make_unique<obs::SharedMedia>();
    bus->initialize(); bus->enabled = 1; bus->generation = 1; bus->heartbeatUS = 10000000;
    float source[480], out[480]; uint8_t valid[480];
    std::fill(source, source + 480, .25f);
    obs::AudioReadCoverage c;
    assert(!bus->readAudio(out, 480, 10, 48000, 10000000, &c, valid));
    assert(c.requested == 480 && !c.found && c.longestGap == 480);
    bus->writeAudio(source, 120, 10);
    bus->writeAudio(source, 120, 10.005);
    assert(bus->readAudio(out, 480, 10, 48000, 10000000, &c, valid));
    assert(c.found >= 238 && c.found <= 240);
    assert(c.headGap == 0 && c.tailGap >= 119 && c.longestGap >= 119);
    assert(valid[60] && !valid[180] && valid[300] && !valid[450]);
    obs::AudioGapMeter meter;
    meter.observe({480, 240, 0, 120, 120});
    meter.observe({480, 0, 480, 480, 480});
    meter.observe({480, 240, 120, 0, 120});
    assert(meter.longest == 720 && meter.trailing == 0);
    std::fill(source, source + 480, 0.f); bus->resetAudio(); bus->writeAudio(source,480,10);
    assert(bus->readAudio(out,480,10,48000,10000000,&c,valid)); // real digital silence is valid, not underrun
    bus->generation = 2; bus->resetAudio();
    assert(!bus->readAudio(out,480,10,48000,10000000,&c,valid));
    assert(c.found == 0);

    obs::AudioEdgeRamp ramp;
    std::vector<float> samples(480, .5f); std::vector<uint8_t> mask(480, 1);
    assert(ramp.apply(samples.data(),mask.data(),480,48000));
    assert(samples.front() > 0 && samples.front() < .02f && std::abs(samples.back()-.5f)<1e-6);
    samples.assign(480, .5f); ramp.apply(samples.data(),mask.data(),480,48000);
    for (float v : samples) assert(std::abs(v-.5f)<1e-6); // full healthy blocks retain unity program gain
    samples.assign(480,0); mask.assign(480,0);
    assert(ramp.apply(samples.data(),mask.data(),480,48000));
    assert(samples.front() < .5f && samples.front() > .48f);
    for (size_t i=48;i<480;++i) assert(samples[i] == 0); // bounded <=1ms tail, no old block repetition
    samples.assign(480,0); assert(!ramp.apply(samples.data(),mask.data(),480,48000));
    samples.assign(480,.5f); mask.assign(480,1); ramp.apply(samples.data(),mask.data(),480,48000);
    assert(samples.front() < .02f && samples.back() == .5f);
    // Within-block holes are tapered on both sides, without touching timestamps.
    samples.assign(480,.5f); mask.assign(480,1);
    for (size_t i=120;i<240;++i) mask[i]=0;
    ramp.apply(samples.data(),mask.data(),480,48000);
    assert(samples[119] < .02f && samples[200] == 0 && samples[240] < .02f);
    ramp.reset(); samples.assign(480,0);mask.assign(480,0);
    assert(!ramp.apply(samples.data(),mask.data(),480,48000)); // never leak a previous session tail

    obs::PullIdentity pull;
    size_t advanced = 0;
    for (unsigned i=0;i<500;++i) {
        assert(pull.claim(true, i*480.,true,i+1,480,2)); advanced += 480;
        assert(!pull.claim(true,i*480.,true,i+1,480,2)); // failure still reserves this identity
    }
    assert(advanced == 240000);
    assert(pull.claim(true,0,true,1,480,4)); // changed native format version is new input

    // Model the actual two-phase critical section. Hold video preparation until
    // the audio writer has acquired the receive lock; old long-lock flow fails.
    std::mutex clock;
    std::promise<void> staged, proceed;
    auto stageReady=staged.get_future(); auto finish=proceed.get_future();
    uint64_t generation=9, epoch=3; bool committed=true;
    std::thread video([&] {
        uint64_t g,e;
        { std::lock_guard<std::mutex> lock(clock); g=generation;e=epoch; }
        staged.set_value();
        assert(finish.wait_for(std::chrono::seconds(3)) == std::future_status::ready);
        { std::lock_guard<std::mutex> lock(clock); committed=obs::publicationCurrent(g,e,generation,epoch,true); }
    });
    stageReady.wait();
    assert(clock.try_lock()); ++epoch; clock.unlock(); // shared A/V rebase during slow rendering
    proceed.set_value();video.join();assert(!committed);
    assert(!obs::publicationCurrent(9,3,10,3,true)); // stop/start
    assert(!obs::publicationCurrent(9,3,9,3,false)); // explicit stop
    assert(obs::publicationCurrent(9,3,9,3,true));

    // Reproduce the previous blind spot: a persistent 280ms arrival shift
    // leaves 21ms AAC blocks 100ms behind real-time. The old -250ms admission
    // window labels every block healthy, so no amount of waiting fills NOW.
    obs::PresentationClock recovery;
    auto anchored=recovery.schedule(0,100,false,true); assert(!anchored.rebased);
    unsigned oldUnreadable=0, recovered=0, late=0;
    for (unsigned block=1;block<=80;++block) {
        double pts=block*1024./48000., now=100.+pts+.280;
        double previousDue=100.+.180+pts;
        if (previousDue+1024./48000. < now) ++oldUnreadable;
        auto audio=recovery.schedule(pts,now,false,true);
        if(audio.rebased)++recovered;
        if(audio.due+1024./48000.<now)++late;
        auto videoFrame=recovery.schedule(pts,now,true,true);
        assert(std::abs(audio.due-videoFrame.due)<1e-8); // never retime audio alone
    }
    assert(oldUnreadable==80 && recovered==1 && late<16);

    // Both tracks continue to share the same mapping through an hour of 30fps
    // presentation scheduling; ramp/coverage logic never retimes source media.
    obs::PresentationClock presentation;
    for (unsigned frame=0;frame<108000;++frame) {
        double pts=frame/30.; double now=100.+pts;
        auto v=presentation.schedule(pts,now,true,true);
        auto a=presentation.schedule(pts,now,false,true);
        assert(!v.rebased && !a.rebased && std::abs(v.due-a.due)<1e-8);
    }
    std::puts("PASS: full/partial/missing/silent PCM coverage; cross-block gaps; bounded 1ms ramps/session reset; 500 duplicate failed pulls; unlocked slow-video staging/obsolete epoch rejection; late-audio deadband old=80/80 missed, shared recovery=1; 1h shared AV clock model (not iPhone runtime)");
}
