#ifdef NDEBUG
#undef NDEBUG
#endif
#include "../core/CommonPresentationClock.hpp"
#include <cassert>
#include <cstdio>
using namespace obs::next;
static void longClock(double ppm,bool millisecond) {
    CommonPresentationClock clock;double low=1e30,high=-1e30;unsigned resets=0;
    constexpr unsigned blocks=24*3600*50;
    for(unsigned n=0;n<blocks;++n) {
        double actual=n*.020,pts=millisecond?std::round(actual*1000.)/1000.:actual;
        double now=1000.+actual/(1.+ppm/1e6)+double(n%7)*.0005;
        double before=clock.map(pts);
        auto result=clock.schedule(pts,now,false,true);resets+=result.rebased;
        if(n>1000){low=std::min(low,result.due-now);high=std::max(high,result.due-now);}
        if(std::isfinite(before) && !result.rebased)assert(std::abs(before-result.due)<1e-8);
        assert(std::abs(clock.schedule(pts,now,true,true).due-result.due)<1e-8);
    }
    assert(resets==0 && clock.stats.fits>10000 && low>.100 && high<.260);
    std::printf("PASS 24h accelerated shared AV mapping: source=%+.0fppm lead=[%.3f,%.3f]ms resets=%u applied=%+.3fppm\n",ppm,low*1000.,high*1000.,resets,clock.stats.ratePPM);
}
static void tcpBurstClock() {
    CommonPresentationClock clock;double low=1e30,high=-1e30,previous=0;unsigned resets=0;
    for(uint64_t n=0;n<3600*50;++n) {
        double pts=n*.020;
        uint64_t random=n*6364136223846793005ULL+1442695040888963407ULL;
        double jitter=double((random>>32)%80001)/1e6;
        double now=std::max(previous+.000001,1000.+pts/1.0005+jitter);previous=now;
        auto result=clock.schedule(pts,now,false,true);resets+=result.rebased;
        if(n>1000){low=std::min(low,result.due-now);high=std::max(high,result.due-now);}
    }
    std::printf("TCP-like ordered 0..80ms arrival bursts: 1h lead=[%.3f,%.3f]ms resets=%u fits=%llu rejected=%llu\n",low*1000.,high*1000.,resets,
        (unsigned long long)clock.stats.fits,(unsigned long long)clock.stats.rejectedFits);
    assert(resets==0 && low>.070 && high<.300 && clock.stats.fits>100);
}
int main() {
    for(double ppm:{-500.,-100.,100.,500.})longClock(ppm,true);
    tcpBurstClock();
    CommonPresentationClock clock;
    assert(clock.schedule(0,100.,false,true).due==100.18);
    assert(clock.schedule(1.,100.01,false,true).rebased); // actual startup backlog
    assert(clock.schedule(2.,101.01,false,true).rebased==false);
    assert(clock.schedule(0.,102.01,false,true).rebased); // actual source timeline restart
    assert(!std::isfinite(clock.schedule(NAN,103.,false,true).due));
    std::puts("PASS startup backlog / actual PTS restart / invalid input; no periodic duration-based reset");
}
