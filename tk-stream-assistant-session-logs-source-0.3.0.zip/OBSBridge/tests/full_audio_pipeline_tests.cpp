#ifdef NDEBUG
#undef NDEBUG
#endif
#include "../core/CommonPresentationClock.hpp"
#include "../core/CaptureOutputWorker.hpp"
#include "../core/SharedMedia.hpp"
#include "../core/HostPCMRead.hpp"
#include <cassert>
#include <cstdio>
#include <memory>
#include <cstdlib>
using namespace obs::next;
static void pipeline(int sourceRate,int nativeRate,double sourcePPM,double nativePPM,double seconds,bool bursty=false,double latencyPPM=0) {
    auto media=std::make_unique<obs::SharedMedia>();media->initialize();media->enabled=1;media->generation=2;
    CommonPresentationClock common;
    auto decoder=std::make_unique<FFmpegAudioTimeline>();AVChannelLayout mono=AV_CHANNEL_LAYOUT_MONO;
    assert(decoder->configure(sourceRate,AV_SAMPLE_FMT_FLT,mono,1));
    auto worker=std::make_unique<CaptureOutputWorker>();CaptureClockTracker capture;CaptureReportSource reporter;CaptureReportQueue<> reports;
    std::array<float,1024> source{};std::array<float,8192> converted{},native{};std::array<uint8_t,8192> validity{};
    constexpr unsigned frames=1024;constexpr double pi=3.141592653589793,frequency=17.;
    uint64_t si=0,ni=0,requested=0,missing=0;unsigned tick=0,resets=0;
    double sourceRatio=1.+sourcePPM/1e6,nativeRatio=1.+nativePPM/1e6,now=1000.,sumSin=0,sumCos=0,maxPhase=0;
    uint64_t windowSamples=0;double previousSource=0;
    while(now<1000.+seconds) {
        uint64_t random=si*6364136223846793005ULL+1442695040888963407ULL;
        double jitter=bursty?double((random>>32)%80001)/1e6:double(si%7)*.0002;
        double st=std::max(previousSource+.000001,1000.+double(si)*frames/sourceRate/sourceRatio+jitter);
        double nh=1000.+double(ni)*frames/nativeRate/nativeRatio;
        double latency=(nh-1000.)*latencyPPM/1e6;
        double nt=nh+.003+latency+double(ni%5)*.00003,bt=1000.+tick*.005;
        now=std::min({st,nt,bt});media->heartbeatUS=uint64_t(now*1e6);
        if(st<=nt && st<=bt) {
            previousSource=st;
            double pts=std::round(double(si)*frames/sourceRate*1000.)/1000.;
            auto scheduled=common.schedule(pts,now,false,true);resets+=scheduled.rebased;
            for(unsigned i=0;i<frames;++i)source[i]=float(.2*std::sin(2*pi*frequency*(double(si*frames+i)/sourceRate)));
            const uint8_t *planes[]={reinterpret_cast<const uint8_t *>(source.data())};
            assert(decoder->push(planes,1,frames,scheduled.due,1)==AudioEngineResult::Ok);
            while(decoder->available()) {
                AudioEngineBlock block;assert(decoder->pop(converted.data(),int(converted.size()),block)==AudioEngineResult::Ok);
                media->writeAudio(converted.data(),size_t(block.frames),block.masterTime);
            }
            ++si;
        } else if(nt<=bt) {
            CaptureReport r;r.cookie=123;r.unit=1;r.generation=2;r.formatVersion=4;r.frames=frames;
            r.hasSample=r.hasHost=true;r.sampleTime=10000.+double(ni)*frames;r.hostTime=nh;r.callbackTime=nt;r.nominalRate=nativeRate;
            CaptureReport ticket;assert(reporter.offer(reports,r,&ticket));
            PreparedContext context{123,1,ticket.captureRevision,2,4,uint32_t(nativeRate)};obs::AudioReadCoverage coverage;
            worker->prepared()->read(context,ticket.framePosition,native.data(),validity.data(),frames,uint64_t(now*1e6),coverage);
            if(now>1001.) {
                requested+=coverage.requested;missing+=coverage.requested-coverage.found;
                for(unsigned i=0;i<frames;++i) {
                    assert(std::isfinite(native[i]) && std::abs(native[i])<.3);
                    double host=nh+.003+latency+double(i)/nativeRate/nativeRatio;
                    double phase=2*pi*frequency*common.sourceForHost(host);
                    sumSin+=native[i]*std::sin(phase);sumCos+=native[i]*std::cos(phase);++windowSamples;
                }
                if(windowSamples>=uint64_t(nativeRate)) {
                    maxPhase=std::max(maxPhase,std::abs(std::atan2(sumCos,sumSin)/(2*pi*frequency)));
                    windowSamples=0;sumSin=sumCos=0;
                }
            }
            ++ni;
        } else {
            CaptureReport report;while(reports.pop(report))capture.observe(report);
            worker->tick(capture,now,[&](float *out,size_t count,double host) {
                return copyHostPCM48(*media,out,count,host,uint64_t(now*1e6));
            });++tick;
        }
    }
    std::printf("pipeline source=%d/%+.0fppm native=%d/%+.0fppm missing=%llu/%llu AVphaseMax=%.3fms mapResets=%u workerResets=%llu errors=%llu bursty=%d latencyCreep=%.0fppm\n",
        sourceRate,sourcePPM,nativeRate,nativePPM,(unsigned long long)missing,(unsigned long long)requested,maxPhase*1000.,resets,
        (unsigned long long)worker->stats.rebuffers,(unsigned long long)worker->stats.failed,int(bursty),latencyPPM);std::fflush(stdout);
    assert(requested && !missing && resets==0 && worker->stats.failed==0 && worker->stats.rebuffers<=(bursty?3u:2u) && maxPhase<.005);
}
int main(int argc,char **argv){
    double seconds=argc>1?std::strtod(argv[1],nullptr):120.;
    assert(std::isfinite(seconds) && seconds>=2 && seconds<=86400);
    bool onlyCreep=argc>2 && std::strcmp(argv[2],"creep")==0;
    if(!onlyCreep)pipeline(44100,48000,500.,-500.,seconds);
    if(argc<=2)pipeline(48000,44100,-500.,500.,seconds);
    if(argc<=2)pipeline(48000,48000,500.,-500.,seconds,true);
    if(argc<=2)pipeline(48000,48000,-100.,100.,seconds,false,100.);
    if(onlyCreep || (argc>2 && std::strcmp(argv[2],"both")==0))pipeline(48000,48000,-100.,100.,seconds,false,10.);
    std::puts("PASS actual two-stage SWR + shared host PCM + native prepared ring, modeled IO and callback jitter; not iPhone/live audience validation");
}
