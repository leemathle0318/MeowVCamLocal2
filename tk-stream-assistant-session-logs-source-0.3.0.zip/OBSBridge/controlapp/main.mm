#import <UIKit/UIKit.h>
#import <AVFoundation/AVFoundation.h>
#import "../Client.h"
#import "LogExport.h"
#include <arpa/inet.h>

@interface OBScan : UIViewController <AVCaptureMetadataOutputObjectsDelegate>
@property(nonatomic,strong) AVCaptureSession *session;
@property(nonatomic,strong) AVCaptureVideoPreviewLayer *layer;
@property(nonatomic,copy) void (^found)(NSString *);
@end
@implementation OBScan
- (void)viewDidLoad {
    [super viewDidLoad];self.view.backgroundColor=UIColor.blackColor;self.title=@"扫描电脑视频通道二维码";
    self.navigationItem.leftBarButtonItem=[[UIBarButtonItem alloc] initWithTitle:@"取消" style:UIBarButtonItemStylePlain target:self action:@selector(cancel)];
    [AVCaptureDevice requestAccessForMediaType:AVMediaTypeVideo completionHandler:^(BOOL granted){
        dispatch_async(dispatch_get_main_queue(),^{
            if(!granted){[self cancel];return;}
            self.session=[AVCaptureSession new];self.session.sessionPreset=AVCaptureSessionPreset640x480;
            NSError *error=nil;AVCaptureDeviceInput *input=[AVCaptureDeviceInput deviceInputWithDevice:[AVCaptureDevice defaultDeviceWithMediaType:AVMediaTypeVideo] error:&error];
            AVCaptureMetadataOutput *output=[AVCaptureMetadataOutput new];
            if(!input || ![self.session canAddInput:input] || ![self.session canAddOutput:output]){[self cancel];return;}
            [self.session addInput:input];[self.session addOutput:output];[output setMetadataObjectsDelegate:self queue:dispatch_get_main_queue()];
            if(![output.availableMetadataObjectTypes containsObject:AVMetadataObjectTypeQRCode]){[self cancel];return;}
            output.metadataObjectTypes=@[AVMetadataObjectTypeQRCode];
            self.layer=[AVCaptureVideoPreviewLayer layerWithSession:self.session];self.layer.videoGravity=AVLayerVideoGravityResizeAspectFill;
            [self.view.layer addSublayer:self.layer];self.layer.frame=self.view.bounds;
            AVCaptureSession *session=self.session;dispatch_async(dispatch_get_global_queue(QOS_CLASS_USER_INITIATED,0),^{[session startRunning];});
        });
    }];
}
- (void)viewDidLayoutSubviews {[super viewDidLayoutSubviews];self.layer.frame=self.view.bounds;}
- (void)cancel {[self dismissViewControllerAnimated:YES completion:nil];}
- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];AVCaptureSession *session=self.session;
    dispatch_async(dispatch_get_global_queue(QOS_CLASS_USER_INITIATED,0),^{[session stopRunning];});
}
- (void)captureOutput:(AVCaptureOutput *)output didOutputMetadataObjects:(NSArray *)objects fromConnection:(AVCaptureConnection *)connection {
    (void)output;(void)connection;
    for(AVMetadataObject *object in objects)if([object isKindOfClass:AVMetadataMachineReadableCodeObject.class]){
        NSString *text=((AVMetadataMachineReadableCodeObject *)object).stringValue;
        if(text.length && self.found){void (^found)(NSString *)=self.found;self.found=nil;[self dismissViewControllerAnimated:YES completion:^{found(text);}];break;}
    }
}
@end

@interface OBSettings : UIViewController
@property(nonatomic,strong) UITextField *address;
@property(nonatomic,strong) UITextField *peer;
@property(nonatomic,strong) UISegmentedControl *pages;
@property(nonatomic,strong) UISegmentedControl *transport;
@property(nonatomic,strong) UISegmentedControl *quality;
@property(nonatomic,strong) UILabel *summary;
@property(nonatomic,strong) UIStackView *connectPanel;
@property(nonatomic,strong) UIStackView *contentStack;
@property(nonatomic,strong) UIStackView *activePanel;
@property(nonatomic,strong) UIButton *cropToggle;
@property(nonatomic,strong) UIStackView *adjustPanel;
@property(nonatomic,strong) UIStackView *statusPanel;
@property(nonatomic,strong) UIStackView *rtmpFields;
@property(nonatomic,strong) UIStackView *obsFields;
@property(nonatomic,strong) UIStackView *cropFields;
@property(nonatomic,strong) UIButton *startButton;
@property(nonatomic,strong) UILabel *status;
@property(nonatomic,strong) NSMutableDictionary *values;
@property(nonatomic,strong) NSMutableDictionary<NSString *,UISlider *> *sliders;
@property(nonatomic,strong) NSTimer *timer;
@property(nonatomic) CFTimeInterval lastStatusUpdate;
@property(nonatomic,strong) UILabel *logSummary;
@property(nonatomic,strong) NSMutableArray<UIButton *> *logButtons;
@property(nonatomic) BOOL logBusy;
@end
@implementation OBSettings
- (void)message:(NSString *)text {
    UIAlertController *a=[UIAlertController alertControllerWithTitle:@"tk直播推流助手" message:text preferredStyle:UIAlertControllerStyleAlert];
    [a addAction:[UIAlertAction actionWithTitle:@"知道了" style:UIAlertActionStyleCancel handler:nil]];[self presentViewController:a animated:YES completion:nil];
}
- (UIButton *)button:(NSString *)title selector:(SEL)selector {
    UIButton *b=[UIButton buttonWithType:UIButtonTypeSystem];[b setTitle:title forState:UIControlStateNormal];
    [b addTarget:self action:selector forControlEvents:UIControlEventTouchUpInside];
    NSLayoutConstraint *height=[b.heightAnchor constraintGreaterThanOrEqualToConstant:44];height.priority=999;height.active=YES;return b;
}
- (UILabel *)label:(NSString *)text detail:(BOOL)detail {
    UILabel *label=[UILabel new];label.text=text;label.numberOfLines=0;
    label.font=[UIFont preferredFontForTextStyle:detail?UIFontTextStyleFootnote:UIFontTextStyleHeadline];
    label.textColor=detail?UIColor.secondaryLabelColor:UIColor.labelColor;
    label.adjustsFontForContentSizeCategory=YES;return label;
}
- (UIStackView *)panel {
    UIStackView *panel=[UIStackView new];panel.axis=UILayoutConstraintAxisVertical;panel.spacing=12;
    panel.layoutMargins=UIEdgeInsetsMake(16,16,16,16);panel.layoutMarginsRelativeArrangement=YES;
    panel.backgroundColor=UIColor.secondarySystemGroupedBackgroundColor;panel.layer.cornerRadius=12;return panel;
}
- (void)viewDidLoad {
    [super viewDidLoad];self.title=@"tk直播推流助手";self.view.backgroundColor=UIColor.systemGroupedBackgroundColor;
    self.navigationItem.rightBarButtonItem=[[UIBarButtonItem alloc] initWithTitle:@"帮助" style:UIBarButtonItemStylePlain target:self action:@selector(help)];
    self.values=[@{@"zoom":@1,@"x":@0,@"y":@0,@"left":@0,@"right":@0,@"top":@0,@"bottom":@0} mutableCopy];
    [self.values addEntriesFromDictionary:OBCTransform()];self.sliders=[NSMutableDictionary dictionary];
    UIScrollView *scroll=[UIScrollView new];scroll.translatesAutoresizingMaskIntoConstraints=NO;[self.view addSubview:scroll];
    UIStackView *stack=[UIStackView new];stack.axis=UILayoutConstraintAxisVertical;stack.spacing=16;stack.translatesAutoresizingMaskIntoConstraints=NO;[scroll addSubview:stack];
    [NSLayoutConstraint activateConstraints:@[
        [scroll.leadingAnchor constraintEqualToAnchor:self.view.safeAreaLayoutGuide.leadingAnchor],[scroll.trailingAnchor constraintEqualToAnchor:self.view.safeAreaLayoutGuide.trailingAnchor],
        [scroll.topAnchor constraintEqualToAnchor:self.view.safeAreaLayoutGuide.topAnchor],[scroll.bottomAnchor constraintEqualToAnchor:self.view.safeAreaLayoutGuide.bottomAnchor],
        [stack.leadingAnchor constraintEqualToAnchor:scroll.contentLayoutGuide.leadingAnchor constant:16],[stack.trailingAnchor constraintEqualToAnchor:scroll.contentLayoutGuide.trailingAnchor constant:-16],
        [stack.topAnchor constraintEqualToAnchor:scroll.contentLayoutGuide.topAnchor constant:12],[stack.bottomAnchor constraintEqualToAnchor:scroll.contentLayoutGuide.bottomAnchor constant:-20],
        [stack.widthAnchor constraintEqualToAnchor:scroll.frameLayoutGuide.widthAnchor constant:-32]]];
    self.summary=[self label:@"等待接收状态" detail:YES];[stack addArrangedSubview:self.summary];
    self.pages=[[UISegmentedControl alloc] initWithItems:@[@"连接",@"画面",@"状态"]];self.pages.selectedSegmentIndex=0;
    [self.pages addTarget:self action:@selector(pageChanged) forControlEvents:UIControlEventValueChanged];[stack addArrangedSubview:self.pages];
    self.connectPanel=[self panel];self.adjustPanel=[self panel];self.statusPanel=[self panel];
    self.contentStack=stack;
    [self.connectPanel addArrangedSubview:[self label:@"视频来源" detail:NO]];
    self.transport=[[UISegmentedControl alloc] initWithItems:@[@"RTMP",@"OBS / TCP"]];
    self.transport.selectedSegmentIndex=[OBCInputMode() isEqual:@"RTMP"]?0:1;
    [self.transport addTarget:self action:@selector(transportChanged) forControlEvents:UIControlEventValueChanged];[self.connectPanel addArrangedSubview:self.transport];
    self.rtmpFields=[UIStackView new];self.rtmpFields.axis=UILayoutConstraintAxisVertical;self.rtmpFields.spacing=10;[self.connectPanel addArrangedSubview:self.rtmpFields];
    self.address=[UITextField new];self.address.placeholder=@"rtmp://电脑IP:1935/live/通道";self.address.text=OBCRtmpURL();self.address.borderStyle=UITextBorderStyleRoundedRect;
    self.address.autocorrectionType=UITextAutocorrectionTypeNo;self.address.autocapitalizationType=UITextAutocapitalizationTypeNone;self.address.accessibilityLabel=@"RTMP地址";[self.rtmpFields addArrangedSubview:self.address];
    UIStackView *pairRow=[UIStackView new];pairRow.axis=UILayoutConstraintAxisHorizontal;pairRow.distribution=UIStackViewDistributionFillEqually;pairRow.spacing=12;
    [pairRow addArrangedSubview:[self button:@"扫码配对" selector:@selector(scan)]];[pairRow addArrangedSubview:[self button:@"粘贴配对码" selector:@selector(paste)]];[self.rtmpFields addArrangedSubview:pairRow];
    self.obsFields=[UIStackView new];self.obsFields.axis=UILayoutConstraintAxisVertical;self.obsFields.spacing=10;[self.connectPanel addArrangedSubview:self.obsFields];
    self.peer=[UITextField new];self.peer.placeholder=@"OBS电脑IPv4";self.peer.text=OBCPeerIP();self.peer.borderStyle=UITextBorderStyleRoundedRect;
    self.peer.autocorrectionType=UITextAutocorrectionTypeNo;self.peer.keyboardType=UIKeyboardTypeNumbersAndPunctuation;self.peer.accessibilityLabel=@"OBS电脑IP";[self.obsFields addArrangedSubview:self.peer];
    [self.obsFields addArrangedSubview:[self button:@"复制手机TCP地址" selector:@selector(copyTCP)]];
    self.startButton=[self button:@"开始接收" selector:@selector(start)];self.startButton.backgroundColor=UIColor.systemBlueColor;self.startButton.layer.cornerRadius=10;
    [self.startButton setTitleColor:UIColor.whiteColor forState:UIControlStateNormal];[self.connectPanel addArrangedSubview:self.startButton];
    UIButton *stop=[self button:@"停止替换" selector:@selector(stop)];[stop setTitleColor:UIColor.systemRedColor forState:UIControlStateNormal];[self.connectPanel addArrangedSubview:stop];
    [self.connectPanel addArrangedSubview:[self label:@"停止后恢复真实摄像头。直播中不要扫码重新配对。" detail:YES]];
    [self.connectPanel addArrangedSubview:[self label:@"画质（OBS 与 RTMP 共用）" detail:NO]];
    self.quality=[[UISegmentedControl alloc] initWithItems:@[@"省电",@"均衡",@"源画质"]];self.quality.selectedSegmentIndex=OBCVideoProfile();
    [self.quality addTarget:self action:@selector(qualityChanged) forControlEvents:UIControlEventValueChanged];[self.connectPanel addArrangedSubview:self.quality];
    [self.connectPanel addArrangedSubview:[self label:@"源画质最高1080p/60fps，不补帧；过热自动保护。最终直播画质由目标App决定。" detail:YES]];
    UIStackView *audioRow=[UIStackView new];audioRow.axis=UILayoutConstraintAxisHorizontal;audioRow.alignment=UIStackViewAlignmentCenter;
    [audioRow addArrangedSubview:[self label:@"OBS声音＋手机麦克风" detail:NO]];UISwitch *audio=[UISwitch new];audio.on=OBCLiveAudioEnabled();
    [audio addTarget:self action:@selector(audioChanged:) forControlEvents:UIControlEventValueChanged];[audioRow addArrangedSubview:audio];[self.connectPanel addArrangedSubview:audioRow];
    [self.adjustPanel addArrangedSubview:[self label:@"打开手机相机或直播画面，使用下方滑块调整。" detail:YES]];
    NSArray *keys=@[@"zoom",@"x",@"y",@"left",@"right",@"top",@"bottom"];
    NSArray *names=@[@"缩放",@"左右位置",@"上下位置",@"裁剪左侧",@"裁剪右侧",@"裁剪顶部",@"裁剪底部"];
    self.cropFields=[UIStackView new];self.cropFields.axis=UILayoutConstraintAxisVertical;self.cropFields.spacing=8;
    for(NSUInteger i=0;i<keys.count;++i){
        UIStackView *parent=i<3?self.adjustPanel:self.cropFields;
        [parent addArrangedSubview:[self label:names[i] detail:YES]];
        UISlider *slider=[UISlider new];slider.tag=(NSInteger)i;slider.minimumValue=i==0?1:(i<3?-1:0);slider.maximumValue=i==0?4:(i<3?1:.45);
        slider.value=[self.values[keys[i]] floatValue];slider.accessibilityLabel=names[i];
        [slider addTarget:self action:@selector(slider:) forControlEvents:UIControlEventValueChanged];self.sliders[keys[i]]=slider;[parent addArrangedSubview:slider];
    }
    self.cropToggle=[self button:@"边缘裁剪" selector:@selector(toggleCrop)];[self.adjustPanel addArrangedSubview:self.cropToggle];self.cropFields.hidden=YES;
    UIStackView *directionRow=[UIStackView new];directionRow.axis=UILayoutConstraintAxisHorizontal;directionRow.distribution=UIStackViewDistributionFillEqually;
    [directionRow addArrangedSubview:[self button:@"旋转90°" selector:@selector(rotate)]];[directionRow addArrangedSubview:[self button:@"竖屏 / 横屏" selector:@selector(outputDirection)]];[self.adjustPanel addArrangedSubview:directionRow];
    [self.adjustPanel addArrangedSubview:[self button:@"恢复画面默认值" selector:@selector(reset)]];
    [self.statusPanel addArrangedSubview:[self label:@"运行诊断" detail:NO]];
    [self.statusPanel addArrangedSubview:[self button:@"复制完整状态" selector:@selector(copyStatus)]];
    self.logSummary=[self label:@"正在读取日志状态" detail:YES];[self.statusPanel addArrangedSubview:self.logSummary];
    self.logButtons=[NSMutableArray array];
    NSArray *logTitles=@[@"标记卡顿",@"导出全程日志",@"清空诊断日志"];
    SEL logSelectors[]={@selector(markLog),@selector(exportLog),@selector(clearLog)};
    for(NSUInteger i=0;i<logTitles.count;++i){UIButton *b=[self button:logTitles[i] selector:logSelectors[i]];[self.logButtons addObject:b];[self.statusPanel addArrangedSubview:b];}
    [self.statusPanel addArrangedSubview:[self label:@"后台自动记录：接收时每5秒，未接收时每60秒；关闭此应用仍记录。仅诊断数字，不录音录像。最多128MB，满后停止记录并提示，不覆盖开头。" detail:YES]];
    self.status=[self label:@"等待状态" detail:YES];self.status.font=[UIFont monospacedSystemFontOfSize:12 weight:UIFontWeightRegular];[self.statusPanel addArrangedSubview:self.status];
    [self transportChanged];[self pageChanged];
    self.timer=[NSTimer scheduledTimerWithTimeInterval:.3 target:self selector:@selector(update) userInfo:nil repeats:YES];
}
- (void)help {[self message:@"OBS与RTMP共用画质、裁剪、方向和混音设置。视频输入H.264，音频AAC；兼容AAC 192 Kbps、48 kHz。TikTok账号用TikTok扫描电脑官方登录码，不用本插件扫码。源画质不保证目标App最终按同规格直播。"] ;}
- (void)pageChanged {
    UIStackView *chosen=self.pages.selectedSegmentIndex==0?self.connectPanel:self.pages.selectedSegmentIndex==1?self.adjustPanel:self.statusPanel;
    if(chosen!=self.activePanel){
        if(self.activePanel){[self.contentStack removeArrangedSubview:self.activePanel];[self.activePanel removeFromSuperview];}
        self.activePanel=chosen;[self.contentStack addArrangedSubview:chosen];
    }
}
- (void)transportChanged {
    for(UIStackView *fields in @[self.rtmpFields,self.obsFields]){[self.connectPanel removeArrangedSubview:fields];[fields removeFromSuperview];}
    [self.connectPanel insertArrangedSubview:self.transport.selectedSegmentIndex==0?self.rtmpFields:self.obsFields atIndex:2];
}
- (void)qualityChanged {NSString *error=OBCSetVideoProfile(self.quality.selectedSegmentIndex);if(error)[self message:error];}
- (void)audioChanged:(UISwitch *)sender {NSString *error=OBCSetLiveAudioEnabled(sender.on);if(error){sender.on=!sender.on;[self message:error];}}
- (void)toggleCrop {
    if(self.cropFields.hidden){
        self.cropFields.hidden=NO;NSUInteger index=[self.adjustPanel.arrangedSubviews indexOfObject:self.cropToggle];
        [self.adjustPanel insertArrangedSubview:self.cropFields atIndex:index+1];
    }else{[self.adjustPanel removeArrangedSubview:self.cropFields];[self.cropFields removeFromSuperview];self.cropFields.hidden=YES;}
}
- (void)copyTCP {NSString *url=OBCURL();if(url)UIPasteboard.generalPasteboard.string=url;[self message:url?:@"手机没有可用的Wi-Fi地址。"] ;}
- (void)copyStatus {UIPasteboard.generalPasteboard.string=self.status.text?:OBCStatus();[self message:@"完整状态已复制，可粘贴发送。"] ;}
- (void)markLog {[self logAction:@"mark"];}
- (void)exportLog {[self logAction:@"export"];}
- (void)clearLog {
    if(self.logBusy)return;
    UIAlertController *a=[UIAlertController alertControllerWithTitle:@"清空诊断日志？" message:@"只删除已记录的诊断历史并开始新日志，不会停止推流。请先导出要保留的日志。" preferredStyle:UIAlertControllerStyleAlert];
    [a addAction:[UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:nil]];
    [a addAction:[UIAlertAction actionWithTitle:@"清空" style:UIAlertActionStyleDestructive handler:^(UIAlertAction *x){(void)x;[self logAction:@"clear"];}]];
    [self presentViewController:a animated:YES completion:nil];
}
- (void)logAction:(NSString *)action {
    if(self.logBusy)return;
    self.logBusy=YES;for(UIButton *b in self.logButtons)b.enabled=NO;
    self.logSummary.text=[action isEqual:@"export"]?@"正在准备日志，请稍候；推流不受影响":@"正在提交日志操作";
    // Serialize this small config transaction with the existing main-thread
    // settings/start/stop actions. A background read-modify-write could restore
    // an older stream RequestID while the user changes another setting.
    NSString *request=NSUUID.UUID.UUIDString,*commandError=OBCLogCommand(action,request);
    if(commandError){self.logBusy=NO;for(UIButton *b in self.logButtons)b.enabled=YES;[self message:commandError];return;}
    dispatch_async(dispatch_get_global_queue(QOS_CLASS_UTILITY,0),^{@autoreleasepool{
        NSString *error=nil;NSURL *file=nil;
        if(!error) {
            CFTimeInterval deadline=CACurrentMediaTime()+40;BOOL acknowledged=NO;
            while(CACurrentMediaTime()<deadline) {
                NSDictionary *state=OBCLogStatus();
                if([state[@"Ack"] isEqual:request]) {
                    acknowledged=YES;
                    if(![state[@"OK"] boolValue])error=[NSString stringWithFormat:@"日志操作未完成（错误 %@）。查看日志状态；不会因此重启推流。",state[@"ErrorCode"]?:@0];
                    break;
                }
                [NSThread sleepForTimeInterval:.25];
            }
            if(!acknowledged)error=@"接收层未及时确认日志请求。请保留当前状态，稍后再试，不必停止推流。";
            if(!error && [action isEqual:@"export"])file=OBCopyLogExport(&error);
        }
        dispatch_async(dispatch_get_main_queue(),^{
            self.logBusy=NO;for(UIButton *b in self.logButtons)b.enabled=YES;
            if(error){[self message:error];return;}
            if(file) {
                UIActivityViewController *share=[[UIActivityViewController alloc] initWithActivityItems:@[file] applicationActivities:nil];
                share.popoverPresentationController.sourceView=self.view;
                share.popoverPresentationController.sourceRect=CGRectMake(CGRectGetMidX(self.view.bounds),CGRectGetMidY(self.view.bounds),1,1);
                share.completionWithItemsHandler=^(UIActivityType type,BOOL completed,NSArray *items,NSError *e){(void)type;(void)completed;(void)items;(void)e;
                    dispatch_async(dispatch_get_global_queue(QOS_CLASS_UTILITY,0),^{[NSFileManager.defaultManager removeItemAtURL:file error:nil];});
                };
                [self presentViewController:share animated:YES completion:nil];
            }else [self message:[action isEqual:@"mark"]?@"已标记卡顿并保存当时诊断。请再点“导出全程日志”，无需先重推。":@"诊断历史已清空，新的后台记录已开始；推流未停止。"];
        });
    }});
}
- (void)start {NSString *e=self.transport.selectedSegmentIndex==0?OBCStartRTMP(self.address.text):OBCSendCommand(YES,self.peer.text);[self message:e?:@"启动请求已发送；请在手机直播预览和观众端确认画面、声音。"] ;}
- (void)stop {
    UIAlertController *alert=[UIAlertController alertControllerWithTitle:@"停止画面替换？" message:@"停止后将恢复真实摄像头。" preferredStyle:UIAlertControllerStyleAlert];
    [alert addAction:[UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:nil]];
    [alert addAction:[UIAlertAction actionWithTitle:@"停止" style:UIAlertActionStyleDestructive handler:^(UIAlertAction *action){(void)action;NSString *e=OBCSendCommand(NO,nil);if(e)[self message:e];}]];
    [self presentViewController:alert animated:YES completion:nil];
}
- (void)scan {
    // Stop replacement before scanning; otherwise the scanner would see the substituted video.
    UIAlertController *a=[UIAlertController alertControllerWithTitle:@"扫描视频通道" message:@"继续将停止画面替换，可能露出真实摄像头。请在开播前扫码；正在直播时建议用粘贴配对文字。取消此提示不会停止接收。" preferredStyle:UIAlertControllerStyleAlert];
    [a addAction:[UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:nil]];
    [a addAction:[UIAlertAction actionWithTitle:@"继续扫码" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action){
        (void)action;NSString *error=OBCSendCommand(NO,nil);
        if(error){dispatch_after(dispatch_time(DISPATCH_TIME_NOW,NSEC_PER_SEC/2),dispatch_get_main_queue(),^{[self message:error];});return;}
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW,NSEC_PER_SEC/2),dispatch_get_main_queue(),^{
            OBScan *s=[OBScan new];s.found=^(NSString *text){[self pair:text];};
            [self presentViewController:[[UINavigationController alloc] initWithRootViewController:s] animated:YES completion:nil];
        });
    }]];[self presentViewController:a animated:YES completion:nil];
}
- (void)paste {NSString *s=UIPasteboard.generalPasteboard.string;if(s.length)[self pair:s];else [self message:@"剪贴板没有配对文字；也可直接填写RTMP地址。"] ;}
- (void)pair:(NSString *)text {
    if([text hasPrefix:@"rtmp://"]){self.address.text=text;return;}
    NSURLComponents *u=[NSURLComponents componentsWithString:text];NSMutableDictionary *q=[NSMutableDictionary dictionary];
    for(NSURLQueryItem *i in u.queryItems)if(i.value)q[i.name]=i.value;
    struct in_addr ip;NSInteger port=[q[@"port"] integerValue];
    if(![u.scheme isEqual:@"meowrtmp"] || ![u.host isEqual:@"pair"] || !q[@"server"] || inet_pton(AF_INET,[q[@"server"] UTF8String],&ip)!=1 || port<1 || port>65535 || [q[@"token"] length]>128 || ![q[@"token"] length]){[self message:@"不是有效的视频通道配对码。TikTok登录码请用TikTok扫描。"] ;return;}
    NSString *device=[[NSUserDefaults standardUserDefaults] stringForKey:@"DeviceID"];
    if(!device){device=NSUUID.UUID.UUIDString;[[NSUserDefaults standardUserDefaults] setObject:device forKey:@"DeviceID"];}
    NSMutableURLRequest *request=[NSMutableURLRequest requestWithURL:[NSURL URLWithString:[NSString stringWithFormat:@"http://%@:%ld/pair",q[@"server"],(long)port]]];
    request.HTTPMethod=@"POST";request.timeoutInterval=6;[request setValue:@"application/json" forHTTPHeaderField:@"Content-Type"];
    request.HTTPBody=[NSJSONSerialization dataWithJSONObject:@{@"token":q[@"token"],@"device":device} options:0 error:nil];
    [[NSURLSession.sharedSession dataTaskWithRequest:request completionHandler:^(NSData *data,NSURLResponse *response,NSError *error){
        NSDictionary *d=data?[NSJSONSerialization JSONObjectWithData:data options:0 error:nil]:nil;
        dispatch_async(dispatch_get_main_queue(),^{
            if(error || ![d isKindOfClass:NSDictionary.class] || ((NSHTTPURLResponse *)response).statusCode!=200 || ![d[@"rtmp"] isKindOfClass:NSString.class]){[self message:error.localizedDescription?:d[@"error"]?:@"配对失败"];return;}
            NSMutableDictionary *pair=[d mutableCopy];pair[@"device"]=device;
            NSString *failure=OBCSavePairing(pair);if(failure){[self message:failure];return;}
            self.address.text=d[@"rtmp"];[self message:@"视频通道配对成功，点击开始RTMP。"];
        });
    }] resume];
}
- (void)save {
    for(NSString *key in self.sliders)self.sliders[key].value=[self.values[key] floatValue];
    NSString *e=OBCSaveTransform(self.values);if(e)self.status.text=e;
}
- (void)slider:(UISlider *)s {NSArray *keys=@[@"zoom",@"x",@"y",@"left",@"right",@"top",@"bottom"];self.values[keys[(NSUInteger)s.tag]]=@(s.value);[self save];}
- (void)rotate {NSString *e=OBCSetVideoRotation(OBCVideoRotation()+1);if(e)[self message:e];}
- (void)outputDirection {BOOL landscape=![self.values[@"landscape"] boolValue];self.values[@"landscape"]=@(landscape);[self save];[self message:landscape?@"当前按横屏输出调整。素材比例不限。":@"当前按竖屏输出调整。素材比例不限。"] ;}
- (void)reset {for(NSString *k in self.values.allKeys)self.values[k]=[k isEqual:@"zoom"]?@1:@0;[self save];}
- (void)update {
    if(UIApplication.sharedApplication.applicationState!=UIApplicationStateActive || !self.view.window || self.presentedViewController)return;
    CFTimeInterval now=CACurrentMediaTime();
    if(now-self.lastStatusUpdate<1.)return;
    self.lastStatusUpdate=now;
    NSString *raw=OBCStatus();
    BOOL healthy=[raw containsString:@"已连接"] && ![raw containsString:@"暂无可发布视频"];
    self.summary.text=healthy?@"连接中，详情见状态":@"查看状态确认接收情况";
    self.status.text=raw;
    if(!self.logBusy) {
        NSDictionary *log=OBCLogStatus();
        if(!log.count)self.logSummary.text=@"尚无本版日志状态；安装后需重启用户空间以加载新接收层。";
        else self.logSummary.text=[NSString stringWithFormat:@"%@ · %.2f / 128 MB\n写入错误 %@ / 丢失记录 %@ / 尾部恢复 %@ 字节",
            [log[@"Full"] boolValue]?@"日志已满，停止记录（请先导出再清空）":[log[@"WriteErrors"] unsignedLongLongValue]?@"日志写入失败，请导出已有记录":[log[@"Ready"] boolValue]?@"后台日志记录中":@"日志未就绪",
            [log[@"Bytes"] doubleValue]/1048576.,log[@"WriteErrors"]?:@0,log[@"Dropped"]?:@0,log[@"RecoveredTailBytes"]?:@0];
    }
}
@end

@interface OBApp : UIResponder <UIApplicationDelegate>
@property(nonatomic,strong) UIWindow *window;
@end
@implementation OBApp
- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)options {
    (void)application;(void)options;self.window=[[UIWindow alloc] initWithFrame:UIScreen.mainScreen.bounds];
    self.window.rootViewController=[[UINavigationController alloc] initWithRootViewController:[OBSettings new]];[self.window makeKeyAndVisible];
    return YES;
}

@end
int main(int argc,char **argv){@autoreleasepool{return UIApplicationMain(argc,argv,nil,NSStringFromClass(OBApp.class));}}
