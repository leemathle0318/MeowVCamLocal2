#pragma once
#import <Foundation/Foundation.h>
// Background only: scoped read of one fixed export file, copy to app temporary
// space, then pass that local URL to the system share sheet. No IPC/audio changes.
FOUNDATION_EXPORT NSURL *OBCopyLogExport(NSString **error);
