#import "LogExport.h"
#import "../Shared.h"
#include <dlfcn.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <unistd.h>
#include <errno.h>

NSURL *OBCopyLogExport(NSString **error) {
    int fd=open(OB_LOG_EXPORT_FILE,O_RDONLY|O_NOFOLLOW|O_CLOEXEC);
    if(fd<0 && (errno==EPERM || errno==EACCES)) {
        // Loaded only after an actual denied read, on the export worker, not
        // at app launch. applyProfile success alone is never considered proof.
        void *lib=dlopen("/var/jb/usr/lib/libsandy.dylib",RTLD_LAZY|RTLD_LOCAL);
        int (*apply)(const char *)=lib?(int (*)(const char *))dlsym(lib,"libSandy_applyProfile"):NULL;
        if(apply)apply("local.xiaoguai.obsbridge.log-read");
        fd=open(OB_LOG_EXPORT_FILE,O_RDONLY|O_NOFOLLOW|O_CLOEXEC);
        // Keep libSandy loaded: it can own process-scoped extension resources.
    }
    int failure=fd<0?errno:0;struct stat st={0};
    if(fd>=0 && (fstat(fd,&st) || !S_ISREG(st.st_mode) || st.st_nlink!=1 || (st.st_mode&0022) ||
        (st.st_uid!=0 && st.st_uid!=501 && st.st_uid!=geteuid()) || st.st_size<=0 || st.st_size>128ll*1024*1024+16384))failure=EINVAL;
    if(failure){if(fd>=0)close(fd);if(error)*error=[NSString stringWithFormat:@"无法读取日志导出文件（错误 %d）。请保留此提示，不需要重推或重装。",failure];return nil;}
    NSString *name=[NSString stringWithFormat:@"tk-diagnostics-%@.jsonl",NSUUID.UUID.UUIDString];
    NSURL *destination=[NSURL fileURLWithPath:[NSTemporaryDirectory() stringByAppendingPathComponent:name]];
    int out=open(destination.path.fileSystemRepresentation,O_CREAT|O_EXCL|O_WRONLY|O_NOFOLLOW|O_CLOEXEC,0600);
    if(out<0)failure=errno;
    char buffer[65536];off_t remaining=st.st_size;
    while(!failure && remaining>0) {
        size_t wanted=remaining<(off_t)sizeof(buffer)?(size_t)remaining:sizeof(buffer);
        ssize_t n=read(fd,buffer,wanted);
        if(n<0 && errno==EINTR)continue;
        if(n<=0){failure=n==0?EIO:errno;break;}
        ssize_t offset=0;
        while(offset<n) {
            ssize_t written=write(out,buffer+offset,(size_t)(n-offset));
            if(written<0 && errno==EINTR)continue;
            if(written<=0){failure=errno?:EIO;break;}offset+=written;
        }
        remaining-=n;
    }
    close(fd);
    if(out>=0){if(!failure && fsync(out))failure=errno;if(close(out) && !failure)failure=errno;}
    if(failure){[[NSFileManager defaultManager] removeItemAtURL:destination error:nil];if(error)*error=[NSString stringWithFormat:@"复制日志失败（错误 %d），可再次导出。",failure];return nil;}
    return destination;
}
