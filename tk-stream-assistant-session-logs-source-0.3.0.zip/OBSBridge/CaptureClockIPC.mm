#import "CaptureClockIPC.h"
#include <notify.h>
#include <mutex>
#include <unistd.h>
namespace {
using Wire=obs::next::CaptureClockWire;
std::mutex channelLock;
const char *names[Wire::Count]={
    "local.xiaoguai.obsbridge.capture.v1.sequence", "local.xiaoguai.obsbridge.capture.v1.cookie",
    "local.xiaoguai.obsbridge.capture.v1.unit", "local.xiaoguai.obsbridge.capture.v1.epoch",
    "local.xiaoguai.obsbridge.capture.v1.host", "local.xiaoguai.obsbridge.capture.v1.master",
    "local.xiaoguai.obsbridge.capture.v1.ratio", "local.xiaoguai.obsbridge.capture.v1.reported",
    "local.xiaoguai.obsbridge.capture.v1.frames", "local.xiaoguai.obsbridge.capture.v1.ready",
    "local.xiaoguai.obsbridge.capture.v1.revision"};
std::array<int,Wire::Count> tokens{{-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1}};
bool token(unsigned i) {
    if(tokens[i]>=0)return true;
    if(notify_register_check(names[i],&tokens[i])){tokens[i]=-1;return false;}
    return true;
}
}
void OBPublishCaptureClock(const obs::next::CaptureClockSnapshot &snapshot) {
    std::lock_guard<std::mutex> guard(channelLock);
    for(unsigned i=0;i<Wire::Count;++i)if(!token(i))return;
    static uint32_t revision=0;
    revision+=2;
    uint64_t sequence=(uint64_t(uint32_t(getpid()))<<32)|revision;
    auto words=Wire::encode(snapshot);
    if(notify_set_state(tokens[Wire::Sequence],sequence|1))return;
    for(unsigned i=1;i<Wire::Count;++i)if(notify_set_state(tokens[i],words[i])) {
        notify_set_state(tokens[Wire::Sequence],0);return;
    }
    // A receiver only accepts the SAME even publication sequence before/after
    // every field. A failed/half-written update cannot form a clock snapshot.
    notify_set_state(tokens[Wire::Sequence],sequence);
}
obs::next::CaptureFeedbackState OBReadCaptureClock(uint64_t cookie,uint32_t generation,double now,
                                                 obs::next::CaptureClockSnapshot &snapshot) {
    std::lock_guard<std::mutex> guard(channelLock);
    return Wire::read([](unsigned i,uint64_t &value){
        return token(i) && notify_get_state(tokens[i],&value)==NOTIFY_STATUS_OK;
    },now,cookie,generation,snapshot);
}
