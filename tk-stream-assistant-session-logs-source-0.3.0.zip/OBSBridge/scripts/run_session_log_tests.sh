#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
ROOT="$PWD"
TEST_DIR="$(mktemp -d "${TMPDIR:-/tmp}/obsbridge-logs.XXXXXX")"
trap 'rm -rf -- "$TEST_DIR"' EXIT
HOST_SDK="$(xcrun --sdk macosx --show-sdk-path)"
HOST_CXX="$(xcrun --sdk macosx --find clang++)"
"$HOST_CXX" -isysroot "$HOST_SDK" -std=c++17 -fobjc-arc -fblocks -Wall -Wextra -Werror -UNDEBUG \
  -DOB_LOG_LIMIT=8192 \
  "-DOB_LOG_FILE=\"$TEST_DIR/session.jsonl\"" \
  "-DOB_LOG_EXPORT_FILE=\"$TEST_DIR/export.jsonl\"" \
  "-DOB_LOG_EXPORT_TEMP=\"$TEST_DIR/export.tmp\"" \
  "$ROOT/SessionLog.mm" "$ROOT/tests/session_log_foundation_tests.mm" -framework Foundation \
  -o "$TEST_DIR/session_log_tests"
"$TEST_DIR/session_log_tests"
