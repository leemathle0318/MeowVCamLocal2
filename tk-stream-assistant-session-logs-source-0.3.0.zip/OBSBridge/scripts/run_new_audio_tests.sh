#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
ROOT="$PWD"
SOURCE="$ROOT/work/ffmpeg-7.1.5"
BUILD="$ROOT/work/ffmpeg-host-build"
PREFIX="$ROOT/work/ffmpeg-host-install"
[ "$(uname -s)" = Darwin ] || { echo 'Requires macOS host compiler.'; exit 1; }
[ -f "$SOURCE/configure" ] || { echo 'Build pinned iOS FFmpeg sources first.'; exit 1; }
mkdir -p "$BUILD"

# This builds/runs MACOS host tests, not the preceding iOS libraries. Invoking
# the absolute clang path alone does not select a macOS SDK for its linker:
# FFmpeg's first executable probe then fails with "library 'System' not found".
unset SDKROOT CC CXX LD AR RANLIB CFLAGS CPPFLAGS CXXFLAGS LDFLAGS
unset CPATH C_INCLUDE_PATH CPLUS_INCLUDE_PATH LIBRARY_PATH
unset IPHONEOS_DEPLOYMENT_TARGET TVOS_DEPLOYMENT_TARGET WATCHOS_DEPLOYMENT_TARGET
HOST_SDK="$(xcrun --sdk macosx --show-sdk-path)"
HOST_CC="$(xcrun --sdk macosx --find clang)"
HOST_CXX="$(xcrun --sdk macosx --find clang++)"
HOST_AR="$(xcrun --sdk macosx --find ar)"
HOST_RANLIB="$(xcrun --sdk macosx --find ranlib)"
HOST_ARCH="$(uname -m)"
case "$HOST_ARCH" in arm64|x86_64) ;; *) echo "Unsupported host architecture: $HOST_ARCH"; exit 1 ;; esac
[ -d "$HOST_SDK" ] || { echo "Missing macOS SDK: $HOST_SDK"; exit 1; }
export SDKROOT="$HOST_SDK"
export MACOSX_DEPLOYMENT_TARGET=13.0
HOST_FLAGS="-arch $HOST_ARCH -isysroot $HOST_SDK -mmacosx-version-min=$MACOSX_DEPLOYMENT_TARGET"

# Keep the original failure status and print the relevant diagnostics inline.
# No cross-compilation bypass: these binaries really must run on this host.
host_failure() {
  STATUS=$?
  if [ "$STATUS" -ne 0 ]; then
    echo 'macOS host build/test failed; diagnostics follow.' >&2
    for LOG in "$BUILD/compiler-smoke.log" "$BUILD/ffbuild/config.log"; do
      if [ -f "$LOG" ]; then echo "--- $LOG (last 100 lines) ---" >&2; tail -n 100 "$LOG" >&2; fi
    done
  fi
}
trap host_failure EXIT
printf 'macOS host: %s\nSDK: %s\nC compiler: %s\n' "$HOST_ARCH" "$HOST_SDK" "$HOST_CC"
printf '%s\n' 'int main(void) { return 0; }' > "$BUILD/compiler-smoke.c"
"$HOST_CC" -arch "$HOST_ARCH" -isysroot "$HOST_SDK" \
  -mmacosx-version-min="$MACOSX_DEPLOYMENT_TARGET" \
  "$BUILD/compiler-smoke.c" -o "$BUILD/compiler-smoke" > "$BUILD/compiler-smoke.log" 2>&1
"$BUILD/compiler-smoke"
(
  cd "$BUILD"
  "$SOURCE/configure" --prefix="$PREFIX" --target-os=darwin --arch="$HOST_ARCH" \
    --cc="$HOST_CC" --cxx="$HOST_CXX" --ld="$HOST_CC" --ar="$HOST_AR" --ranlib="$HOST_RANLIB" \
    --sysroot="$HOST_SDK" --extra-cflags="$HOST_FLAGS" --extra-cxxflags="$HOST_FLAGS" \
    --extra-ldflags="$HOST_FLAGS" --host-cc="$HOST_CC" --host-ld="$HOST_CC" \
    --host-cflags="$HOST_FLAGS" --host-ldflags="$HOST_FLAGS" \
    --disable-everything --disable-autodetect --disable-programs --disable-network \
    --disable-doc --disable-debug --disable-asm --disable-shared --enable-static \
    --disable-avcodec --disable-avformat --disable-avdevice --disable-avfilter \
    --disable-swscale --disable-postproc --enable-avutil --enable-swresample
  make -j"$(sysctl -n hw.ncpu)"
  make install
)
for NAME in capture_clock capture_wire common_clock ffmpeg_timeline prepared_capture full_audio_pipeline; do
  "$HOST_CXX" -arch "$HOST_ARCH" -isysroot "$HOST_SDK" \
    -mmacosx-version-min="$MACOSX_DEPLOYMENT_TARGET" \
    -std=c++17 -Wall -Wextra -Werror -O2 -UNDEBUG \
    -I"$PREFIX/include" "tests/${NAME}_tests.cpp" \
    "$PREFIX/lib/libswresample.a" "$PREFIX/lib/libavutil.a" \
    -o "work/${NAME}_tests"
  "work/${NAME}_tests" 2>&1 | tee "work/${NAME}-test.log"
done
# Use the pinned library for long-duration PCM as well as short edge cases.
# This is accelerated modeled IO, not a four-hour iPhone/audience test.
"work/full_audio_pipeline_tests" 14400 both 2>&1 | tee work/full_audio_pipeline-long-test.log

echo 'Pinned FFmpeg 7.1.5 native host tests passed; NOT iPhone or audience verification.'
