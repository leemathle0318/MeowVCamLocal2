#pragma once
#import <Foundation/Foundation.h>
#import <CoreMedia/CoreMedia.h>
#import <AudioToolbox/AudioToolbox.h>

FOUNDATION_EXPORT double OBNow(void);
FOUNDATION_EXPORT BOOL OBEnabled(void);
FOUNDATION_EXPORT void OBStart(NSString *bindIP, NSString *allowedPeer);
FOUNDATION_EXPORT void OBStop(void);
FOUNDATION_EXPORT NSString *OBStatus(void);
FOUNDATION_EXPORT void OBProducerTick(void);
FOUNDATION_EXPORT NSString *OBControlStatus(void);
// Mutates the system source's pixel buffer, not an app's capture delegate.
FOUNDATION_EXPORT BOOL OBReplaceVideo(CMSampleBufferRef camera);
FOUNDATION_EXPORT CMSampleBufferRef OBCopyAudio(CMSampleBufferRef mic) CF_RETURNS_RETAINED;
FOUNDATION_EXPORT CMSampleBufferRef OBCopyAudioForNode(CMSampleBufferRef mic, id node) CF_RETURNS_RETAINED;
FOUNDATION_EXPORT void OBPublishAudioDiagnostics(void);
FOUNDATION_EXPORT void OBPublishVideoDiagnostics(void);
FOUNDATION_EXPORT NSString *OBMediaAudioStatus(void);
FOUNDATION_EXPORT BOOL OBMixABL(AudioBufferList *abl, UInt32 frames,
                              const AudioStreamBasicDescription *format, double time);

FOUNDATION_EXPORT void OBStartRTMP(NSString *url);
FOUNDATION_EXPORT NSDictionary *OBReceiveCounters(void);
// Whitelisted numeric diagnostics, collected only by the utility log queue.
FOUNDATION_EXPORT NSDictionary *OBLogSnapshot(void);
