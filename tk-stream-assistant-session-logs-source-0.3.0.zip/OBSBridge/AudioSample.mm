#import "AudioSample.h"
#include <vector>
#include <algorithm>
#include <array>
#include <cstring>
#include "core/AudioListQuery.hpp"

OSStatus OBGetAudioBufferList(CMSampleBufferRef source, AudioBufferList *list,
    size_t capacity, size_t *needed, CMBlockBufferRef *retained, OBAudioListReport *report) {
    if (report) *report = {};
    if (needed) *needed = 0;
    if (retained) *retained = nullptr;
    if (!source || !list || !needed || !retained || capacity > OBAudioListCapacity)
        return kCMSampleBufferError_RequiredParameterMissing;
    OSStatus rc = CMSampleBufferGetAudioBufferListWithRetainedBlockBuffer(source, needed,
        nullptr, 0, kCFAllocatorDefault, kCFAllocatorDefault,
        kCMSampleBufferFlag_AudioBufferList_Assure16ByteAlignment, nullptr);
    if (report) { report->stage = 1; report->queryStatus = rc; }
    auto plan = obs::audioListPlan(rc, kCMSampleBufferError_ArrayTooSmall, *needed, capacity,
        offsetof(AudioBufferList, mBuffers), sizeof(AudioBuffer));
    if (plan.code == obs::AudioListPlanCode::APIError) return rc;
    if (plan.code == obs::AudioListPlanCode::Capacity) return kCMSampleBufferError_ArrayTooSmall;
    if (plan.code != obs::AudioListPlanCode::Ready) return kCMSampleBufferError_RequiredParameterMissing;
    memset(list, 0, *needed);
    list->mNumberBuffers = plan.buffers;
    if (report) { report->stage = 2; report->inputBuffers = plan.buffers; }
    // Exact queried size and initialized entry capacity; do not pass the
    // size-output pointer again or advertise unused scratch space as entries.
    rc = CMSampleBufferGetAudioBufferListWithRetainedBlockBuffer(source, nullptr,
        list, *needed, kCFAllocatorDefault, kCFAllocatorDefault,
        kCMSampleBufferFlag_AudioBufferList_Assure16ByteAlignment, retained);
    if (report) report->fillStatus = rc;
    if (!rc && (!*retained || !list->mNumberBuffers || list->mNumberBuffers > plan.buffers))
        rc = kCMSampleBufferError_RequiredParameterMissing;
    if (rc && *retained) { CFRelease(*retained); *retained = nullptr; }
    return rc;
}

CMSampleBufferRef OBCopyMixedAudioSample(CMSampleBufferRef source, const AudioBufferList *mixed, OSStatus *status) {
    auto fail = [&](OSStatus code) -> CMSampleBufferRef { if (status) *status = code; return nullptr; };
    if (!source || !mixed || !mixed->mNumberBuffers || mixed->mNumberBuffers > 8) return fail(kCMSampleBufferError_RequiredParameterMissing);
    CMItemCount frames = CMSampleBufferGetNumSamples(source);
    auto format = CMSampleBufferGetFormatDescription(source);
    const auto *asbd = format ? CMAudioFormatDescriptionGetStreamBasicDescription(format) : nullptr;
    if (!asbd || asbd->mFormatID != kAudioFormatLinearPCM || frames <= 0 || frames > 8192 ||
        !asbd->mBytesPerFrame || asbd->mBytesPerFrame > 64) return fail(kCMSampleBufferError_RequiredParameterMissing);
    bool planar = (asbd->mFormatFlags & kAudioFormatFlagIsNonInterleaved) != 0;
    if (mixed->mNumberBuffers != (planar ? asbd->mChannelsPerFrame : 1)) return fail(kCMSampleBufferError_RequiredParameterMissing);
    size_t planeBytes = size_t(frames) * asbd->mBytesPerFrame;
    size_t total = planeBytes * mixed->mNumberBuffers;
    if (total > 8192 * 8 * 8) return fail(kCMSampleBufferError_RequiredParameterMissing);
    for (UInt32 i = 0; i < mixed->mNumberBuffers; ++i)
        if (!mixed->mBuffers[i].mData || mixed->mBuffers[i].mDataByteSize < planeBytes ||
            mixed->mBuffers[i].mNumberChannels != (planar ? 1 : asbd->mChannelsPerFrame)) return fail(kCMSampleBufferError_RequiredParameterMissing);
    CMItemCount timingCount = 0;
    OSStatus rc = CMSampleBufferGetSampleTimingInfoArray(source, 0, nullptr, &timingCount);
    if (rc || (timingCount != 1 && timingCount != frames)) return fail(rc ?: kCMSampleBufferError_RequiredParameterMissing);
    std::vector<CMSampleTimingInfo> timing(size_t(timingCount), CMSampleTimingInfo{});
    rc = CMSampleBufferGetSampleTimingInfoArray(source, timingCount, timing.data(), nullptr);
    if (rc) return fail(rc);
    CMBlockBufferRef block = nullptr;
    rc = CMBlockBufferCreateWithMemoryBlock(kCFAllocatorDefault, nullptr, total,
        kCFAllocatorDefault, nullptr, 0, total, 0, &block);
    if (!rc && !block) rc = kCMSampleBufferError_AllocationFailed;
    if (!rc) rc = CMBlockBufferAssureBlockMemory(block);
    for (UInt32 i = 0; !rc && i < mixed->mNumberBuffers; ++i)
        rc = CMBlockBufferReplaceDataBytes(mixed->mBuffers[i].mData, block, planeBytes * i, planeBytes);
    CMSampleBufferRef result = nullptr;
    size_t sampleSize = asbd->mBytesPerFrame;
    if (!rc) rc = CMSampleBufferCreateReady(kCFAllocatorDefault, block, format, frames,
        timingCount, timing.data(), planar ? 0 : 1, planar ? nullptr : &sampleSize, &result);
    if (block) CFRelease(block);
    if (rc || !result) { if (result) CFRelease(result); return fail(rc ?: kCMSampleBufferError_RequiredParameterMissing); }
    // CreateReady success alone is insufficient: only publish audio samples
    // that CoreMedia can actually extract with the expected channel geometry.
    alignas(16) std::array<uint8_t, OBAudioListCapacity> storage{};
    auto *checked = reinterpret_cast<AudioBufferList *>(storage.data());
    size_t needed = 0; CMBlockBufferRef retained = nullptr;
    rc = OBGetAudioBufferList(result, checked, storage.size(), &needed, &retained);
    if (!rc && (!retained || checked->mNumberBuffers != mixed->mNumberBuffers))
        rc = kCMSampleBufferError_RequiredParameterMissing;
    for (UInt32 i = 0; !rc && i < checked->mNumberBuffers; ++i)
        if (!checked->mBuffers[i].mData || checked->mBuffers[i].mDataByteSize < planeBytes ||
            checked->mBuffers[i].mNumberChannels != mixed->mBuffers[i].mNumberChannels)
            rc = kCMSampleBufferError_RequiredParameterMissing;
    if (retained) CFRelease(retained);
    if (rc) { CFRelease(result); return fail(rc); }
    for (auto mode : {kCMAttachmentMode_ShouldPropagate, kCMAttachmentMode_ShouldNotPropagate}) {
        CFDictionaryRef attachments = CMCopyDictionaryOfAttachments(kCFAllocatorDefault, source, mode);
        if (attachments) { CMSetAttachments(result, attachments, mode); CFRelease(attachments); }
    }
    CFArrayRef original = CMSampleBufferGetSampleAttachmentsArray(source, false);
    if (original) {
        CFArrayRef destination = CMSampleBufferGetSampleAttachmentsArray(result, true);
        CFIndex count = destination ? std::min(CFArrayGetCount(original), CFArrayGetCount(destination)) : 0;
        for (CFIndex i = 0; i < count; ++i) {
            auto from = static_cast<CFDictionaryRef>(CFArrayGetValueAtIndex(original, i));
            auto to = static_cast<CFMutableDictionaryRef>(const_cast<void *>(CFArrayGetValueAtIndex(destination, i)));
            CFDictionaryApplyFunction(from, [](const void *key, const void *value, void *context) {
                CFDictionarySetValue(static_cast<CFMutableDictionaryRef>(context), key, value);
            }, to);
        }
    }
    if (status) *status = noErr;
    return result;
}
