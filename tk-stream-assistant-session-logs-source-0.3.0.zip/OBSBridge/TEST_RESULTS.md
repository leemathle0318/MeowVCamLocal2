> 以下为基础版历史检查。本次日志版结果请看 SESSION_LOG_TEST_RESULTS.md；这些历史结果不是新日志功能的手机验证。

# 0.2.9 检查记录（2026-10-12）

## 用户GitHub实测

- 0.2.6纯C++回归通过，CoreMedia混音输出读取断言失败，没有错误码。
- 0.2.7真实CoreMedia第一个原始音频fixture读取失败，status=-12737（ArrayTooSmall）、needed24/capacity4096/buffers0；还未进入混音。查询/填充阶段未区分，不能认定具体阶段或仅是分配空间小。

## 本机执行

- 从0.2.9源码重新编译并运行10组C++测试：timeline、shortcut、shared_media、nonblocking_read、pending_frames、mapped_media、access_attempt、video_continuity、native_audio、audio_list_contract。
- 新列表契约测试覆盖-12737+有效24字节查询可继续、1/2/8条目容量、真正空间不足/其他API错误/零或残缺尺寸/超过8条目拒绝。这是纯策略测试，不冒充CoreMedia实际API执行。
- 保留44种原生PCM格式、独立已知字节、合成双音源幅度、游标重置/抖动、限幅/NaN/越界测试；5000并发帧版本和两Windows进程只读媒体映射回归。
- 12个插件单元加CoreMedia测试源文件，共13个iOS arm64 Mach-O对象编译，SDK16.5/deploy15/ARC/blocks/Wall/Wextra/Werror。
- 16项源码结构检查、5项打包准备、12项不可安装的合成deb检查；源码ZIP版本/LF/完整性，工作流YAML/Bash/嵌入Python和10种源码定位/旧版本/危险路径/换行案例检查。

## 未执行/未确认

Windows不能执行macOS CoreMedia库。Actions内真实8种CoreMedia用例和所有断言保留；新行为是否解决用户报错需要这一步实际结果。完整Theos链接、签名、arm64e、真机视频/OBS音轨+麦克风/音画同步/观众端没有通过记录。未把成功编译叫作声音功能实现验收。


## 原画质修复 1 主机验证（2026-10-14）

- 21个arm64 iOS对象编译成功，最后的ControlMain页面切换修改另外重新编译通过。不是完整macOS/Theos链接，也不是iPhone运行测试。
- 12组C++测试通过：新增1080×1920完整共享帧写入/只读复制、v4/v5布局拒绝、24/25/30/50/60源帧保留、过热预算、RTMP持续提前/滞后恢复、AAC样本连续性等。
- AAC毫秒取整模拟中，旧写入有412个缺样本位置，样本连续调度为0；保留真实时间跳变。这不是对用户录音杂音的已证实诊断。
- Python：24项项目结构检查、8项打包检查、16项合成deb严格校验，共48项通过。
- 真实本机TCP：H.264 1080×1920/30fps收齐60帧，1920×1080/60fps收齐120帧；两组AAC均解出95帧，输入48kHz、AAC名义192Kbps（VBR实际平均191530bps）。分片收取137字节，传输内容完全一致。
- 真实MediaMTX+电脑Publisher+插件同源RTMP读取器：两组源尺寸都正确解码，连续循环运行；竖屏测试解出124视频帧/282音频帧，横屏测试357/281。观测时间包含接入等待关键帧和探测，不能直接拿总帧数除时间作为稳定播放帧率。
- 测试启动初期先连播放器曾因流未就绪被服务器拒绝；检查服务端明确发布就绪后才开始测试，两组通过。没有把初次失败写成通过，也没有因此修改用户电脑软件。
- 没有iPhone的Metal/VideoToolbox性能、UIKit截图、热状态或直播观众端验证。不能宣称任何视频都保证流畅或观众端一定是源分辨率/帧率。
