#import "Receiver.h"
#import "Shared.h"
#import "LiveAudioStatus.h"
#import "CaptureClockIPC.h"
#include "core/VideoBudget.hpp"
#import "MediaBus.h"
#import <CoreImage/CoreImage.h>
#include "core/Timeline.hpp"
#include "core/NonblockingRead.hpp"
#include "core/PendingFrames.hpp"
#include "core/CommonPresentationClock.hpp"
#include "core/FFmpegAudioTimeline.hpp"
#include "core/RtmpPull.hpp"
#include <atomic>
#include <array>
#include <deque>
#include <memory>
#include <new>
#include <mutex>
#include <string>
#include <vector>
#include <ifaddrs.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <fcntl.h>
#include <time.h>
#include <unistd.h>
#include <cerrno>
#include <cstring>
extern "C" {
#include <libavformat/avformat.h>
#include <libavcodec/avcodec.h>
#include <libavutil/hwcontext.h>
#include <libavutil/pixdesc.h>
#include <libswresample/swresample.h>
#include <libswscale/swscale.h>
}

namespace {
void waitNetwork(void) {
    timespec delay{0, 10000000}; // 10 ms, no busy spinning
    nanosleep(&delay, nullptr);
}
bool nonblocking(int fd) {
    int flags = fcntl(fd, F_GETFL, 0);
    return flags >= 0 && fcntl(fd, F_SETFL, flags | O_NONBLOCK) == 0;
}
struct Image {
    CVPixelBufferRef pixel;
    double due;
    Image(CVPixelBufferRef p, double d) : pixel(CVPixelBufferRetain(p)), due(d) {}
    ~Image() { CVPixelBufferRelease(pixel); }
};
struct Engine {
    std::atomic<bool> enabled{false}, listening{false}, rtmpMode{false}, connected{false};
    std::atomic<uint64_t> generation{0}, videos{0}, audios{0}, bytes{0}, accepted{0}, rejected{0}, published{0}, publishFailed{0};
    std::atomic<uint64_t> ticks{0}, clockResets{0}, queueDrops{0}, budgetDrops{0}, hardwareFrames{0}, softwareFrames{0};
    std::atomic<uint64_t> decodedVideo{0}, invalidVideo{0}, pixelFailures{0}, timingDrops{0};
    std::atomic<double> lastVideoDelta{0};
    uint64_t audioWaitMaxUS = 0, audioWaitTotalUS = 0, audioLateDrops = 0, obsoleteVideo = 0;
    double lastAudioLeadMS = 0, lastRenderMS = 0;
    obs::next::CaptureClockSnapshot nativeCapture;
    obs::next::CaptureFeedbackState captureState=obs::next::CaptureFeedbackState::Unavailable;
    double lastCapturePoll=-1e30;
    std::mutex mutex;
    std::string message = "尚未启用", lastError, lastPeer;
    std::deque<std::shared_ptr<Image>> images;
    std::shared_ptr<Image> current;
    obs::next::CommonPresentationClock clock;
    uint64_t audioSegments=0,audioEngineErrors=0;
    uint64_t clockEpoch = 0;
    std::atomic<double> lastVideo{0};
    std::shared_ptr<Image> publishedImage;
    dispatch_queue_t queue = dispatch_queue_create("local.xiaoguai.obsbridge.receive", DISPATCH_QUEUE_SERIAL);
    bool active(uint64_t g) { return enabled.load() && generation.load() == g; }
    void note(const char *s) { std::lock_guard<std::mutex> l(mutex); message = s; }
    void noteFor(uint64_t g, const char *s) {
        std::lock_guard<std::mutex> l(mutex);
        if (generation.load() == g) message = s;
    }
    void clearLocked() {
        images.clear(); current.reset(); publishedImage.reset(); clock.reset(); ++clockEpoch; OBBusResetAudio();
        nativeCapture={};captureState=obs::next::CaptureFeedbackState::Unavailable;
    }
    // The same sender clock schedules both tracks, independent of network arrival jitter.
    double scheduleLocked(double pts, bool video) {
        auto result = clock.schedule(pts, OBNow(), video, rtmpMode.load());
        if (result.rebased) {
            ++clockResets; ++clockEpoch;
            // Flush both tracks together, but retain the newly established clock.
            images.clear(); current.reset(); publishedImage.reset(); OBBusResetAudio();
        }
        return result.due;
    }
};
Engine &engine() { static Engine e; return e; }

struct Reader {
    int fd = -1;
    int receiveError = 0;
    uint64_t generation;
    double lastData = OBNow();
    std::unique_ptr<obs::RtmpPull> rtmp;
    explicit Reader(uint64_t g) : generation(g) {}
    ~Reader() { if (fd >= 0) close(fd); }
    static int raw(void *opaque, uint8_t *data, int size) {
        auto &r = *static_cast<Reader *>(opaque);
        auto result = obs::nonblockingRead([&]{ return engine().active(r.generation); },
            [&]{
                ssize_t n = recv(r.fd, data, size, 0);
                int code = n < 0 ? errno : 0;
                return obs::ReadAttempt{int(n), code, code == EINTR, code == EAGAIN || code == EWOULDBLOCK};
            }, []{ return OBNow(); }, []{ waitNetwork(); }, r.lastData);
        if (result.end == obs::ReadEnd::Data) {
            r.lastData = OBNow(); engine().bytes += uint64_t(result.bytes); return result.bytes;
        }
        if (result.end == obs::ReadEnd::Eof) return AVERROR_EOF;
        if (result.end == obs::ReadEnd::Timeout) return AVERROR(ETIMEDOUT);
        if (result.end == obs::ReadEnd::Cancelled) return AVERROR_EXIT;
        r.receiveError = result.error;
        return AVERROR(result.error);
    }
    static int read(void *opaque,uint8_t *data,int size) {
        auto &r=*static_cast<Reader *>(opaque);
        if(!r.rtmp)return raw(opaque,data,size);
        try {return r.rtmp->readFLV(data,size);}
        catch(const std::exception &error) {
            auto &e=engine();std::lock_guard<std::mutex> lock(e.mutex);
            if(e.generation.load()==r.generation)e.lastError=error.what();
            return AVERROR_EXIT;
        }
    }
    static int interrupt(void *opaque) {
        auto &r = *static_cast<Reader *>(opaque);
        return !engine().active(r.generation);
    }
};

struct Decoder {
    obs::FrameGate gate;
    std::unique_ptr<obs::next::FFmpegAudioTimeline> audioEngine;
    uint64_t audioEpoch=0;
    std::array<float,8192> audioOutput{};
    AVCodecContext *ctx = nullptr;
    AVStream *stream = nullptr;
    AVFrame *frame = av_frame_alloc();
    SwsContext *sws = nullptr;
    int inputRate = 0;
    AVSampleFormat inputFormat = AV_SAMPLE_FMT_NONE;
    AVChannelLayout inputLayout{};
    ~Decoder() {
        avcodec_free_context(&ctx); av_frame_free(&frame);
        sws_freeContext(sws); av_channel_layout_uninit(&inputLayout);
    }
    static AVPixelFormat pixelFormat(AVCodecContext *, const AVPixelFormat *formats) {
        for (auto p = formats; *p != AV_PIX_FMT_NONE; ++p)
            if (*p == AV_PIX_FMT_VIDEOTOOLBOX) return *p;
        for (auto p = formats; *p != AV_PIX_FMT_NONE; ++p) {
            auto d = av_pix_fmt_desc_get(*p);
            if (d && !(d->flags & AV_PIX_FMT_FLAG_HWACCEL)) return *p;
        }
        return AV_PIX_FMT_NONE;
    }
    bool open(AVFormatContext *fmt, AVMediaType type) {
        int i = av_find_best_stream(fmt, type, -1, -1, nullptr, 0);
        if (i < 0) return false;
        stream = fmt->streams[i];
        AVCodecID expected = type == AVMEDIA_TYPE_VIDEO ? AV_CODEC_ID_H264 : AV_CODEC_ID_AAC;
        if (stream->codecpar->codec_id != expected) return false;
        const AVCodec *codec = avcodec_find_decoder(expected);
        if (!codec || !frame || !(ctx = avcodec_alloc_context3(codec))) return false;
        if (avcodec_parameters_to_context(ctx, stream->codecpar) < 0) return false;
        ctx->pkt_timebase = stream->time_base;
        ctx->thread_count = 2;
        ctx->max_pixels = 1920 * 1080;
        if (type == AVMEDIA_TYPE_VIDEO) {
            if (av_hwdevice_ctx_create(&ctx->hw_device_ctx, AV_HWDEVICE_TYPE_VIDEOTOOLBOX,
                                      nullptr, nullptr, 0) >= 0) ctx->get_format = pixelFormat;
        }
        return avcodec_open2(ctx, codec, nullptr) >= 0;
    }
    double pts() {
        int64_t p = frame->best_effort_timestamp;
        if (p == AV_NOPTS_VALUE) p = frame->pts;
        return p == AV_NOPTS_VALUE ? NAN : p * av_q2d(stream->time_base);
    }
    void video(uint64_t g) {
        ++engine().decodedVideo;
        if (frame->width <= 0 || frame->height <= 0 || frame->width > 2048 ||
            frame->height > 2048 || int64_t(frame->width) * frame->height > 1920 * 1080) { ++engine().invalidVideo; return; }
        double p = pts(); if (!std::isfinite(p)) { ++engine().invalidVideo; return; }
        auto budget = obs::videoBudget(OBBusVideoProfile(), unsigned(NSProcessInfo.processInfo.thermalState));
        if (!gate.admit(p, budget.fps)) { ++engine().budgetDrops; return; }
        CVPixelBufferRef pixel = nullptr;
        bool owned = false;
        if (frame->format == AV_PIX_FMT_VIDEOTOOLBOX) { pixel = (CVPixelBufferRef)frame->data[3]; ++engine().hardwareFrames; }
        else {
            ++engine().softwareFrames;
            NSDictionary *attrs = @{(id)kCVPixelBufferIOSurfacePropertiesKey: @{}};
            if (CVPixelBufferCreate(kCFAllocatorDefault, frame->width, frame->height,
                    kCVPixelFormatType_32BGRA, (__bridge CFDictionaryRef)attrs, &pixel) != kCVReturnSuccess) { ++engine().pixelFailures; return; }
            owned = true;
            sws = sws_getCachedContext(sws, frame->width, frame->height, (AVPixelFormat)frame->format,
                    frame->width, frame->height, AV_PIX_FMT_BGRA, SWS_FAST_BILINEAR, nullptr, nullptr, nullptr);
            if (!sws || CVPixelBufferLockBaseAddress(pixel, 0) != kCVReturnSuccess) {
                ++engine().pixelFailures; CVPixelBufferRelease(pixel); return;
            }
            uint8_t *out[] = {(uint8_t *)CVPixelBufferGetBaseAddress(pixel), nullptr, nullptr, nullptr};
            int stride[] = {(int)CVPixelBufferGetBytesPerRow(pixel), 0, 0, 0};
            int rows = sws_scale(sws, frame->data, frame->linesize, 0, frame->height, out, stride);
            CVPixelBufferUnlockBaseAddress(pixel, 0);
            if (rows != frame->height) { ++engine().pixelFailures; CVPixelBufferRelease(pixel); return; }
        }
        if (pixel) {
            auto &e = engine(); std::lock_guard<std::mutex> l(e.mutex);
            if (e.active(g)) {
                double due = e.scheduleLocked(p, true), now = OBNow();
                e.lastVideoDelta = (due - now) * 1000.;
                if (obs::next::CommonPresentationClock::usable(due, now)) {
                    if (obs::enqueuePending(e.images, std::make_shared<Image>(pixel, due))) {
                        ++e.videos; e.lastVideo = now;
                    } else ++e.queueDrops;
                } else ++e.timingDrops;
            }
        }
        if (!pixel) ++engine().pixelFailures;
        if (owned) CVPixelBufferRelease(pixel);
    }
    void audio(uint64_t g) {
        double p = pts();
        if (!std::isfinite(p) || frame->nb_samples <= 0 || frame->nb_samples > 8192 ||
            frame->sample_rate < 8000 || frame->sample_rate > 96000 ||
            frame->ch_layout.nb_channels < 1 || frame->ch_layout.nb_channels > 2) return;
        auto &e=engine();double due=0;uint64_t epoch=0;
        if(!audioEngine)audioEngine.reset(new(std::nothrow) obs::next::FFmpegAudioTimeline);
        if(!audioEngine){std::lock_guard<std::mutex> lock(e.mutex);++e.audioEngineErrors;return;}
        {
            double waitStart=OBNow();std::lock_guard<std::mutex> lock(e.mutex);
            uint64_t waited=uint64_t(std::max(0.,OBNow()-waitStart)*1000000.);
            e.audioWaitMaxUS=std::max(e.audioWaitMaxUS,waited);e.audioWaitTotalUS+=waited;
            if(!e.active(g))return;
            due=e.scheduleLocked(p, false);epoch=e.clockEpoch+1;
        }
        bool changed=audioEpoch!=epoch || frame->sample_rate!=inputRate || frame->format!=inputFormat ||
            av_channel_layout_compare(&frame->ch_layout,&inputLayout);
        auto configure=[&] {
            if(!audioEngine->configure(frame->sample_rate,(AVSampleFormat)frame->format,frame->ch_layout,epoch))return false;
            av_channel_layout_uninit(&inputLayout);
            if(av_channel_layout_copy(&inputLayout,&frame->ch_layout)<0)return false;
            inputRate=frame->sample_rate;inputFormat=(AVSampleFormat)frame->format;audioEpoch=epoch;return true;
        };
        if(changed && !configure()){std::lock_guard<std::mutex> lock(e.mutex);++e.audioEngineErrors;return;}
        int planes=av_sample_fmt_is_planar((AVSampleFormat)frame->format)?frame->ch_layout.nb_channels:1;
        auto convert=[&]{return audioEngine->push((const uint8_t *const *)frame->extended_data,planes,frame->nb_samples,due,epoch);};
        auto result=convert();
        if(result==obs::next::AudioEngineResult::Discontinuity) {
            // A real missing/timestamp-jumped audio segment starts at its shared
            // A/V due time. Do not independently shift video or invent old PCM.
            {std::lock_guard<std::mutex> lock(e.mutex);++e.audioSegments;}
            if(configure())result=convert();
        }
        if(result!=obs::next::AudioEngineResult::Ok){std::lock_guard<std::mutex> lock(e.mutex);++e.audioEngineErrors;return;}
        while(audioEngine->available()) {
            obs::next::AudioEngineBlock block;
            if(audioEngine->pop(audioOutput.data(),int(audioOutput.size()),block)!=obs::next::AudioEngineResult::Ok || !block.frames)break;
            std::lock_guard<std::mutex> lock(e.mutex);
            if(!e.active(g) || e.clockEpoch+1!=epoch)return;
            double now=OBNow();e.lastAudioLeadMS=(block.masterTime-now)*1000.;
            if(block.masterTime>now-.25 && block.masterTime<now+.75) {
                OBBusWriteAudio(audioOutput.data(),size_t(block.frames),block.masterTime);++e.audios;
            } else ++e.audioLateDrops;
        }
    }

    void push(AVPacket *packet, uint64_t g, bool isVideo) {
        if (!ctx || packet->stream_index != stream->index) return;
        int rc = avcodec_send_packet(ctx, packet);
        if (rc == AVERROR(EAGAIN)) {
            while (avcodec_receive_frame(ctx, frame) >= 0) {
                @autoreleasepool { if (isVideo) video(g); else audio(g); }
                av_frame_unref(frame);
            }
            rc = avcodec_send_packet(ctx, packet);
        }
        if (rc < 0) return;
        while (avcodec_receive_frame(ctx, frame) >= 0) {
            @autoreleasepool { if (isVideo) video(g); else audio(g); }
            av_frame_unref(frame);
        }
    }
};

void decodeConnection(Reader &reader) {
    auto &e = engine();
    AVFormatContext *fmt = avformat_alloc_context();
    uint8_t *data = (uint8_t *)av_malloc(32768);
    AVIOContext *io = data ? avio_alloc_context(data, 32768, 0, &reader, Reader::read, nullptr, nullptr) : nullptr;
    if (!fmt || !io) {
        if (io) { av_freep(&io->buffer); avio_context_free(&io); } else av_free(data);
        avformat_free_context(fmt); e.noteFor(reader.generation, "内存不足"); return;
    }
    fmt->pb = io; fmt->flags |= AVFMT_FLAG_CUSTOM_IO;
    fmt->max_streams = 8;
    fmt->interrupt_callback = {Reader::interrupt, &reader};
    AVDictionary *opts = nullptr;
    av_dict_set(&opts, "probesize", "262144", 0);
    av_dict_set(&opts, "analyzeduration", "500000", 0);
    av_dict_set(&opts, "max_delay", "0", 0);
    const char *format=reader.rtmp?"flv":"mpegts";
    av_dict_set(&opts, "format_whitelist", format, 0);
    av_dict_set(&opts, "codec_whitelist", "h264,aac", 0);
    int rc = avformat_open_input(&fmt, nullptr, av_find_input_format(format), &opts);
    av_dict_free(&opts);
    if (rc >= 0) rc = avformat_find_stream_info(fmt, nullptr);
    if (rc >= 0) {
        Decoder video, audio;
        bool v = video.open(fmt, AVMEDIA_TYPE_VIDEO), a = audio.open(fmt, AVMEDIA_TYPE_AUDIO);
        if (!v && !a) e.noteFor(reader.generation, "没有可解码的 H.264/AAC 轨道");
        else {
            e.noteFor(reader.generation, v && a ? "已连接，H.264/AAC 解码中" : "已连接，但缺视频或音频轨道，不满足完整功能");
            AVPacket *packet = av_packet_alloc();
            if (packet) {
                while (e.active(reader.generation) && av_read_frame(fmt, packet) >= 0) {
                    video.push(packet, reader.generation, true);
                    audio.push(packet, reader.generation, false);
                    av_packet_unref(packet);
                }
                av_packet_free(&packet);
            }
        }
    } else {
        char text[AV_ERROR_MAX_STRING_SIZE]{}; av_strerror(rc, text, sizeof(text));
        NSString *error = [NSString stringWithFormat:@"MPEG-TS 打开/探测失败：%s (%d)", text, rc];
        e.noteFor(reader.generation, error.UTF8String);
        std::lock_guard<std::mutex> lock(e.mutex);
        if (e.generation.load() == reader.generation) e.lastError = error.UTF8String;
    }
    avformat_close_input(&fmt);
    // Custom AVIO remains owned by us; FFmpeg may have replaced its buffer.
    av_freep(&io->buffer); avio_context_free(&io);
    if (reader.receiveError) {
        NSString *error = [NSString stringWithFormat:@"recv 失败：errno=%d，%@", reader.receiveError,
            [NSString stringWithUTF8String:strerror(reader.receiveError)] ?: @"未知错误"];
        std::lock_guard<std::mutex> lock(e.mutex);
        if (e.generation.load() == reader.generation) e.lastError = error.UTF8String;
        NSLog(@"[OBSBridge] %@", error);
    }
}

void networkError(Engine &e, uint64_t g, const char *operation, int code) {
    NSString *message = [NSString stringWithFormat:@"%s 失败：errno=%d，%s", operation, code, strerror(code)];
    std::lock_guard<std::mutex> lock(e.mutex);
    if (e.generation.load() != g) return;
    e.message = message.UTF8String; e.lastError = e.message;
    e.listening = false; e.enabled = false;
    NSLog(@"[OBSBridge] %@", message);
}
void serve(NSString *ip, NSString *peer, uint64_t g) {
    auto &e = engine();
    if (!e.active(g)) return;
    sockaddr_in addr{}; addr.sin_len = sizeof(addr); addr.sin_family = AF_INET;
    addr.sin_port = htons(OB_PORT);
    in_addr allowed{};
    if (inet_pton(AF_INET, ip.UTF8String, &addr.sin_addr) != 1 ||
        inet_pton(AF_INET, peer.UTF8String, &allowed) != 1) {
        networkError(e, g, "IPv4", EINVAL); return;
    }
    int listener = socket(AF_INET, SOCK_STREAM, 0);
    if (listener < 0) { networkError(e, g, "socket", errno); return; }
    int yes = 1; setsockopt(listener, SOL_SOCKET, SO_REUSEADDR, &yes, sizeof(yes));
    if (bind(listener, (sockaddr *)&addr, sizeof(addr))) {
        int code = errno; close(listener); networkError(e, g, "bind", code); return;
    }
    if (listen(listener, 2)) {
        int code = errno; close(listener); networkError(e, g, "listen", code); return;
    }
    if (!nonblocking(listener)) {
        int code = errno; close(listener); networkError(e, g, "fcntl listener", code); return;
    }
    if (e.active(g)) e.listening = true;
    while (e.active(g)) {
        e.noteFor(g, "TCP 已监听，等待 OBS 连接（与摄像头/音频 Hook 独立）");
        sockaddr_in remote{}; socklen_t len = sizeof(remote);
        Reader reader(g); reader.fd = accept(listener, (sockaddr *)&remote, &len);
        if (reader.fd < 0) {
            if (errno == EINTR) continue;
            if (errno == EAGAIN || errno == EWOULDBLOCK) { waitNetwork(); continue; }
            networkError(e, g, "accept", errno); break;
        }
        char actual[INET_ADDRSTRLEN]{};
        inet_ntop(AF_INET, &remote.sin_addr, actual, sizeof(actual));
        { std::lock_guard<std::mutex> lock(e.mutex); e.lastPeer = actual; }
        if (remote.sin_addr.s_addr != allowed.s_addr) { ++e.rejected; continue; }
        if (!nonblocking(reader.fd)) {
            networkError(e, g, "fcntl connection", errno); break;
        }
        ++e.accepted;
        { std::lock_guard<std::mutex> lock(e.mutex); if (e.active(g)) e.clearLocked(); }
        @autoreleasepool { decodeConnection(reader); }
        { std::lock_guard<std::mutex> lock(e.mutex); if (e.active(g)) e.clearLocked(); }
    }
    close(listener);
    if (e.generation.load() == g) e.listening = false;
}

void pullRTMP(NSString *value,uint64_t g) {
    auto &e=engine();unsigned attempts=0;
    while(e.active(g)) {
        @autoreleasepool {try {
            auto url=obs::RtmpURL::parse(value.UTF8String?:"");Reader r(g);
            sockaddr_in address{};address.sin_len=sizeof(address);address.sin_family=AF_INET;
            address.sin_port=htons(url.port);inet_pton(AF_INET,url.host.c_str(),&address.sin_addr);
            r.fd=socket(AF_INET,SOCK_STREAM,0);
            if(r.fd<0 || !nonblocking(r.fd))throw std::runtime_error("RTMP socket/fcntl failed");
            int yes=1;setsockopt(r.fd,SOL_SOCKET,SO_NOSIGPIPE,&yes,sizeof(yes));
            e.noteFor(g,"RTMP 正在连接电脑服务器");
            int rc=connect(r.fd,(sockaddr *)&address,sizeof(address));
            if(rc && errno!=EINPROGRESS)throw std::runtime_error("RTMP connect failed");
            double deadline=OBNow()+8;
            while(rc) {
                if(!e.active(g) || OBNow()>deadline)throw std::runtime_error("RTMP connect cancelled or timeout");
                int error=0;socklen_t n=sizeof(error);
                if(getsockopt(r.fd,SOL_SOCKET,SO_ERROR,&error,&n) || error)throw std::runtime_error("RTMP socket connection error");
                sockaddr_in peer{};n=sizeof(peer);
                if(!getpeername(r.fd,(sockaddr *)&peer,&n))break;
                waitNetwork();
            }
            r.rtmp=std::make_unique<obs::RtmpPull>([&](uint8_t *data,size_t size){
                while(size){int n=Reader::raw(&r,data,int(size));if(n<=0)return false;data+=n;size-=size_t(n);}return true;
            },[&](const uint8_t *data,size_t size){
                double end=OBNow()+8;
                while(size && e.active(g) && OBNow()<end) {
                    ssize_t n=send(r.fd,data,size,0);
                    if(n>0){data+=n;size-=size_t(n);continue;}
                    if(n<0 && errno==EINTR)continue;
                    if(n<0 && (errno==EAGAIN || errno==EWOULDBLOCK)){waitNetwork();continue;}
                    return false;
                }return !size;
            });
            r.rtmp->start(url);++e.accepted;attempts=0;
            if(e.active(g))e.connected=true;
            {std::lock_guard<std::mutex> lock(e.mutex);e.lastPeer=url.host;e.lastError.clear();if(e.active(g))e.clearLocked();}
            decodeConnection(r);
        } catch(const std::exception &error) {
            std::lock_guard<std::mutex> lock(e.mutex);
            if(e.generation.load()==g)e.lastError=error.what();
        }}
        if(!e.active(g))break;
        e.connected=false;
        e.noteFor(g,"RTMP 已断开或流未就绪，等待重连；不会停止并恢复真实摄像头");
        double until=OBNow()+std::min(15u,2u+(++attempts)*2u);
        while(e.active(g) && OBNow()<until)waitNetwork();
    }
}

}

BOOL OBEnabled(void) { return engine().enabled.load(); }
NSDictionary *OBReceiveCounters(void) {
    auto &e=engine();return @{@"bytes":@(e.bytes.load()),@"videos":@(e.videos.load()),
        @"receiving":@(e.enabled.load() && OBNow()-e.lastVideo.load()<3)};
}
NSDictionary *OBLogSnapshot(void) {
    auto &e=engine();NSMutableDictionary *d;
    {
        std::lock_guard<std::mutex> lock(e.mutex);
        d=[@{@"enabled":@(e.enabled.load()),@"connected":@(e.connected.load()),@"rtmp":@(e.rtmpMode.load()),
            @"generation":@(e.generation.load()),@"clock_epoch":@(e.clockEpoch),@"bytes":@(e.bytes.load()),
            @"accepted":@(e.accepted.load()),@"rejected":@(e.rejected.load()),@"video_in":@(e.videos.load()),@"audio_in":@(e.audios.load()),
            @"published":@(e.published.load()),@"publish_failed":@(e.publishFailed.load()),@"ticks":@(e.ticks.load()),
            @"queue_depth":@(e.images.size()),@"queue_head_ms":@(e.images.empty()?0:(e.images.front()->due-OBNow())*1000.),
            @"queue_drops":@(e.queueDrops.load()),@"clock_resets":@(e.clockResets.load()),@"decoded_video":@(e.decodedVideo.load()),
            @"invalid_video":@(e.invalidVideo.load()),@"pixel_failures":@(e.pixelFailures.load()),@"video_timing_drops":@(e.timingDrops.load()),
            @"video_lead_ms":@(e.lastVideoDelta.load()),@"audio_lead_ms":@(e.lastAudioLeadMS),@"render_ms":@(e.lastRenderMS),
            @"audio_wait_max_us":@(e.audioWaitMaxUS),@"audio_wait_total_us":@(e.audioWaitTotalUS),@"audio_late_drops":@(e.audioLateDrops),
            @"obsolete_video":@(e.obsoleteVideo),@"budget_drops":@(e.budgetDrops.load()),@"hardware_frames":@(e.hardwareFrames.load()),
            @"software_frames":@(e.softwareFrames.load()),@"clock_rate_ppm":@(e.clock.stats.ratePPM),@"clock_phase_ms":@(e.clock.stats.lastPhaseMS),
            @"estimated_source_s":@(e.clock.sourceForHost(OBNow())),
            @"clock_fits":@(e.clock.stats.fits),@"clock_rejected_fits":@(e.clock.stats.rejectedFits),@"audio_segments":@(e.audioSegments),
            @"audio_engine_errors":@(e.audioEngineErrors),@"capture_feedback_state":@(unsigned(e.captureState)),
            @"capture_fresh":@(e.nativeCapture.fresh(OBNow())),@"capture_rate_ppm":@((e.nativeCapture.ratio-1.)*1e6),
            @"network_error_present":@(!e.lastError.empty())} mutableCopy];
    }
    // Keep IPC out of the engine lock, and arbitrary URLs/error messages out
    // of the journal entirely. No config/Pairing dictionary is serialized.
    d[@"media"]=OBMediaLogSnapshot();d[@"live"]=OBLiveAudioLogSnapshot();
    d[@"thermal_state"]=@(NSProcessInfo.processInfo.thermalState);
    d[@"quality_profile"]=@(OBBusVideoProfile());return d;
}
void OBStart(NSString *ip, NSString *peer) {
    OBStop(); auto &e = engine();
    e.rtmpMode=false;
    e.decodedVideo=0;e.invalidVideo=0;e.pixelFailures=0;e.timingDrops=0;e.lastVideoDelta=0;e.lastVideo=0;
    { std::lock_guard<std::mutex> lock(e.mutex);
      e.audioWaitMaxUS=e.audioWaitTotalUS=e.audioLateDrops=e.obsoleteVideo=0;
      e.lastAudioLeadMS=e.lastRenderMS=0; }
    uint64_t g = ++e.generation;
    e.videos = 0; e.audios = 0; e.bytes = 0; e.accepted = 0; e.rejected = 0;
    e.published = 0; e.publishFailed = 0;
    e.ticks = 0; e.clockResets = 0; e.queueDrops = 0;
    e.budgetDrops = 0; e.hardwareFrames = 0; e.softwareFrames = 0;
    { std::lock_guard<std::mutex> lock(e.mutex);
      e.lastError.clear(); e.lastPeer.clear(); e.message = "启动请求已处理，正在创建 TCP 接收端"; }
    OBBusEnable(YES); e.enabled = true;
    dispatch_async(e.queue, ^{ @autoreleasepool { serve(ip, peer, g); } });
}
void OBStartRTMP(NSString *url) {
    try {(void)obs::RtmpURL::parse(url.UTF8String?:"");}
    catch(const std::exception &error){engine().note(error.what());return;}
    OBStop();auto &e=engine();uint64_t g=++e.generation;
    e.rtmpMode=true;
    e.decodedVideo=0;e.invalidVideo=0;e.pixelFailures=0;e.timingDrops=0;e.lastVideoDelta=0;e.lastVideo=0;
    { std::lock_guard<std::mutex> lock(e.mutex);
      e.audioWaitMaxUS=e.audioWaitTotalUS=e.audioLateDrops=e.obsoleteVideo=0;
      e.lastAudioLeadMS=e.lastRenderMS=0; }
    e.videos=0;e.audios=0;e.bytes=0;e.accepted=0;e.rejected=0;e.published=0;e.publishFailed=0;
    e.clockResets=0;e.queueDrops=0;e.ticks=0;e.budgetDrops=0;e.hardwareFrames=0;e.softwareFrames=0;
    OBBusEnable(YES);e.enabled=true;
    dispatch_async(e.queue,^{@autoreleasepool{pullRTMP(url,g);}});
}
void OBStop(void) {
    auto &e = engine(); e.enabled = false; e.listening = false; e.connected = false; ++e.generation;
    std::lock_guard<std::mutex> lock(e.mutex);
    OBBusEnable(NO); e.clearLocked(); e.message = "已停止接收和共享输出，系统节点透传真实输入";
}
void OBProducerTick(void) {
    OBBusHeartbeat(); auto &e = engine(); ++e.ticks;
    if (!e.enabled.load()) { OBBusEnable(NO); return; }
    // Feedback IPC is background-only, bounded to 2Hz and outside the receiver
    // audio/video mutex. Host time is the shared A/V master; per-unit native
    // feedback drives the background output resampler in the live process.
    double pollTime=OBNow();bool pollCapture=false;
    {
        std::lock_guard<std::mutex> lock(e.mutex);
        if(pollTime-e.lastCapturePoll>=.5){e.lastCapturePoll=pollTime;pollCapture=true;}
    }
    if(pollCapture) {
        uint64_t cookie=0;uint32_t busGeneration=0;obs::next::CaptureClockSnapshot snapshot;
        auto state=OBBusProducerIdentity(cookie,busGeneration)?OBReadCaptureClock(cookie,busGeneration,OBNow(),snapshot):
            obs::next::CaptureFeedbackState::Unavailable;
        std::lock_guard<std::mutex> lock(e.mutex);
        uint64_t currentCookie=0;uint32_t currentGeneration=0;
        if(OBBusProducerIdentity(currentCookie,currentGeneration) && currentCookie==cookie && currentGeneration==busGeneration) {
            e.nativeCapture=snapshot;e.captureState=state;
        } else {e.nativeCapture={};e.captureState=obs::next::CaptureFeedbackState::Stale;}
    }
    std::shared_ptr<Image> image;
    uint64_t generation = 0, epoch = 0;
    {
        std::lock_guard<std::mutex> lock(e.mutex);
        double now = OBNow();
        while (!e.images.empty() && e.images.front()->due <= now) {
            e.current = e.images.front(); e.images.pop_front();
        }
        if (!e.current || e.current == e.publishedImage || now - e.current->due >= .5) return;
        image = e.current; generation = e.generation.load(); epoch = e.clockEpoch;
    }
    // GPU render + CPU pixel copy must NOT hold the receive/audio clock mutex.
    // The producer dispatch queue serializes the staging buffers and command processing.
    OBVideoPublication publication;
    double started = OBNow();
    BOOL prepared = OBBusPrepareVideo(image->pixel, image->due, publication);
    double elapsed = (OBNow() - started) * 1000.;
    {
        std::lock_guard<std::mutex> lock(e.mutex);
        e.lastRenderMS = elapsed;
        if (!obs::publicationCurrent(generation, epoch, e.generation.load(), e.clockEpoch, e.enabled.load())) {
            ++e.obsoleteVideo; return; // lease destructor invalidates/releases the unpublished staging slot
        }
        if (prepared && OBBusCommitVideo(publication)) { ++e.published; e.publishedImage = image; }
        else ++e.publishFailed;
    }
}

NSString *OBStatus(void) {
    auto &e = engine(); std::lock_guard<std::mutex> lock(e.mutex);
    NSString *message = [NSString stringWithUTF8String:e.message.c_str()] ?: @"状态编码无效";
    NSString *lastError = e.lastError.empty() ? @"无" : [NSString stringWithUTF8String:e.lastError.c_str()];
    NSString *lastPeer = [NSString stringWithUTF8String:e.lastPeer.c_str()] ?: @"";
    double headWait = e.images.empty() ? 0 : (e.images.front()->due - OBNow()) * 1000;
    NSString *link=e.rtmpMode.load()?[NSString stringWithFormat:@"RTMP 主动拉流：%@",!e.enabled.load()?@"已停止":OBNow()-e.lastVideo.load()<3?@"近期有视频":e.connected.load()?@"已连接 / 暂无可发布视频":@"等待流 / 重连"]:
        [NSString stringWithFormat:@"OBS TCP监听：%@",e.listening?@"是":@"否"];
    NSString *capture=e.captureState==obs::next::CaptureFeedbackState::Ready && e.nativeCapture.fresh(OBNow())?
        [NSString stringWithFormat:@"采音时钟反馈：有效，速差 %+.3f ppm",(e.nativeCapture.ratio-1.)*1e6]:
        @"采音时钟反馈：等待频率校准；原生预备输出可先按有效时间戳工作";
    return [NSString stringWithFormat:@"OBSBridge %@ · SpringBoard 接收层\n%@\n%@；收包 %llu 字节\n连接 %llu / 拒绝 %llu；最近来源 %@\n有效入队：视频 %llu / 音频 %llu\n共享发布 %llu / 发布失败 %llu\n调度 %llu；队列 %zu / 队首 %.0f ms\n丢帧 %llu / 时钟重置 %llu\n最近网络错误：%@\n%@\n\n%@",
        OB_VERSION, message, link,
        (unsigned long long)e.bytes.load(), (unsigned long long)e.accepted.load(),
        (unsigned long long)e.rejected.load(), lastPeer,
        (unsigned long long)e.videos.load(), (unsigned long long)e.audios.load(),
        (unsigned long long)e.published.load(), (unsigned long long)e.publishFailed.load(),
        (unsigned long long)e.ticks.load(), e.images.size(), headWait,
        (unsigned long long)e.queueDrops.load(), (unsigned long long)e.clockResets.load(),
        lastError ?: @"错误编码无效", [NSString stringWithFormat:@"%@\n%@\n共同时间轴：速差 %+.3f ppm / 拟合 %llu / 拒绝 %llu\n音频片段重建 %llu / 引擎错误 %llu",OBBusProducerStatus(),capture,e.clock.stats.ratePPM,
            (unsigned long long)e.clock.stats.fits,(unsigned long long)e.clock.stats.rejectedFits,
            (unsigned long long)e.audioSegments,(unsigned long long)e.audioEngineErrors],
        [NSString stringWithFormat:@"%@\n解码输出 %llu；无效帧 %llu；像素失败 %llu\n时序丢弃 %llu；最近视频提前量 %.0f ms\n音频写入等锁 最长 %llu us / 累计 %llu us；音频时序丢弃 %llu\n最近音频提前量 %.1f ms；画面准备 %.1f ms；过期画面取消 %llu\n节流丢帧 %llu；节流后硬解 %llu / 软解 %llu\n画质档 %@；热状态 %ld\n\n%@",
            OBMediaStatus(), (unsigned long long)e.decodedVideo.load(), (unsigned long long)e.invalidVideo.load(),
            (unsigned long long)e.pixelFailures.load(), (unsigned long long)e.timingDrops.load(), e.lastVideoDelta.load(),
            (unsigned long long)e.audioWaitMaxUS, (unsigned long long)e.audioWaitTotalUS,
            (unsigned long long)e.audioLateDrops, e.lastAudioLeadMS, e.lastRenderMS, (unsigned long long)e.obsoleteVideo,
            (unsigned long long)e.budgetDrops.load(), (unsigned long long)e.hardwareFrames.load(),
            (unsigned long long)e.softwareFrames.load(), OBBusVideoProfile()==2?@"源画质（最高1080p/60fps，过热会降档）":OBBusVideoProfile()==1?@"720p/30fps":@"540p/30fps",
            (long)NSProcessInfo.processInfo.thermalState, OBLiveAudioStatus()]];
}
