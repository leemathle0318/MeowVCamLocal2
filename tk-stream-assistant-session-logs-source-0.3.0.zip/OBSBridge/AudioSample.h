#pragma once
#import <Foundation/Foundation.h>
#import <CoreMedia/CoreMedia.h>
#import <AudioToolbox/AudioToolbox.h>
// Copies all channel planes into independent owned storage. Keeps the original
// ASBD, sample count, timing entries and attachments; never changes source data.
FOUNDATION_EXPORT CMSampleBufferRef OBCopyMixedAudioSample(CMSampleBufferRef source,
    const AudioBufferList *mixed, OSStatus *status) CF_RETURNS_RETAINED;
// Query CoreMedia's actual required metadata size before extracting; do not
// assume channel count alone specifies the runtime's allocation contract.
enum { OBAudioListCapacity = 4096 };
typedef struct { OSStatus queryStatus, fillStatus; unsigned stage, inputBuffers; } OBAudioListReport;
FOUNDATION_EXPORT OSStatus OBGetAudioBufferList(CMSampleBufferRef source,
    AudioBufferList *list, size_t capacity, size_t *needed, CMBlockBufferRef *retained,
    OBAudioListReport *report
#ifdef __cplusplus
    = nullptr
#endif
);
