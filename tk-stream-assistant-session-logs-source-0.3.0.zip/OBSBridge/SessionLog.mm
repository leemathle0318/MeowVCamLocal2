#import "SessionLog.h"
#import "Shared.h"
#import "Receiver.h"
#include "core/SessionJournal.hpp"
#include <atomic>
#include <algorithm>
#include <mutex>
#include <memory>
#include <fcntl.h>
#include <sys/stat.h>
#include <unistd.h>
#include <cerrno>
#include <cmath>

namespace {
constexpr uint64_t cap=OB_LOG_LIMIT;
dispatch_queue_t logQueue;
dispatch_source_t logTimer;
std::unique_ptr<obs::SessionJournal> journal;
std::mutex stateLock;
NSDictionary *published=@{};
NSString *lastRequest, *boot;
uint64_t sequence=0, recoveredTail=0, ioErrors=0;
uint64_t overdueSamples=0;
double maxSampleGap=0;
std::atomic<unsigned> pending{0};
std::atomic<uint64_t> rejected{0};
double lastSample=-1e30;
NSDictionary *previous;
NSInteger lastError=0;
NSString *ack=@"", *ackAction=@"";
bool ackOK=false;

// Fixed paths only. Do not follow links or accept group/other writable files.
int openSafe(const char *path, int flags, mode_t mode) {
    int fd=open(path,flags|O_NOFOLLOW|O_CLOEXEC,mode);
    if(fd<0)return -1;
    struct stat st{};
    if(fstat(fd,&st) || !S_ISREG(st.st_mode) || st.st_nlink!=1 ||
       (st.st_uid!=geteuid() && st.st_uid!=0) || (st.st_mode&0022)) {
        close(fd);errno=EPERM;return -1;
    }
    return fd;
}
id finiteJSON(id value) {
    if([value isKindOfClass:NSNumber.class])return std::isfinite([value doubleValue])?value:NSNull.null;
    if([value isKindOfClass:NSDictionary.class]) {
        NSMutableDictionary *safe=[NSMutableDictionary dictionary];
        for(NSString *key in value)safe[key]=finiteJSON(value[key]);return safe;
    }
    if([value isKindOfClass:NSArray.class]) {
        NSMutableArray *safe=[NSMutableArray array];for(id item in value)[safe addObject:finiteJSON(item)];return safe;
    }
    return value;
}
std::string jsonLine(NSDictionary *record) {
    NSData *data=nil;
    @try {data=[NSJSONSerialization dataWithJSONObject:finiteJSON(record) options:0 error:nil];}
    @catch(NSException *exception){(void)exception;return {};}
    if(!data)return {};
    std::string text(static_cast<const char *>(data.bytes),data.length);text+='\n';return text;
}
NSDictionary *state() {
    return @{@"Schema":@1,@"Revision":@(OB_VERSION_CODE),@"Bytes":@(journal?journal->bytes():0),@"Cap":@(cap),
        @"Full":@(journal && journal->full),@"WriteErrors":@(ioErrors+(journal?journal->errors:0)),
        @"Dropped":@(rejected.load()+(journal?journal->dropped:0)),@"RecoveredTailBytes":@(recoveredTail),
        @"OverdueSamples":@(overdueSamples),@"MaxSampleGapSeconds":@(maxSampleGap),
        @"ErrorCode":@(lastError),@"Ready":@(bool(journal)),@"Date":@([NSDate date].timeIntervalSince1970),
        @"Ack":ack?:@"",@"Action":ackAction?:@"",@"OK":@(ackOK)};
}
void publish() {NSDictionary *value=state();std::lock_guard<std::mutex> lock(stateLock);published=value;}
void record(NSString *kind,NSDictionary *values) {
    NSMutableDictionary *row=[@{@"schema":@1,@"event":kind,@"boot":boot?:@"",@"seq":@(++sequence),
        @"unix_s":@([NSDate date].timeIntervalSince1970),@"host_s":@(OBNow())} mutableCopy];
    [row addEntriesFromDictionary:values?:@{}];
    if(journal && !journal->append(jsonLine(row)))lastError=journal->full?EFBIG:EIO;
}
void openJournal() {
    int fd=openSafe(OB_LOG_FILE,O_CREAT|O_RDWR,0600);
    if(fd<0){lastError=errno;++ioErrors;return;}
    if(fchmod(fd,0600)){lastError=errno;++ioErrors;close(fd);return;}
    struct stat info{};
    if(fstat(fd,&info) || info.st_size<0 || uint64_t(info.st_size)>cap){lastError=EFBIG;++ioErrors;close(fd);return;}
    // A killed SpringBoard may leave one partial JSON line. Retain all complete
    // records, truncate only the incomplete tail, and report its byte count.
    if(info.st_size) {
        char tail[16384];off_t start=info.st_size>off_t(sizeof(tail))?info.st_size-off_t(sizeof(tail)):0;
        ssize_t n=pread(fd,tail,size_t(info.st_size-start),start);
        if(n!=info.st_size-start){lastError=EIO;++ioErrors;close(fd);return;}
        if(tail[n-1]!='\n') {
            ssize_t i=n-1;while(i>=0 && tail[i]!='\n')--i;
            if(i<0 && start){lastError=EINVAL;++ioErrors;close(fd);return;}
            off_t end=start+i+1;recoveredTail+=uint64_t(info.st_size-end);
            if(ftruncate(fd,end)){lastError=errno;++ioErrors;close(fd);return;}
            info.st_size=end;
        }
    }
    FILE *file=fdopen(fd,"r+");
    if(!file){lastError=errno;++ioErrors;close(fd);return;}
    journal=std::make_unique<obs::SessionJournal>(file,uint64_t(info.st_size),cap);
    record(@"process_start",@{@"revision":@(OB_VERSION_CODE),@"version":OB_VERSION,
        @"pid":@(getpid()),@"ios":NSProcessInfo.processInfo.operatingSystemVersionString,
        @"recovered_tail_bytes":@(recoveredTail),@"preexisting_bytes":@(info.st_size),
        @"active_interval_s":@5,@"idle_interval_s":@60,@"byte_cap":@(cap)});
}
void sample(NSString *reason) {
    double started=OBNow();NSDictionary *snapshot=OBLogSnapshot();
    double gap=lastSample<0?0:started-lastSample;
    maxSampleGap=std::max(maxSampleGap,gap);
    if(previous && [previous[@"enabled"] isEqual:snapshot[@"enabled"]] && [previous[@"generation"] isEqual:snapshot[@"generation"]]) {
        double expected=[snapshot[@"enabled"] boolValue]?5.:60.;
        if(gap>expected*2.)overdueSamples+=uint64_t(gap/expected)-1;
    }
    NSMutableArray *changed=[NSMutableArray array];
    for(NSString *key in @[@"enabled",@"connected",@"generation",@"clock_epoch",@"accepted",@"clock_resets",@"audio_segments",@"audio_engine_errors"])
        if(previous && ![previous[key] isEqual:snapshot[key]])[changed addObject:key];
    record(@"snapshot",@{@"reason":reason,@"metrics":snapshot,@"changed":changed,
        @"sample_cost_ms":@((OBNow()-started)*1000.),@"sample_gap_s":@(gap)});
    previous=snapshot;lastSample=started;publish();
}
bool exportJournal() {
    if(!journal){lastError=ENOENT;return false;}
    const char *temp=OB_LOG_EXPORT_TEMP;
    // A fixed staging name is safe because there is exactly one serial writer.
    // Existing files are checked BEFORE truncation, including hard links.
    int fd=openSafe(temp,O_CREAT|O_RDWR,0644);
    if(fd<0){lastError=errno;return false;}
    if(ftruncate(fd,0) || fchmod(fd,0644)){lastError=errno;close(fd);return false;}
    FILE *out=fdopen(fd,"w");
    if(!out){lastError=errno;close(fd);return false;}
    bool ok=journal->copyTo(out);
    NSDictionary *manifest=@{@"schema":@1,@"event":@"export_manifest",@"unix_s":@([NSDate date].timeIntervalSince1970),
        @"revision":@(OB_VERSION_CODE),@"state":state(),
        @"no_detected_record_loss_in_this_process":@(!journal->full && !journal->dropped && !journal->errors && !ioErrors && !rejected.load() && !recoveredTail && !overdueSamples),
        @"scope":@"plugin numeric diagnostics; not recordings, system logs or audience confirmation"};
    auto footer=jsonLine(manifest);
    ok=ok && !footer.empty() && fwrite(footer.data(),1,footer.size(),out)==footer.size();
    if(fflush(out) || fsync(fd))ok=false;
    if(fclose(out))ok=false;
    if(ok && rename(temp,OB_LOG_EXPORT_FILE)==0){lastError=0;return true;}
    lastError=errno?:EIO;unlink(temp);return false;
}
bool enqueue(dispatch_block_t block) {
    unsigned n=pending.fetch_add(1);
    if(n>=16){pending.fetch_sub(1);++rejected;return false;}
    dispatch_async(logQueue,^{@autoreleasepool{block();}pending.fetch_sub(1);});return true;
}
}
NSDictionary *OBLogState(void){std::lock_guard<std::mutex> lock(stateLock);return published;}
void OBLogInitialize(void) {
    logQueue=dispatch_queue_create("local.xiaoguai.obsbridge.session-log",DISPATCH_QUEUE_SERIAL);
    dispatch_set_target_queue(logQueue,dispatch_get_global_queue(QOS_CLASS_UTILITY,0));
    boot=NSUUID.UUID.UUIDString;
    NSDictionary *config=[NSDictionary dictionaryWithContentsOfFile:OB_CONFIG];lastRequest=config[@"LogRequestID"];
    dispatch_async(logQueue,^{@autoreleasepool{openJournal();publish();}});
    logTimer=dispatch_source_create(DISPATCH_SOURCE_TYPE_TIMER,0,0,logQueue);
    dispatch_source_set_timer(logTimer,dispatch_time(DISPATCH_TIME_NOW,NSEC_PER_SEC),NSEC_PER_SEC,NSEC_PER_SEC/5);
    dispatch_source_set_event_handler(logTimer,^{@autoreleasepool{
        if(OBNow()-lastSample>=(OBEnabled()?5.:60.))sample(@"periodic");
    }});dispatch_resume(logTimer);
}
void OBLogHandleConfig(NSDictionary *config) {
    NSString *request=config[@"LogRequestID"],*action=config[@"LogAction"];NSDate *date=config[@"LogRequestDate"];
    if(![request isKindOfClass:NSString.class] || request.length>64 || ![[NSUUID alloc] initWithUUIDString:request] || [request isEqual:lastRequest] ||
       ![date isKindOfClass:NSDate.class] || fabs(date.timeIntervalSinceNow)>30 ||
       ![action isKindOfClass:NSString.class] ||
       ![@[@"mark",@"export",@"clear"] containsObject:action])return;
    if(enqueue(^{
        ack=request;ackAction=action;ackOK=false;
        if([action isEqual:@"clear"]) {
            // Never touch the media cache or configuration. Clearing logs does
            // NOT stop/seek/reconnect reception or change the source clock.
            journal.reset();lastError=0;ioErrors=0;recoveredTail=0;rejected=0;overdueSamples=0;maxSampleGap=0;previous=nil;lastSample=-1e30;
            for(NSString *path in @[@OB_LOG_EXPORT_FILE,@OB_LOG_EXPORT_TEMP])
                if(unlink(path.fileSystemRepresentation) && errno!=ENOENT){lastError=errno;++ioErrors;}
            int fd=openSafe(OB_LOG_FILE,O_CREAT|O_RDWR,0600);
            if(fd>=0){if(ftruncate(fd,0)){lastError=errno;++ioErrors;}close(fd);}
            else {lastError=errno;++ioErrors;}
            if(!ioErrors){openJournal();record(@"user_clear",@{});}
            ackOK=bool(journal) && !ioErrors;
        }else {
            sample([action isEqual:@"mark"]?@"user_mark":@"before_export");
            if([action isEqual:@"mark"]){record(@"audience_stutter_mark",@{});ackOK=journal && !journal->full && !journal->errors;}
            else ackOK=exportJournal();
        }
        publish();
    }))lastRequest=request;
}
void OBLogCommandEvent(BOOL enabled,BOOL rtmp) {
    enqueue(^{record(@"receiver_command",@{@"enabled":@(enabled),@"rtmp":@(rtmp)});publish();});
}
