#import "Client.h"
#import "Shared.h"
#if OB_CONTROL_IN_SPRINGBOARD
#import "Receiver.h"
#endif
#include <notify.h>
#include <ifaddrs.h>
#include <arpa/inet.h>
#include <sys/stat.h>
#include <string.h>
#include <math.h>
#include <errno.h>

// Both control UIs and mediaserverd use this explicit shared path. A successful
// CFPreferences synchronize is not proof that this particular file was written.
static NSMutableDictionary *OBCReadConfig(void) {
    return [[NSDictionary dictionaryWithContentsOfFile:OB_CONFIG] mutableCopy] ?: [NSMutableDictionary dictionary];
}
static NSString *OBCWriteConfig(NSDictionary *config) {
    NSError *error = nil;
    NSData *data = [NSPropertyListSerialization dataWithPropertyList:config
        format:NSPropertyListBinaryFormat_v1_0 options:0 error:&error];
    if (!data) return [NSString stringWithFormat:@"无法生成控制配置：%@ (%@/%ld)",
        error.localizedDescription ?: @"未知错误", error.domain ?: @"", (long)error.code];
    if (![data writeToFile:OB_CONFIG options:NSDataWritingAtomic error:&error])
        return [NSString stringWithFormat:@"无法写入共享配置：%@\n%@ (%@/%ld)\n暂未发送通知。",
            OB_CONFIG, error.localizedDescription ?: @"未知错误", error.domain ?: @"", (long)error.code];
    if (chmod(OB_CONFIG.fileSystemRepresentation, 0644) != 0) {
        int code = errno;
        return [NSString stringWithFormat:@"配置已保存，但无法设置读取权限：%s (errno %d)\n暂未发送通知。",
            strerror(code), code];
    }
    NSDictionary *saved = [NSDictionary dictionaryWithContentsOfFile:OB_CONFIG];
    if (![saved isEqualToDictionary:config])
        return @"共享配置写入后校验失败，暂未发送通知。请截图此提示。";
    return nil;
}
NSDictionary *OBCLogStatus(void) {
    NSDictionary *status=[NSDictionary dictionaryWithContentsOfFile:OB_STATUS];
    NSDate *date=status[@"Date"];
    if(![date isKindOfClass:NSDate.class] || fabs(date.timeIntervalSinceNow)>12)return @{};
    NSDictionary *log=status[@"Log"];
    return [log isKindOfClass:NSDictionary.class]?log:@{};
}
NSString *OBCLogCommand(NSString *action,NSString *requestID) {
    if(![action isKindOfClass:NSString.class] || ![@[@"mark",@"export",@"clear"] containsObject:action] ||
       ![requestID isKindOfClass:NSString.class] || requestID.length>64 || ![[NSUUID alloc] initWithUUIDString:requestID])return @"无效的日志操作";
    NSMutableDictionary *config=OBCReadConfig();
    config[@"LogAction"]=action;config[@"LogRequestID"]=requestID;config[@"LogRequestDate"]=[NSDate date];
    // Deliberately do not touch Enabled / RequestID / RequestDate / RTMPURL.
    NSString *error=OBCWriteConfig(config);
    if(error)return error;
    uint32_t rc=notify_post(OB_NOTIFY);
    return rc?[NSString stringWithFormat:@"日志通知发送失败 %u；接收层仍会轮询日志请求",rc]:nil;
}

NSString *OBCWiFiIP(void) {
    struct ifaddrs *list = NULL; NSString *ip = nil;
    if (!getifaddrs(&list)) {
        for (struct ifaddrs *p = list; p; p = p->ifa_next) {
            if (!p->ifa_addr || p->ifa_addr->sa_family != AF_INET || strcmp(p->ifa_name, "en0")) continue;
            char value[INET_ADDRSTRLEN];
            if (inet_ntop(AF_INET, &((struct sockaddr_in *)p->ifa_addr)->sin_addr, value, sizeof(value)))
                ip = [NSString stringWithUTF8String:value];
        }
        freeifaddrs(list);
    }
    return ip;
}
NSString *OBCPeerIP(void) {
    id value = OBCReadConfig()[@"PCIP"];
    return [value isKindOfClass:NSString.class] ? value : @"";
}
NSString *OBCSavePeerIP(NSString *peer) {
    NSString *trimmed = [peer stringByTrimmingCharactersInSet:NSCharacterSet.whitespaceAndNewlineCharacterSet];
    NSMutableDictionary *config = OBCReadConfig();
    config[@"PCIP"] = trimmed ?: @"";
    return OBCWriteConfig(config);
}
NSInteger OBCVideoRotation(void) {
    id value = OBCReadConfig()[@"VideoRotation"];
    return [value isKindOfClass:NSNumber.class] ? (value ? [value unsignedIntegerValue] & 3 : 0) : 0;
}
NSString *OBCSetVideoRotation(NSInteger turns) {
    NSMutableDictionary *config = OBCReadConfig();
    config[@"VideoRotation"] = @(turns & 3);
    NSString *error = OBCWriteConfig(config);
    if (error) return error;
    if (notify_post(OB_NOTIFY) != NOTIFY_STATUS_OK) return @"方向已保存，通知失败；接收层将轮询读取。";
    return nil;
}
NSString *OBCURL(void) {
    NSString *ip = OBCWiFiIP();
    return ip ? [NSString stringWithFormat:@"tcp://%@:%d", ip, OB_PORT] : nil;
}
NSInteger OBCVideoProfile(void) {
    id value=OBCReadConfig()[@"VideoProfile"];
    NSInteger profile=[value isKindOfClass:NSNumber.class]?[value integerValue]:2;
    return profile>=0 && profile<=2?profile:2;
}
NSString *OBCSetVideoProfile(NSInteger profile) {
    NSMutableDictionary *config = OBCReadConfig(); config[@"VideoProfile"] = @(profile>=0 && profile<=2?profile:2);
    NSString *error = OBCWriteConfig(config); if (error) return error;
    notify_post(OB_NOTIFY); return nil;
}
BOOL OBCLiveAudioEnabled(void) {
    id value = OBCReadConfig()[@"LiveAudio"];
    return ![value isKindOfClass:NSNumber.class] || [value boolValue];
}
NSString *OBCSetLiveAudioEnabled(BOOL enabled) {
    NSMutableDictionary *config = OBCReadConfig(); config[@"LiveAudio"] = @(enabled);
    NSString *error = OBCWriteConfig(config); if (error) return error;
    notify_post(OB_NOTIFY); return nil;
}
NSString *OBCSendCommand(BOOL enabled, NSString *peer) {
    NSString *ip = OBCWiFiIP();
    NSString *trimmed = [peer stringByTrimmingCharactersInSet:NSCharacterSet.whitespaceAndNewlineCharacterSet];
    struct in_addr address;
    if (enabled && (!ip || !trimmed || inet_pton(AF_INET, trimmed.UTF8String, &address) != 1))
        return @"请连接 Wi-Fi，并填写 OBS 电脑的局域网 IPv4（不是手机 IP）。";
    NSMutableDictionary *config = OBCReadConfig();
    if (enabled) config[@"PCIP"] = trimmed;
    config[@"Enabled"] = @(enabled);
    if(enabled) config[@"Mode"]=@"OBS";
    config[@"BindIP"] = ip ?: @"";
    NSString *request = NSUUID.UUID.UUIDString;
    config[@"RequestID"] = request;
    config[@"RequestDate"] = [NSDate date];
    NSString *error = OBCWriteConfig(config);
    if (error) return error;
    if (notify_post(OB_NOTIFY) != NOTIFY_STATUS_OK) return @"命令已保存，但通知发送失败。";
    return nil;
}
NSString *OBCStatus(void) {
#if OB_CONTROL_IN_SPRINGBOARD
    return OBControlStatus(); // Direct status, not inferred from a missing file.
#else
    NSDictionary *status = [NSDictionary dictionaryWithContentsOfFile:OB_STATUS];
    NSDate *date = status[@"Date"];
    if (![date isKindOfClass:NSDate.class] || fabs(date.timeIntervalSinceNow) > 8)
        return @"接收服务状态暂时不可读，请检查插件安装及状态文件权限。";
    NSString *text = status[@"Text"];
    return [text isKindOfClass:NSString.class] ? text : @"媒体服务状态格式错误。";
#endif
}
NSString *OBCAudioStatus(void) {
#if OB_CONTROL_IN_SPRINGBOARD
    extern NSString *OBLiveAudioStatus(void);
    return [NSString stringWithFormat:@"%@\n\n%@", OBMediaAudioStatus(), OBLiveAudioStatus()];
#else
    return @"请在桌面应用的状态页查看音频诊断。";
#endif
}

NSString *OBCRtmpURL(void) { id v=OBCReadConfig()[@"RTMPURL"];return [v isKindOfClass:NSString.class]?v:@""; }
NSDictionary *OBCTransform(void) { id v=OBCReadConfig()[@"Transform"];return [v isKindOfClass:NSDictionary.class]?v:@{}; }
NSString *OBCSaveTransform(NSDictionary *values) {
    NSMutableDictionary *c=OBCReadConfig();c[@"Transform"]=values;
    NSString *e=OBCWriteConfig(c);if(!e)notify_post(OB_NOTIFY);return e;
}
NSDictionary *OBCPairing(void) { id v=OBCReadConfig()[@"Pairing"];return [v isKindOfClass:NSDictionary.class]?v:@{}; }
NSString *OBCSavePairing(NSDictionary *values) {
    NSMutableDictionary *c=OBCReadConfig();c[@"Pairing"]=values;return OBCWriteConfig(c);
}
NSString *OBCStartRTMP(NSString *url) {
    NSURLComponents *u=[NSURLComponents componentsWithString:url];struct in_addr ip;
    if(![u.scheme isEqual:@"rtmp"] || inet_pton(AF_INET,u.host.UTF8String,&ip)!=1 || u.user || u.password || u.query || u.fragment ||
        u.path.length<4 || (u.port && (u.port.integerValue<1 || u.port.integerValue>65535)))
        return @"请输入 rtmp://电脑局域网IPv4:1935/live/通道；不支持RTMPS或域名";
    NSMutableDictionary *c=OBCReadConfig();c[@"Mode"]=@"RTMP";c[@"RTMPURL"]=url;c[@"Enabled"]=@YES;
    c[@"RequestID"]=NSUUID.UUID.UUIDString;c[@"RequestDate"]=[NSDate date];
    NSString *e=OBCWriteConfig(c);if(!e)notify_post(OB_NOTIFY);return e;
}

NSString *OBCInputMode(void) { return [OBCReadConfig()[@"Mode"] isEqual:@"RTMP"]?@"RTMP":@"OBS"; }
