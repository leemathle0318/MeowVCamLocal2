#pragma once
#import <Foundation/Foundation.h>
FOUNDATION_EXPORT NSString *OBLiveAudioStatus(void);
FOUNDATION_EXPORT NSDictionary *OBLiveAudioLogSnapshot(void);
// Called on the media health queue, never in a PCM callback.
FOUNDATION_EXPORT void OBRefreshLiveAudioOwner(void);
FOUNDATION_EXPORT BOOL OBLiveAudioOwnsCapture(void);
