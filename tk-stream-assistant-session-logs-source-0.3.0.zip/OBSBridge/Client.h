#pragma once
#import <Foundation/Foundation.h>

FOUNDATION_EXPORT NSString *OBCWiFiIP(void);
FOUNDATION_EXPORT NSString *OBCPeerIP(void);
// nil = saved and read back from the shared configuration, otherwise an error.
FOUNDATION_EXPORT NSString *OBCSavePeerIP(NSString *peer);
FOUNDATION_EXPORT NSInteger OBCVideoRotation(void);
FOUNDATION_EXPORT NSString *OBCSetVideoRotation(NSInteger quarterTurns);
FOUNDATION_EXPORT NSInteger OBCVideoProfile(void);
FOUNDATION_EXPORT NSString *OBCSetVideoProfile(NSInteger profile);
FOUNDATION_EXPORT BOOL OBCLiveAudioEnabled(void);
FOUNDATION_EXPORT NSString *OBCSetLiveAudioEnabled(BOOL enabled);
FOUNDATION_EXPORT NSString *OBCURL(void);
// nil = command saved and notification posted, NOT a receiver startup acknowledgement.
FOUNDATION_EXPORT NSString *OBCSendCommand(BOOL enabled, NSString *peer);
FOUNDATION_EXPORT NSString *OBCStatus(void);
FOUNDATION_EXPORT NSString *OBCAudioStatus(void);

FOUNDATION_EXPORT NSString *OBCRtmpURL(void);
FOUNDATION_EXPORT NSString *OBCStartRTMP(NSString *url);
FOUNDATION_EXPORT NSDictionary *OBCTransform(void);
FOUNDATION_EXPORT NSString *OBCSaveTransform(NSDictionary *values);
FOUNDATION_EXPORT NSString *OBCSavePairing(NSDictionary *values);
FOUNDATION_EXPORT NSDictionary *OBCPairing(void);

FOUNDATION_EXPORT NSString *OBCInputMode(void);
FOUNDATION_EXPORT NSDictionary *OBCLogStatus(void);
FOUNDATION_EXPORT NSString *OBCLogCommand(NSString *action, NSString *requestID);
