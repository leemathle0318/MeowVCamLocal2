#pragma once
#include <array>
#include <cmath>
#include <cstdint>
#include <cstring>

namespace obs::next {
struct CaptureClockSnapshot {
    uint64_t cookie=0, unit=0, consumedFrames=0, owner=0, revision=0;
    uint32_t generation=0, formatVersion=0;
    double hostAnchor=0, masterAnchor=0, ratio=1, reportedAt=0;
    bool ready=false;
    bool fresh(double now)const {
        return ready && cookie && unit && formatVersion && !(formatVersion&1) && revision && std::isfinite(now) && now>=0 &&
            std::isfinite(reportedAt) && reportedAt>=0 && std::isfinite(ratio) && ratio>=.998 && ratio<=1.002 &&
            std::isfinite(hostAnchor) && hostAnchor>=0 && std::isfinite(masterAnchor) && masterAnchor>=0 &&
            std::fabs(hostAnchor-reportedAt)<=1. && now-reportedAt<2. && reportedAt-now<=.0025;
    }
    double masterForHost(double host,double now)const {
        if(!fresh(now) || !std::isfinite(host) || std::fabs(host-hostAnchor)>2.)return NAN;
        return masterAnchor+(host-hostAnchor)*ratio;
    }
    double hostForMaster(double master,double now)const {
        if(!fresh(now) || !std::isfinite(master))return NAN;
        double host=hostAnchor+(master-masterAnchor)/ratio;
        return std::fabs(host-hostAnchor)<=2. ? host : NAN;
    }
};
enum class CaptureFeedbackState { Unavailable, Busy, Invalid, Stale, Ready };
struct CaptureClockWire {
    enum Index : unsigned { Sequence, Cookie, Unit, Epoch, Host, Master, Ratio, Reported, Frames, Ready, Revision, Count };
    using Words=std::array<uint64_t,Count>;
    static uint64_t bits(double value){uint64_t word;std::memcpy(&word,&value,8);return word;}
    static double number(uint64_t word){double value;std::memcpy(&value,&word,8);return value;}
    static Words encode(const CaptureClockSnapshot &s) {
        Words words{};
        words[Cookie]=s.cookie;words[Unit]=s.unit;
        words[Epoch]=(uint64_t(s.generation)<<32)|s.formatVersion;
        words[Host]=bits(s.hostAnchor);words[Master]=bits(s.masterAnchor);words[Ratio]=bits(s.ratio);
        words[Reported]=bits(s.reportedAt);words[Frames]=s.consumedFrames;words[Ready]=s.ready?1:0;words[Revision]=s.revision;
        return words;
    }
    static CaptureFeedbackState decode(const Words &w,double now,uint64_t expectedCookie,uint32_t expectedGeneration,CaptureClockSnapshot &s) {
        s={};
        if(!w[Sequence] || !(w[Sequence]>>32))return CaptureFeedbackState::Unavailable;
        if(w[Sequence]&1)return CaptureFeedbackState::Busy;
        if(w[Ready]!=1)return CaptureFeedbackState::Unavailable;
        CaptureClockSnapshot candidate;
        candidate.cookie=w[Cookie];candidate.unit=w[Unit];candidate.generation=uint32_t(w[Epoch]>>32);
        candidate.formatVersion=uint32_t(w[Epoch]);candidate.owner=w[Sequence]>>32;
        candidate.hostAnchor=number(w[Host]);candidate.masterAnchor=number(w[Master]);candidate.ratio=number(w[Ratio]);
        candidate.reportedAt=number(w[Reported]);candidate.consumedFrames=w[Frames];candidate.ready=true;
        candidate.revision=w[Revision];
        if(!candidate.cookie || !candidate.unit || !candidate.formatVersion || (candidate.formatVersion&1) || !candidate.revision ||
           !std::isfinite(candidate.hostAnchor) || candidate.hostAnchor<0 ||
           !std::isfinite(candidate.masterAnchor) || candidate.masterAnchor<0 ||
           !std::isfinite(candidate.ratio) || candidate.ratio<.998 || candidate.ratio>1.002 ||
           !std::isfinite(candidate.reportedAt) || candidate.reportedAt<0 ||
           std::fabs(candidate.hostAnchor-candidate.reportedAt)>1. || !std::isfinite(now) || now<0)
            return CaptureFeedbackState::Invalid;
        if(candidate.cookie!=expectedCookie || candidate.generation!=expectedGeneration || !candidate.fresh(now))
            return CaptureFeedbackState::Stale;
        s=candidate;return CaptureFeedbackState::Ready;
    }
    // No retry loop: this is background IPC. A publication in progress can be
    // tried on the next worker tick; never stitch fields from different epochs.
    template<class Read> static CaptureFeedbackState read(Read reader,double now,uint64_t cookie,uint32_t generation,CaptureClockSnapshot &s) {
        s={};Words words{};uint64_t after=0;
        if(!reader(Sequence,words[Sequence]) || !words[Sequence])return CaptureFeedbackState::Unavailable;
        if(words[Sequence]&1)return CaptureFeedbackState::Busy;
        for(unsigned i=1;i<Count;++i)if(!reader(i,words[i]))return CaptureFeedbackState::Unavailable;
        if(!reader(Sequence,after) || after!=words[Sequence])return CaptureFeedbackState::Busy;
        return decode(words,now,cookie,generation,s);
    }
};
}
