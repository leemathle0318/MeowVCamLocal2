#pragma once
#include <cstdio>
#include <cstdint>
#include <string>
#include <array>
namespace obs {
// Background-only. Owns a previously validated regular FILE; never called by
// capture/render/decoder callbacks. Preserve the beginning instead of silently
// overwriting it at the cap. An explicit user clear is needed after saturation.
class SessionJournal {
    FILE *file_;
    uint64_t bytes_, cap_;
public:
    uint64_t dropped=0, errors=0;
    bool full=false;
    SessionJournal(FILE *file,uint64_t existing,uint64_t cap):file_(file),bytes_(existing),cap_(cap){}
    ~SessionJournal(){if(file_)std::fclose(file_);}
    SessionJournal(const SessionJournal&)=delete;
    SessionJournal& operator=(const SessionJournal&)=delete;
    uint64_t bytes()const{return bytes_;}
    bool append(const std::string &line) {
        if(line.empty() || line.back()!='\n' || line.find('\n')!=line.size()-1 || line.size()>16384) {
            ++errors;++dropped;return false;
        }
        if(bytes_>cap_ || line.size()>cap_-bytes_){full=true;++dropped;return false;}
        if(!file_ || errors){++dropped;return false;}
        if(std::fseek(file_,0,SEEK_END) || std::fwrite(line.data(),1,line.size(),file_)!=line.size() || std::fflush(file_)) {
            ++errors;++dropped;return false;
        }
        bytes_+=line.size();return true;
    }
    // Called on the same serial writer queue. Copy only committed bytes, never
    // an incomplete tail left by a failed append. Bounded memory even at 128MiB.
    bool copyTo(FILE *out) {
        if(file_)std::clearerr(file_);
        if(!file_ || !out || std::fseek(file_,0,SEEK_SET))return false;
        std::array<char,65536> block{};uint64_t remaining=bytes_;
        while(remaining) {
            size_t n=remaining<block.size()?size_t(remaining):block.size();
            if(std::fread(block.data(),1,n,file_)!=n || std::fwrite(block.data(),1,n,out)!=n)return false;
            remaining-=n;
        }
        return std::fflush(out)==0;
    }
};
}
