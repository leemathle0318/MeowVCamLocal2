#pragma once
#include "NativePCM.hpp"

namespace obs {
// Native I/O and host/video clocks need not run at exactly the same frequency.
// Keep the program read position continuous, with bounded rate compensation;
// microphone PCM, its sample count and timestamps are not changed.
struct DisciplinedAudioCursor : AudioDeliveryCursor {
    double filteredPhase = 0, correction = 0, effectiveRate = 0, phase = 0;
    double begin(uint64_t cookie, uint32_t epoch, double now, size_t frames, double sampleRate) {
        if (!cookie || !std::isfinite(now) || now < 0 || !frames || frames > 8192 ||
            !std::isfinite(sampleRate) || sampleRate < 8000 || sampleRate > 192000) {
            initialized = false; effectiveRate = 0; return NAN;
        }
        phase = initialized ? next-now : 0;
        bool reanchor = !initialized || cookie != session || epoch != generation || sampleRate != rate ||
                        std::fabs(phase) > .080;
        double duration = double(frames) / sampleRate;
        if (reanchor) { next = now; filteredPhase = correction = phase = 0; }
        else {
            // Two-second low pass rejects callback scheduling jitter. A four-second
            // phase loop corrects clock skew without accumulating a growing delay.
            filteredPhase += (phase-filteredPhase)*duration/(2.+duration);
            double target = std::clamp(-filteredPhase/4., -.0005, .0005);
            // At most 500ppm (0.05%), and 20ppm per second slew. Not ffplay's
            // much larger 10% correction; never an audio-block repeat/drop.
            correction += std::clamp(target-correction, -.000020*duration, .000020*duration);
        }
        initialized = true; session = cookie; generation = epoch; rate = sampleRate;
        effectiveRate = std::clamp(sampleRate/(1.+correction), 8000., 192000.);
        correction = sampleRate/effectiveRate-1.;
        double start = next; next += double(frames)/effectiveRate;
        return start;
    }
};
}
