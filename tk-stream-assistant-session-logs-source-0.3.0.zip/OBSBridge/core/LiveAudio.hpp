#pragma once
#include "NativePCM.hpp"

namespace obs {
// Only successful Apple I/O input pulls are eligible. Never touch playback,
// converters, failed calls or an unknown Audio Unit merely because it has bus 1.
inline bool liveInput(uint32_t type, uint32_t subtype, uint32_t manufacturer,
                      uint32_t bus, int32_t status) {
    return !status && bus == 1 && type == 0x61756f75 && manufacturer == 0x6170706c &&
        (subtype == 0x72696f63 || subtype == 0x7670696f);
}
// Preserve original arguments, status and call count even when a mixer refuses
// the format/buffer. A silence flag may only be cleared after adding real PCM.
template<class Original, class Mixer> inline int32_t liveRender(Original original, Mixer mixer,
        uint32_t *flags, uint32_t silenceFlag, bool eligible) {
    int32_t result = original();
    if (!result && eligible && mixer()) {
        if (flags) *flags &= ~silenceFlag;
    }
    return result;
}
struct PullIdentity {
    bool valid = false, sampleValid = false, hostValid = false;
    double sample = 0;
    uint64_t host = 0;
    uint32_t frames = 0, version = 0;
    bool duplicate(bool hasSample, double sampleTime, bool hasHost, uint64_t hostTime,
                   uint32_t count, uint32_t formatVersion) const {
        return valid && version == formatVersion && frames == count &&
            ((hasSample && sampleValid && sampleTime == sample) ||
             (hasHost && hostValid && hostTime == host));
    }
    bool claim(bool hasSample, double sampleTime, bool hasHost, uint64_t hostTime,
               uint32_t count, uint32_t formatVersion) {
        if (duplicate(hasSample, sampleTime, hasHost, hostTime, count, formatVersion)) return false;
        accept(hasSample, sampleTime, hasHost, hostTime, count, formatVersion);
        return true;
    }
    void accept(bool hasSample, double sampleTime, bool hasHost, uint64_t hostTime,
                uint32_t count, uint32_t formatVersion) {
        valid = true; sampleValid = hasSample; hostValid = hasHost;
        sample = sampleTime; host = hostTime; frames = count; version = formatVersion;
    }
};
}
