#pragma once
// Application adapter, MIT. FFmpeg remains LGPL under its upstream terms.
// This object belongs to ONE non-real-time worker. Never use it in AudioUnitRender.
#include <algorithm>
#include <array>
#include <cmath>
#include <cstdint>
#include <limits>
extern "C" {
#include <libavutil/audio_fifo.h>
#include <libavutil/opt.h>
#include <libswresample/swresample.h>
}

namespace obs::next {
enum class AudioEngineResult { Ok, NotConfigured, Invalid, EpochChanged, Discontinuity, Full, LibraryError, ClockUnavailable };
struct AudioEngineBlock { int frames=0; double masterTime=0; uint64_t epoch=0; };

// Resampling, variable sample counts and timestamp compensation are supplied by
// libswresample. AVAudioFifo owns sample queuing. The adapter ONLY bounds their
// memory, validates epochs/PTS and carries the external master-clock contract.
class FFmpegAudioTimeline {
public:
    static constexpr int OutputRate=48000, Capacity=96000, MaximumInput=8192, Scratch=65536;
    struct Stats { uint64_t input=0, output=0, taken=0, full=0, invalid=0, discontinuities=0; } stats;
private:
    SwrContext *swr_=nullptr;
    AVAudioFifo *fifo_=nullptr;
    std::array<float,Scratch> converted_{};
    int inputRate_=0, inputChannels_=0, outputRate_=OutputRate;
    AVSampleFormat inputFormat_=AV_SAMPLE_FMT_NONE;
    uint64_t epoch_=0;
    bool started_=false, poisoned_=false;
    double anchor_=0, head_=0, expected_=0, lastMaster_=0;
    AudioEngineResult fail(AudioEngineResult reason) { poisoned_=true;return reason; }
public:
    FFmpegAudioTimeline()=default;
    FFmpegAudioTimeline(const FFmpegAudioTimeline&)=delete;
    FFmpegAudioTimeline &operator=(const FFmpegAudioTimeline&)=delete;
    ~FFmpegAudioTimeline(){ close(); }
    void close() {
        swr_free(&swr_);av_audio_fifo_free(fifo_);fifo_=nullptr;
        inputRate_=inputChannels_=0;epoch_=0;started_=poisoned_=false;
        inputFormat_=AV_SAMPLE_FMT_NONE;
    }
    bool configure(int rate, AVSampleFormat format, const AVChannelLayout &layout, uint64_t epoch,int outputRate=OutputRate) {
        close();stats={};
        if(rate<8000 || rate>96000 || outputRate<8000 || outputRate>192000 || layout.nb_channels<1 || layout.nb_channels>2 || !epoch ||
           format==AV_SAMPLE_FMT_NONE)return false;
        AVChannelLayout mono=AV_CHANNEL_LAYOUT_MONO;
        if(swr_alloc_set_opts2(&swr_,&mono,AV_SAMPLE_FMT_FLT,outputRate,&layout,format,rate,0,nullptr)<0)return false;
        // Pre-enable resampling even for 48k -> 48k. First compensation must not
        // initialize/recreate the filter and discard pending samples mid-stream.
        if(av_opt_set_int(swr_,"flags",SWR_FLAG_RESAMPLE,0)<0 ||
           av_opt_set_double(swr_,"async",1.,0)<0 ||
           av_opt_set_double(swr_,"min_comp",.0005,0)<0 ||
           av_opt_set_double(swr_,"max_soft_comp",.002,0)<0 ||
           av_opt_set_double(swr_,"comp_duration",1.,0)<0 ||
           av_opt_set_double(swr_,"min_hard_comp",.250,0)<0 || swr_init(swr_)<0) {
            close();return false;
        }
        fifo_=av_audio_fifo_alloc(AV_SAMPLE_FMT_FLT,1,Capacity);
        if(!fifo_){close();return false;}
        inputRate_=rate;outputRate_=outputRate;inputChannels_=layout.nb_channels;inputFormat_=format;epoch_=epoch;return true;
    }
    int available()const{return fifo_?av_audio_fifo_size(fifo_):0;}
    int capacity()const{return Capacity;}
    int allocatedSamples()const{return fifo_?av_audio_fifo_space(fifo_)+av_audio_fifo_size(fifo_):0;}
    uint64_t epoch()const{return epoch_;}
    int outputRate()const{return outputRate_;}
    // masterTime is supplied by the common A/V/output clock adapter. Supplying
    // raw source PTS or unsmoothed packet-arrival time is NOT a completed sync design.
    AudioEngineResult push(const uint8_t *const *planes,int planeCount,int frames,double masterTime,uint64_t epoch) {
        if(!swr_ || !fifo_ || poisoned_)return AudioEngineResult::NotConfigured;
        if(epoch!=epoch_)return AudioEngineResult::EpochChanged;
        int required=av_sample_fmt_is_planar(inputFormat_)?inputChannels_:1;
        if(!planes || planeCount!=required || !planes[0] || frames<=0 || frames>MaximumInput || !std::isfinite(masterTime) ||
           masterTime<0 || masterTime>1e10){++stats.invalid;return AudioEngineResult::Invalid;}
        // Validate the entire required plane set before calling a C library.
        if(required>1 && !planes[1]) {
            ++stats.invalid;return AudioEngineResult::Invalid;
        }
        if(started_ && masterTime<=lastMaster_) {
            ++stats.invalid;return AudioEngineResult::Invalid; // duplicated/stale decoded block
        }
        if(started_ && std::fabs(masterTime-expected_)>.250) {
            ++stats.discontinuities;return AudioEngineResult::Discontinuity;
        }
        double base=started_?anchor_:masterTime;
        long double ticks=(static_cast<long double>(masterTime)-base)*inputRate_*outputRate_;
        // Apple arm64 long double is double. Use an exactly representable power
        // of two, not INT64_MAX rounded up to an out-of-range floating value.
        constexpr long double maximumTicks=4611686018427387904.L;
        if(!std::isfinite(ticks) || ticks < -maximumTicks || ticks > maximumTicks){
            ++stats.invalid;return AudioEngineResult::Invalid;
        }
        // AVAudioFifo auto-grows if write exceeds space. Reserve for the whole
        // conversion PLUS maximum permitted timestamp fill before advancing SWR.
        int bound=swr_get_out_samples(swr_,frames);
        int maximumFill=outputRate_/4+64;
        if(bound<0 || bound>Scratch-maximumFill)return fail(AudioEngineResult::LibraryError);
        if(av_audio_fifo_space(fifo_)<bound+maximumFill){++stats.full;return AudioEngineResult::Full;}
        int64_t stamp=swr_next_pts(swr_,std::llround(ticks));
        uint8_t *output[]={reinterpret_cast<uint8_t *>(converted_.data())};
        int n=swr_convert(swr_,output,Scratch,planes,frames);
        if(n<0 || n>av_audio_fifo_space(fifo_))return fail(AudioEngineResult::LibraryError);
        double first=base+double(stamp)/(double(inputRate_)*outputRate_);
        int queued=available();
        if(n && queued && std::fabs(first-(head_+double(queued)/outputRate_))>2./outputRate_)
            return fail(AudioEngineResult::Discontinuity);
        if(n) {
            if(!queued)head_=first;
            void *data[]={converted_.data()};
            if(av_audio_fifo_write(fifo_,data,n)!=n)return fail(AudioEngineResult::LibraryError);
        }
        anchor_=base;started_=true;lastMaster_=masterTime;expected_=masterTime+double(frames)/inputRate_;
        stats.input+=unsigned(frames);stats.output+=unsigned(n);return AudioEngineResult::Ok;
    }
    AudioEngineResult pop(float *samples,int wanted,AudioEngineBlock &block) {
        block={};
        if(!fifo_ || poisoned_)return AudioEngineResult::NotConfigured;
        if(!samples || wanted<=0 || wanted>Scratch)return AudioEngineResult::Invalid;
        int n=std::min(wanted,available());
        block={n,head_,epoch_};
        if(n) {
            void *output[]={samples};
            if(av_audio_fifo_read(fifo_,output,n)!=n)return fail(AudioEngineResult::LibraryError);
            head_+=double(n)/outputRate_;stats.taken+=unsigned(n);
        }
        return AudioEngineResult::Ok;
    }
    double filterDelay()const{return swr_?double(swr_get_delay(swr_,outputRate_))/outputRate_:0;}
};
}
