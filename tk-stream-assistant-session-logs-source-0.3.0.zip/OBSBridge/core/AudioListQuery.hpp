#pragma once
#include <cstddef>
#include <cstdint>
namespace obs {
enum class AudioListPlanCode { Ready, APIError, Capacity, InvalidSize };
struct AudioListPlan { AudioListPlanCode code; unsigned buffers; };
inline AudioListPlan audioListPlan(int32_t queryStatus, int32_t arrayTooSmall,
    size_t needed, size_t capacity, size_t offset, size_t entryBytes) {
    // A size-only probe has zero output capacity. Some runtime paths return
    // ArrayTooSmall while successfully reporting the required metadata size.
    if (queryStatus && queryStatus != arrayTooSmall) return {AudioListPlanCode::APIError, 0};
    if (needed > capacity) return {AudioListPlanCode::Capacity, 0};
    if (!entryBytes || needed < offset || (needed-offset) % entryBytes)
        return {AudioListPlanCode::InvalidSize, 0};
    size_t buffers = (needed-offset) / entryBytes;
    if (!buffers || buffers > 8) return {AudioListPlanCode::InvalidSize, 0};
    return {AudioListPlanCode::Ready, unsigned(buffers)};
}
}
