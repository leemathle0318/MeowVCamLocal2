#pragma once
#include "FFmpegAudioTimeline.hpp"
#include "CaptureClockWire.hpp"
namespace obs::next {
// Background worker adapter. Native sample/host feedback, not callback arrival,
// supplies the output clock used by FFmpeg automatic timestamp compensation.
// Output PTS is in the DEVICE's nominal 48k sample-seconds domain. It must NOT be
// relabeled as fixed-rate host seconds when writing to a legacy PCM timeline.
class CaptureClockedAudio {
    FFmpegAudioTimeline timeline_;
    CaptureClockSnapshot identity_;
    uint64_t epoch_=0;
    bool configured_=false;
    bool same(const CaptureClockSnapshot &s)const {
        return s.owner==identity_.owner && s.revision==identity_.revision && s.cookie==identity_.cookie && s.unit==identity_.unit &&
            s.generation==identity_.generation && s.formatVersion==identity_.formatVersion;
    }
public:
    bool configure(int rate,AVSampleFormat format,const AVChannelLayout &layout,
                   const CaptureClockSnapshot &clock,double now,uint64_t epoch) {
        configured_=false;timeline_.close();
        if(!clock.owner || !clock.fresh(now) || !epoch || !timeline_.configure(rate,format,layout,epoch))return false;
        identity_=clock;epoch_=epoch;configured_=true;return true;
    }
    // hostDue must come from the common source A/V -> host mapping. Source PTS
    // and packet arrival are not interchangeable with this mapped presentation.
    AudioEngineResult pushForHost(const uint8_t *const *planes,int planeCount,int frames,double hostDue,
                                 const CaptureClockSnapshot &clock,double now,uint64_t epoch) {
        if(!configured_)return AudioEngineResult::NotConfigured;
        if(epoch!=epoch_ || !same(clock))return AudioEngineResult::EpochChanged;
        if(!clock.fresh(now))return AudioEngineResult::ClockUnavailable;
        double due=clock.masterForHost(hostDue,now);
        if(!std::isfinite(due))return AudioEngineResult::ClockUnavailable;
        return timeline_.push(planes,planeCount,frames,due,epoch);
    }
    AudioEngineResult pop(float *samples,int frames,AudioEngineBlock &block){return timeline_.pop(samples,frames,block);}
    int available()const{return timeline_.available();}
    int allocatedSamples()const{return timeline_.allocatedSamples();}
    double filterDelay()const{return timeline_.filterDelay();}
    const FFmpegAudioTimeline::Stats &stats()const{return timeline_.stats;}
};
}
