#pragma once
#include "SharedMedia.hpp"
namespace obs::next {
// Background-only exact-grid copy. Rate conversion belongs to SWR, not a second
// linear interpolator or a floating-point +=10ms read cursor in front of it.
inline bool copyHostPCM48(const obs::SharedMedia &media,float *out,size_t frames,double host,uint64_t nowUS) {
    if(!out || !frames || frames>8192 || !std::isfinite(host) || host<0 || host>1e10 ||
       std::fabs(host-double(nowUS)/1e6)>2.)return false;
    uint32_t generation=media.generation.load(std::memory_order_acquire);
    if(!media.fresh(nowUS) || !media.audioReady.load(std::memory_order_acquire))return false;
    int64_t first=std::llround(host*obs::AudioRate);bool complete=true;
    for(size_t i=0;i<frames;++i) {
        float sample=0;bool found=media.sample(first+int64_t(i),sample);out[i]=sample;complete&=found;
    }
    complete=complete && media.fresh(nowUS) && media.audioReady.load(std::memory_order_acquire) &&
        generation==media.generation.load(std::memory_order_acquire);
    if(!complete)std::fill(out,out+frames,0);
    return complete;
}
}
