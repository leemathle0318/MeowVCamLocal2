#pragma once
#include <cstdint>

namespace obs {
// Only a successfully copied, process-owned snapshot may be reused. A failed
// shared-memory copy never replaces it. Stop, stream reset and session changes
// invalidate it immediately; a network gap may hold it for at most 1500 ms.
struct VideoContinuity {
    static constexpr uint64_t HoldUS = 1500000;
    uint64_t session = 0, due = 0;
    uint32_t generation = 0, slot = 0, sequence = 0;
    bool valid = false;
    void clear() { valid = false; due = 0; sequence = 0; }
    void context(uint64_t cookie, uint32_t epoch, bool active) {
        if (!active || !cookie || cookie != session || epoch != generation) clear();
        session = cookie; generation = epoch;
    }
    bool reusable(uint64_t now) const {
        return valid && now >= due && now - due < HoldUS;
    }
    bool same(uint32_t index, uint32_t version) const {
        return valid && slot == index && sequence == version;
    }
    bool accept(uint32_t index, uint32_t version, uint64_t timestamp, uint64_t now) {
        if (!session || !version || index >= 3 || timestamp > now || now - timestamp >= HoldUS) return false;
        slot = index; sequence = version; due = timestamp; valid = true; return true;
    }
};
// CoreImage uses EXIF orientation values. Opposite quarter-turns are required
// when encoding a portrait OBS frame into the landscape sensor buffer: iOS
// applies the capture session's orientation later, at display/recording time.
inline int sensorOrientation(uint32_t sourceW, uint32_t sourceH, uint32_t targetW, uint32_t targetH) {
    return ((sourceW < sourceH) != (targetW < targetH)) ? 8 : 1;
}
inline int extraOrientation(unsigned turns) {
    constexpr int orientations[] = {1, 6, 3, 8};
    return orientations[turns & 3];
}
}
