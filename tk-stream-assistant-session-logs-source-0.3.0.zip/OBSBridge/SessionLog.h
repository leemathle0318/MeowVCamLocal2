#pragma once
#import <Foundation/Foundation.h>
// SpringBoard utility queue only. No logging dependency in the RT audio tweak.
FOUNDATION_EXPORT void OBLogInitialize(void);
FOUNDATION_EXPORT void OBLogHandleConfig(NSDictionary *config);
FOUNDATION_EXPORT NSDictionary *OBLogState(void);
FOUNDATION_EXPORT void OBLogCommandEvent(BOOL enabled, BOOL rtmp);
