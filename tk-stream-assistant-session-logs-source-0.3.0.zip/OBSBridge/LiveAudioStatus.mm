#import "LiveAudioStatus.h"
#import "MediaBus.h"
#include <notify.h>
#include <atomic>
#include <mutex>
namespace {
const char *names[] = {"local.xiaoguai.obsbridge.live.heart", "local.xiaoguai.obsbridge.live.owner",
    "local.xiaoguai.obsbridge.live.calls", "local.xiaoguai.obsbridge.live.mixed",
    "local.xiaoguai.obsbridge.live.misses", "local.xiaoguai.obsbridge.live.format",
    "local.xiaoguai.obsbridge.live.phase", "local.xiaoguai.obsbridge.live.read-permission",
    "local.xiaoguai.obsbridge.live.mapping", "local.xiaoguai.obsbridge.live.coverage",
    "local.xiaoguai.obsbridge.live.gaps", "local.xiaoguai.obsbridge.live.duplicates", "local.xiaoguai.obsbridge.live.window",
    "local.xiaoguai.obsbridge.live.clock", "local.xiaoguai.obsbridge.live.clock-max", "local.xiaoguai.obsbridge.live.samples"};
int tokens[16] = {-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1};
std::mutex statusLock;
uint64_t read(unsigned i) {
    std::lock_guard<std::mutex> lock(statusLock);
    uint64_t value = 0;
    if (tokens[i] < 0 && notify_register_check(names[i], &tokens[i])) { tokens[i] = -1; return 0; }
    if (notify_get_state(tokens[i], &value)) return 0;
    return value;
}
std::atomic<uint64_t> owner{0};
}
void OBRefreshLiveAudioOwner(void) { owner.store(read(1), std::memory_order_release); }
BOOL OBLiveAudioOwnsCapture(void) {
    // Cached notification state; no IPC, allocation, filesystem or lock here.
    return obs::heartbeatFresh(owner.load(std::memory_order_acquire), OBNow());
}
NSDictionary *OBLiveAudioLogSnapshot(void) {
    uint64_t h=read(0),m=read(4),f=read(5),c=read(9),g=read(10),w=read(12),k=read(13),p=read(14);
    // Notification channels are individually atomic, not a cross-process
    // transaction. Preserve raw counters; offline deltas must honor PID resets
    // and uint32 wrap, and must NOT interpret stale heartbeats as live capture.
    return @{@"pid":@(h>>32),@"fresh":@(obs::heartbeatFresh(h,OBNow())),@"heart_raw":@(h),
        @"calls":@(read(2)),@"mixed":@(read(3)),@"underflow_u32":@(uint32_t(m>>32)),@"skipped_u32":@(uint32_t(m)),
        @"rate_hz":@(f>>32),@"bits":@((f>>16)&65535),@"channels":@(f&65535),@"phase":@(read(6)),
        @"permission_raw":@(read(7)),@"mapping_raw":@(read(8)),@"partial_blocks_u32":@(uint32_t(c>>32)),
        @"missing_samples_u32":@(uint32_t(c)),@"concealed_u32":@(uint32_t(g>>32)),@"longest_gap_us_u32":@(uint32_t(g)),
        @"duplicates":@(read(11)),@"window_calls_u32":@(uint32_t(w>>32)),@"window_underflow_u32":@(uint32_t(w)),
        @"lead_us":@(int32_t(k>>32)),@"rate_milli_ppm":@(int32_t(k)),@"rebuilds_u32":@(uint32_t(p>>32)),
        @"max_lead_us_u32":@(uint32_t(p)),@"read_samples":@(read(15))};
}
NSString *OBLiveAudioStatus(void) {
    uint64_t heart = read(0), calls = read(2), mixed = read(3), misses = read(4), format = read(5), phase = read(6);
    if (!obs::heartbeatFresh(heart, OBNow())) return @"直播音频模块：没有新心跳。请完全退出再打开 TikTok；不能据此认定观众端无声音。";
    NSArray<NSString *> *reasons = @[@"等待麦克风输入", @"已在应用 RemoteIO/VoiceIO 输入加入 OBS PCM（需观众端确认）",
        @"预备音频尚未就绪，保持原麦克风", @"原生格式/缓冲不匹配，保持原麦克风",
        @"直播混音已关闭", @"等待只读共享映射/授权", @"超过固定注册/映射上限，保持原麦克风",
        @"媒体服务版本未确认，暂不混音；安装后请重启用户空间", @"素材音块有缺样，已短渐变衔接（需查看缺样诊断）",
        @"采音入口缺少成对时间戳，无法校准；当前保持原麦克风"];
    uint64_t access = read(7), mapping = read(8), coverage = read(9), gaps = read(10), duplicates = read(11), window = read(12);
    uint64_t clock = read(13), clockMax = read(14), samples = read(15);
    return [NSString stringWithFormat:@"TikTok 音频入口 · PID %u\n%@\n成功输入 %llu / 实际加入 OBS %llu\n缺音频 %u / 格式或忙碌跳过 %u\n部分缺音块 %u / 缺失输出样本 %u；最长连续缺音 %.1f ms\n短渐出块 %u / 重复输入跳过 %llu；最近统计窗口 输入 %u / 缺音 %u\n预备音频提前量 %+.3f ms / 采音速差 %+.3f ppm\n预备提前量峰值 %.3f ms / 预备缓冲重建 %u；累计读取样本 %llu\n原生 %u Hz / %u 位 / %u 通道\n授权阶段 %u / 详情 %d；映射阶段 %u / 详情 %u\n诊断计数不是观众端播放成功证明。",
        unsigned(heart >> 32), phase < reasons.count ? reasons[unsigned(phase)] : @"未知状态",
        (unsigned long long)calls, (unsigned long long)mixed, unsigned(misses >> 32), unsigned(misses),
        uint32_t(coverage >> 32), uint32_t(coverage), uint32_t(gaps) / 1000., uint32_t(gaps >> 32),
        (unsigned long long)duplicates, uint32_t(window >> 32), uint32_t(window),
        int32_t(clock >> 32)/1000., int32_t(clock)/1000., uint32_t(clockMax)/1000., uint32_t(clockMax >> 32), (unsigned long long)samples,
        unsigned(format >> 32), unsigned((format >> 16) & 65535), unsigned(format & 65535),
        unsigned(access >> 32), int32_t(access), unsigned(mapping >> 32), uint32_t(mapping)];
}
